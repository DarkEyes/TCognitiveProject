# TCog Protocol v0.3 Changelog

Revision target: v0.3.1 draft, building on v0.3.

## v0.3.1 changes (additive, v0.3 packages remain valid)

### Schema changes

- Added optional `covers` field to manifest, with `primary` and `secondary_auto_indexed` sub-fields. Declares concept-level authority for definitional and procedural query routing. Each `primary` entry is `{concept, scope}` where `scope` is an optional qualifier distinguishing this package's treatment from another package that may also cover the same concept.
- Added validation rule (warning level) for `covers.primary` entries that do not match any cluster, unit, or feature in the package.
- See schema §5.1.2 for full structure and authoring rules.

### Retrieval changes

- Added Step 0: query class detection. Classifies queries as `definitional`, `procedural`, `analytical`, `comparative`, `appraisal`, or `other`, with optional `targets` extracted for definitional/procedural queries.
- Added §4.4: covers-routed retrieval pre-pass. For definitional and procedural queries, runs a label-matching pre-pass over packages with `covers` declarations *before* cue-based routing. The candidate set is the union of covers-routed and cue-based; covers backstops cue-based without replacing it.
- Covers-routed retrieval is mechanical (lemma + phrase containment), not semantic — it preserves the small-LLM-first design center of mechanical mode.
- `avoid_when` overrides covers: a package that has explicitly avoided a frame cannot be activated for it via covers.

### Ingestion changes

- Added Step 2.5: declare covers (concept-level authority). Authoring rules, scale guidance (5-15 entries per package), LLM-drafting workflow, and explicit failure modes (over-claiming and under-claiming).
- Updated §16 (minimal output standard) to mention covers as part of manifest authoring.

### Rationale

The covers field addresses a structural blind spot in cue-based retrieval. A package may be the authoritative home of a concept (e.g., `algorithm_design_core` for "algorithm") but its cues may be authored for design or analysis vocabulary rather than bare definitional phrasing. Cue-based retrieval then misses the package on a query like "what is an algorithm?", even though the package is the most natural home for the answer.

Covers solves this by adding a registry-level index of "where does concept X live?" that does not depend on cue authorship discipline. The field is additive — packages without it work as before — and short by design (5-15 entries per package), so authoring overhead is minimal. An auto-indexed secondary layer derived from cluster and unit labels provides fallback recall without per-package authoring.

### Carried forward from v0.3 unchanged

All schema, ingestion, and retrieval mechanics from v0.3 remain. The two retrieval modes (mechanical default, semantic-augmented opt-in), merge ingestion procedure, branching trajectories, relations with `retrieval_behavior`, lifecycle status and quality levels, copyright-safe anchors, and validation rules from v0.3 are preserved.

### Migration from v0.3

v0.3 packages are forward-compatible with v0.3.1 if `protocol_version` is updated. The `covers` field is optional. Recommended approach:

1. Update `protocol_version` on the manifest as packages are revised.
2. Author `covers.primary` for high-traffic definitional packages first (Tier 1: math, CS, science core packages).
3. Leave narrow or appraisal-only packages without `covers` until concrete routing failures emerge.

A fresh package authored under v0.3.1 should declare `covers` if it is the authoritative home of any top-level concept.

---

## v0.3 changes (from v0.2)

### Schema changes (additive, v0.2 packages remain valid)

- Added `merge_intent` field to manifest. Records package lineage when a package was created from prior packages (extension, merge, split) or fresh.
- Added `branch_of` field to trajectories. Branches are now first-class artifacts with explicit junction clusters.
- Added `negative_cue_index` and `constraint_trigger_index` to optional index structure.
- Added explicit `retrieval_behavior` enum on relations: `surface_both_frames`, `prefer_source`, `prefer_target`, `require_user_choice`.
- Added `excerpt_char_limit` recommendation (≤280) made explicit in validation rules.
- Added validation rule for `merge_intent.base_package` consistency with declared dependencies.

### Ingestion changes

- **Restored explicit package-merge procedure as §10.** v0.2 had compressed this; v0.3 makes it dedicated. Includes:
  - five-pass merge workflow (Pass 0 setup → Pass 1 local extraction → Pass 2 classification → Pass 3 delta construction → Pass 4 trajectory branch detection → Pass 5 conflict surfacing).
  - explicit duplicate / refinement / novel / conflict classification rules with similarity thresholds.
  - full delta document JSON structure with additions, refinements, branches, conflicts, summary.
  - trajectory branch detection via reading-order alignment (no graph isomorphism needed).
  - conflict surfacing with proposed resolutions, recommended resolution, and user-decision flag.
- Added Rule 8 to discipline rules: surface conflicts; do not resolve them silently.
- Added merge-intent recording when merge is committed.

### Retrieval changes

- **Two retrieval modes specified explicitly.** This restores the small-LLM-first design center:
  - **Mechanical mode (default):** cue matching, negative cues, activation policy, trajectory phrase matching, conversation state. No semantic similarity. Auditable, model-independent, runs on small local LLMs.
  - **Semantic-augmented mode (opt-in):** adds semantic similarity to cluster description and unit definition. For capable models when cue coverage is incomplete.
- Score formulas given for both modes; mechanical is the documented baseline.
- Mode declared in runtime state via `retrieval_mode` field.
- Added `retrieval_behavior` dispatch in conflict-check step. Conflicts now have machine-readable presentation rules.
- Added branching trajectory handling: when a trajectory has `branch_of`, retrieval can use parent up to junction and branch beyond, or surface both.
- Added cluster activation cap (7) with tie-breaking rules.
- Added explicit `coherence_budget` placeholder note: declared in runtime state but concrete rules deferred to v0.4.

### Carried forward from v0.2 unchanged

- Activation policies at package and cluster level.
- Lifecycle status (`candidate / draft / human_vetted / expert_vetted / field_tested / deprecated`).
- Quality levels orthogonal to status.
- Copyright-safe anchors.
- Relations as first-class objects.
- Required cluster fields: cues, default_behavior, activation_policy.
- Two-pass ingestion (local extraction + global consolidation).
- Layered response format with Sections A–D.
- Runtime state object.
- Worked examples for grief-frame overreach, hospital allocation, conflicting frames.

### Migration from v0.2

v0.2 packages are forward-compatible with v0.3 if `protocol_version` is updated. New optional fields (`merge_intent`, `branch_of`, `retrieval_behavior` in relations) are added as packages are revised.

v0.1 packages (e.g., the kolmogorov_wiki package) require migration: `default` → `default_behavior`, addition of cluster `activation_policy`, anchor excerpts shortened to ≤280 chars.

## Suggested next steps

1. Build a validator for TCog Schema v0.3 that checks IDs, references, anchors, cluster cues, activation policies, trajectory paths, merge-intent consistency, and branch junctions.
2. Migrate the kolmogorov_wiki package to v0.3 as a worked example.
3. Test the merge-ingestion procedure with a small worked example: an existing package extended by a new source.
4. Build the web app with API key supply, package loading, mechanical-mode retrieval default, and the runtime state object persisted across sessions.
5. Defer to v0.4: concrete coherence budget rules, semantic-similarity threshold defaults, ecosystem-level concerns (registry, signing, revocation).
