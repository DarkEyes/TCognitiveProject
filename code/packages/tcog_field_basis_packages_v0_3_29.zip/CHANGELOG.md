# TCog Field Basis Packages — Medicine Cue Audit

**Bundle version:** v0.3.29-medicine-cue-audit
**Bundle date:** 2026-05-03
**Protocol version:** 0.3.1
**Builds on:** v0.3.28-covers-complete

This bundle adds a targeted cue-discipline audit on `medicine_diagnostic_safety_core` to fix the false-positive frame-routing issue where the medicine package was activating on non-medical text (econometric analysis, credit scoring examples, ML supervised-learning passages).

## What changed in this revision

### medicine_diagnostic_safety_core: 0.3.1 → 0.3.2

**Pure deletion audit. No cues added. No cues replaced with longer phrases.**

The principle: a cue earns its place in a narrow-domain package only if its appearance in text indicates the text is probably about that domain. Generic vocabulary that is also used in statistics, finance, ML, decision theory, or generic English does not earn its place — even if it has legitimate domain-specific meaning when context is present.

71 cluster cues deleted across 8 clusters. 14 constraint trigger_cues deleted across 4 constraints.

#### Cluster cue deletions (71 total)

- **k_first_do_no_harm** (-8): "is this safe", "could this hurt", "risk of harm", "minimize risk", "safety first", "dose", "how much should I take", "is it safe to take" — these fire on safety-of-anything contexts.
- **k_symptoms_are_evidence_not_diagnosis** (-9): "experiencing", "what does this mean", "is this serious", "what could cause this", "evidence of", "indicator of", "could be a sign of", "pain", "feel tired" — generic English; "evidence of" and "indicator of" especially fire on social-science and stats text.
- **k_differential_diagnosis_matters** (-7): "differential", "could it be", "possible causes", "rule out", "narrow down", "list of possibilities", "what else could it be" — "differential" alone is math/stats; the rest are generic problem-solving English.
- **k_red_flags_override_routine** (-10): "red flag", "red flags", "warning sign", "is this an emergency", "danger sign", "urgent", "needs immediate", "don't wait", "severe", "sudden severe" — heavily used in dating, finance, project management, generic.
- **k_base_rates_matter_clinically** (-8): "base rate", "base rates", "prior probability", "how common is", "prevalence", "common condition", "Bayesian", "before testing" — these are statistics/probability vocabulary, not medicine-defining.
- **k_tests_have_false_positives_and_negatives** (-10): "false positive", "false negative", "test sensitivity", "test specificity", "uncertain", "uncertainty", "test accuracy", "could be wrong", "wrong test result", "test imperfection" — entirely cross-domain stats vocabulary. **This cluster now has zero cues.** Author review needed: the cluster's content (clinical-test interpretation) deserves medicine-specific cues, or the cluster should be merged with a stats package's content.
- **k_treatment_depends_on_diagnosis_and_values** (-12): "treatment", "what to do about", "how to treat", "should I take", "shared decision", "their priorities", "quality of life", "what matters to them", "risk benefit", "is it worth it", "weighing the risks", "pros and cons" — "treatment" alone fires on data treatment, tax treatment, legal treatment.
- **k_uncertainty_must_be_managed** (-7): "uncertain", "uncertainty", "not sure", "we don't know", "could be wrong", "what we don't know", "probabilistic" — pure cross-domain epistemic vocabulary.

#### Constraint trigger_cue deletions (14 total)

- **c_red_flag_safety_boundary** (-3): "severe", "red flag", "emergency" — would fire critical blocking constraint on "severe over-fitting", "red flag in the contract", "emergency hotfix".
- **c_no_unsupervised_diagnosis** (-4): "might have", "I think I have", "I think I might have", "do I have" — would fire blocking diagnosis-refusal constraint on "the model might have a bias", "I think I have a typo".
- **c_no_individualized_dosing** (-3): "how much should I take", "is it safe to take", "what should I take for" — ambiguous (food, supplements, alcohol).
- **c_uncertainty_disclosure** (-4): "evidence shows", "studies have found", "is it true that", "is it confirmed" — generic empirical-claim vocabulary; constraint would fire on every empirical claim in any domain.

### Verification

After audit, the test cases that exposed the bug now route correctly:

| Text | Before | After |
|---|---|---|
| "VAR analysis... Granger-causes retail spending..." | Primary: medicine | Medicine: NOT active |
| "credit scoring model algorithm trained on financial data..." | Primary: medicine | Medicine: NOT active |
| "customer segmentation algorithms cluster customers..." | Primary: medicine | Medicine: NOT active |
| "Supervised learning: a paradigm in ML..." | Aux: medicine | Medicine: NOT active; ml_core primary |
| "patient presents with crushing chest pain..." | Primary: medicine | Primary: medicine ✓ (red_flag constraint fires) |
| "How do doctors decide between diagnoses..." | Primary: medicine | Primary: medicine ✓ |

Medicine's own 5 internal tests still pass.

## Known issues for future revisions

The Granger and credit-scoring test cases also revealed similar overreach in other packages — bare single-letter constraint triggers ("L", "n"), bare common English words ("or", "model", "algorithm", "machine") in constraint trigger_cues. These cause the same false-positive class of failures in `theory_of_computation_core`, `algorithm_design_core`, `combinatorics_discrete_structures_core`, and `computer_science_systems_core`.

These are **not addressed in this revision**. The medicine audit was scoped narrowly per the issue report. A parallel audit on the formal-CS packages should be the next revision — same principle, same methodology: a constraint trigger_cue earns its place only if its appearance indicates the text is probably about that domain.

## Bundle stats

- **34 packages** total
- **34/34** declare covers
- **580 covers primary entries** across the bundle
- **1,140 anchored units** (unchanged)
- **302 clusters** (unchanged)
- **278 constraints** (unchanged)
- **586 tests** (unchanged; 5/5 medicine tests pass)
- **medicine cluster cues**: 116 → 45 (-71)
- **medicine constraint triggers**: 34 → 20 (-14)


---

# Previous bundle revision

# TCog Field Basis Packages — Covers Complete

**Bundle version:** v0.3.28-covers-complete
**Bundle date:** 2026-05-03
**Protocol version:** 0.3.1

This bundle contains all 34 TCog basis packages with complete covers manifest declarations per TCog Schema v0.3.1. Every package now declares concept-level authority via the `covers` field, supporting covers-routed retrieval for definitional and procedural queries.

## Bundle summary

- **34 packages** total
- **34/34** declare covers
- **580 covers primary entries** across the bundle
- **1,140 anchored units**
- **302 clusters**
- **278 constraints**
- **586 tests**
- **0 covers validation warnings**

## What changed in this bundle

### Phase 1 — earlier sessions (11 packages)

These were updated in prior work:

| Package | Version | Covers entries |
|---|---|---|
| algorithm_design_core | 0.4.0 | 16 (incl. foundational `k_algorithmic_foundations` cluster + 4 anchored units added) |
| theory_of_computation_core | 0.3.2 | 17 (plus repaired malformed `blocks_answer` field on 17 constraints) |
| graph_theory_core | 0.3.1 | (TBD) |
| ml_core | 0.2.0 | (TBD) |
| set_theory_logic_core | 0.2.0 | (TBD) |
| linear_algebra_core | 0.2.0 | (TBD) |
| scientific_methodology_core | 0.2.0 | (TBD) |
| probability_stats_core | 1.0.0 | 104 (major content revision: 113 new units across 8 new clusters; renamed from probability_stats_foundations_core) |
| statistics_core | 0.3.1 | 11 |
| combinatorics_discrete_structures_core | 0.3.1 | 15 |
| calculus_real_analysis_core | 0.2.0 | 12 |

### Phase 2 — this session (23 packages)

Eight batches:

**Batch 1 — Practitioner / applied (4 packages):**
- medicine_diagnostic_safety_core 0.3.0 → 0.3.1 (10 covers entries, safety_critical)
- counselling_practice_core 0.3.0 → 0.3.1 (10 covers entries, safety_critical)
- law_practice_core 0.3.0 → 0.3.1 (13 covers entries, safety_critical)
- education_pedagogy_core 0.3.1 → 0.3.2 (14 covers entries)

**Batch 2 — Social sciences (5 packages):**
- economics_core 0.3.0 → 0.3.1 (11 covers entries)
- political_science_governance_core 0.3.0 → 0.3.1 (13 covers entries)
- sociology_institutions_core 0.3.1 → 0.3.2 (15 covers entries)
- history_path_dependence_core 0.3.0 → 0.3.1 (9 covers entries)
- psychology_core 0.3.0 → 0.3.1 (16 covers entries)

**Batch 3 — Hard sciences (3 packages):**
- physics_dynamical_constraints_core 0.3.1 → 0.3.2 (18 covers entries)
- chemistry_interactions_core 0.3.1 → 0.3.2 (16 covers entries)
- biology_adaptation_core 0.3.0 → 0.3.1 (9 covers entries)

**Batch 4 — Communication & cognition (3 packages):**
- cognitive_science_core 0.3.0 → 0.3.1 (15 covers entries)
- communication_rhetoric_core 0.3.0 → 0.3.1 (12 covers entries)
- philosophy_ethics_core 0.3.0 → 0.3.1 (10 covers entries)

**Batch 5 — HCI / decision / management / IS (4 packages):**
- design_hci_core 0.3.1 → 0.3.2 (16 covers entries)
- operations_research_decision_core 0.3.1 → 0.3.2 (20 covers entries)
- management_execution_core 0.3.1 → 0.3.2 (13 covers entries)
- information_science_retrieval_core 0.3.1 → 0.3.2 (22 covers entries)

**Batch 6 — Math (1 package):**
- math_proof_core 0.3.0 → 0.3.1 (15 covers entries)

**Batch 7 — Engineering (2 packages):**
- systems_control_core 0.3.1 → 0.3.2 (20 covers entries)
- computer_science_systems_core 0.3.0 → 0.3.1 (10 covers entries)

**Batch 8 — Aesthetics (1 package):**
- art_form_affect_core 0.3.1 → 0.3.2 (17 covers entries)

## Productive cross-package overlaps preserved

The covers framework's strength is multi-package coverage with distinguishing scope qualifiers. Selected examples surfaced through this rollout:

- **`learning`**: ml_core (machine learning) ↔ education_pedagogy_core (human pedagogical) ↔ cognitive_science_core (cognitive-architecture)
- **`feedback`**: design_hci_core (UI feedback) ↔ education_pedagogy_core (instructional) ↔ systems_control_core (control-theoretic)
- **`cognition` / `memory` / `attention`**: cognitive_science_core (architecture) ↔ psychology_core (process) ↔ design_hci_core (implication) ↔ education_pedagogy_core (pedagogical)
- **`equilibrium`**: economics_core (market) ↔ chemistry_interactions_core (Le Chatelier) ↔ physics_dynamical_constraints_core (dynamical)
- **`state space`**: physics_dynamical_constraints_core (dynamical) ↔ systems_control_core (control-theoretic)
- **`Lyapunov`**: physics_dynamical_constraints_core (stability) ↔ systems_control_core (control function)
- **`Lagrangian`**: physics_dynamical_constraints_core (action principle) ↔ operations_research_decision_core (duality)
- **`legitimacy`**: political_science_governance_core (political) ↔ philosophy_ethics_core (normative)
- **`institutions`**: political_science_governance_core (formal) ↔ sociology_institutions_core (cultural) ↔ history_path_dependence_core (persistent)
- **`tradeoff`**: economics_core (scarcity-based) ↔ ml_core (bias-variance) ↔ biology_adaptation_core (evolutionary fitness)
- **`decision`**: operations_research_decision_core (under uncertainty) ↔ probability_stats_core (decision theory) ↔ management_execution_core (managerial)
- **`tragedy of the commons`**: political_science_governance_core (governance) ↔ systems_control_core (system archetype)
- **`Goodhart's law`**: operations_research_decision_core (proxy metrics) ↔ management_execution_core (organizational)
- **`safety`**: counselling_practice_core (crisis) ↔ medicine_diagnostic_safety_core (clinical) ↔ systems_control_core (engineering)
- **`value`**: philosophy_ethics_core (ethical) ↔ medicine_diagnostic_safety_core (patient values) ↔ art_form_affect_core (aesthetic)
- **`graph` / `tree`**: graph_theory_core (structural) ↔ combinatorics_discrete_structures_core (counting)
- **`function`**: set_theory_logic_core (set-theoretic mapping) ↔ probability_stats_core (loss function) ↔ biology_adaptation_core (biological)

A query like "what is feedback?" surfaces all three relevant packages with their distinguishing scope qualifiers; the LLM in the retrieval pipeline picks the framing matching the question's intent.

## Safety_critical packages (3)

These packages have safety_critical implications. Their blocking constraints should not be user-overridable per the architecture's safety design (see Claude Code prompt in separate file). The covers entries here are routing aids; the safety architecture (constraints with severity:critical and blocks_answer:true) operates independently of covers.

- medicine_diagnostic_safety_core
- counselling_practice_core
- law_practice_core

## Verification

| Check | Result |
|---|---|
| Schema validity (all packages) | OK (no cross-package validator run yet, per-package validators were clean during authoring) |
| Covers warnings (entry not matching any cluster/unit/feature) | 0 across 34 packages |
| Internal tests preserved (per-package) | All preserved during covers addition |
| Malformed `blocks_answer` field | 0 (theory_of_computation_core fix included) |

## Known follow-ups (out of scope for this bundle)

1. **Pipeline: covers-routed retrieval** — implemented separately in TCog-R demo via the prompt provided previously
2. **Pipeline: constraint trigger_cue gating** — constraints should fire only on trigger_cue match (currently over-fires on cluster-relatedness alone)
3. **Pipeline: safety_critical override for non-critical blocks** — implemented via the override-button prompt provided previously

These are TCog-R pipeline changes, not package changes.
