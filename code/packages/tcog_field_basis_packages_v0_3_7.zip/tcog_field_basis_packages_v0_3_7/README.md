# TCog Field Basis Packages v0.3.7

This bundle contains 7 focused reference packages and 17 loadable scaffold packages — 24 total — for TCog Protocol v0.3 field-level query routing.

**Reading guide:** the seven focused packages are intended for evaluation as authored content (real anchors to canonical works; some have blocking constraints, multiple trajectories, and substantive cross-package relations). The seventeen scaffolds are loadable v0.3 packages that pass schema validation and demonstrate breadth-of-domain, but their anchors are self-referential and their content is templated — they are not authored disciplinary content. See `PROVENANCE.json` for the per-package quality declaration.

## What this is

A seed package bundle for Trajectory Cognition. Each package is a loadable bundle of:

```text
manifest.json
units.jsonl
clusters.jsonl
constraints.jsonl
transitions.jsonl
trajectories.jsonl
relations.jsonl
tests.jsonl
index.json
validation_report.json
package.combined.json
README.md
```

## Bundle totals

- 24 packages
- 194 units, 194 clusters
- 61 constraints (11 blocking)
- 35 trajectories (16 with output_template, 1 branching)
- 39 cross-package relations
- 42 single-package tests + cross_package_tests.jsonl at bundle root

## Retrieval grammar

```text
query
→ package routing
→ cue and negative-cue scan
→ cluster activation
→ unit loading
→ constraint trigger check
→ trajectory match
→ relation/conflict check
→ answer with marked synthesis
→ state update
```

## Authoring depth

Packages are at three authoring depths. The bundle is intentionally layered: a few packages are authored to demonstrate the architecture's distinctive moves; the rest are scaffolds that show the schema scales across fields.

### Focused (with real anchors): 7 packages

Real anchors to canonical works. The five *fully focused* packages also have blocking constraints, multiple trajectories with output_template, and substantive cross-package relations. The *anchor_promoted* packages have real anchors but light-tier constraint and trajectory machinery — see `PROVENANCE.json` for details.

**Fully focused** (5):

- `counselling_practice_core` — counselling
- `economics_core` — economics
- `medicine_diagnostic_safety_core` — medicine
- `philosophy_ethics_core` — philosophy / ethics
- `statistics_core` — statistics

**Anchor-promoted** (2):

- `biology_adaptation_core` — biology
- `computer_science_systems_core` — computer science

### Light scaffolds: 17 packages

Self-referential anchors, label-derived basis_role and failure_modes, single trajectory. Useful for breadth-of-domain demonstration; not intended to be evaluated as authored content until upgraded.

- `art_form_affect_core` — art / aesthetics
- `chemistry_interactions_core` — chemistry
- `cognitive_science_core` — cognitive science
- `communication_rhetoric_core` — communication / rhetoric
- `design_hci_core` — design / human-computer interaction
- `education_pedagogy_core` — education
- `history_path_dependence_core` — history
- `information_science_retrieval_core` — information science
- `law_admissibility_core` — law
- `management_execution_core` — management
- `math_proof_core` — mathematics
- `operations_research_decision_core` — operations research / decision science
- `physics_dynamical_constraints_core` — physics
- `political_science_governance_core` — political science
- `psychology_core` — psychology
- `sociology_institutions_core` — sociology / anthropology
- `systems_control_core` — systems engineering / control theory

## Verification

The bundle ships with a verification machinery that exits non-zero on any failure:

```bash
make verify       # schema + loader + tests
make verify-all   # schema + loader + tests + SHA256SUMS verification
```

`make verify` runs three checks:

1. `python3 validate_bundle.py --strict` — v0.3 schema validation with line-level error reporting across every file in every package. Exits 0 only if all 24 packages pass strict mode (zero errors and zero warnings).
2. `python3 load_example.py` — loader smoke test that loads every package's `package.combined.json` and prints a per-package summary.
3. `python3 run_tests.py` — runs all 42 single-package tests and 6 cross-package tests against the Python port of the v0.3 retrieval engine. The Python engine in `run_tests.py` produces identical results to the JavaScript engine in `tcog_demo.html`.

A GitHub Actions workflow at `.github/workflows/verify.yml` runs `make verify` on every push, plus:

- `sha256sum -c SHA256SUMS` to verify content integrity (299 files).
- A focused-tier audit that fails the build if any focused-tier package has self-referential anchors.

See `AUTHORING_GUIDE.md` for documentation on authoring new packages and `PROVENANCE.json` for the per-package tier declaration with structural guarantees.

## Loader note

Use `bundle_manifest.json` to discover packages. Load each package folder independently or load `package.combined.json` for a single-file import. See `load_example.py` for a minimal loader.

## Cross-package tests

`cross_package_tests.jsonl` at the bundle root contains tests that require multiple packages loaded together. Each test specifies `required_packages` and the expected multi-package behavior (multi-frame banner, cross-package constraint firing, etc.).

## Safety note

`counselling_practice_core` is safety-sensitive. Its critical-severity blocking constraint `c_crisis_safety_override` fires on suicide/self-harm indicators and directs users to concrete crisis-line resources (988 in US, 116 123 in UK, local emergency services). Its high-severity blocking constraint `c_no_clinical_substitution` refuses requests to substitute the system for professional therapy. The package is NOT a substitute for therapy, counselling, or crisis intervention; it disciplines responses to emotional content within an architecturally bounded scope.
