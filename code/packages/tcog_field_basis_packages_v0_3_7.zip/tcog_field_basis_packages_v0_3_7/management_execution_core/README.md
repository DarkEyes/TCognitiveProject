# Management Execution Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core management reasoning principles for goals, planning, organizing, leading, controlling, strategy fit, structure, culture, stakeholders, metrics, execution, and learning.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`management_execution_core:tr_core` — management execution trajectory
