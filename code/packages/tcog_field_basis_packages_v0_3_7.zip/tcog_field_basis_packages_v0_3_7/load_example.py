import json
from pathlib import Path

root = Path(__file__).resolve().parent
bundle = json.loads((root / "bundle_manifest.json").read_text())
print(f"Bundle: {bundle['bundle_id']} with {bundle['package_count']} packages")

for p in bundle["packages"]:
    pdir = root / p["path"]
    manifest = json.loads((pdir / "manifest.json").read_text())
    index = json.loads((pdir / "index.json").read_text())
    print(f"- {manifest['package_id']}: {len(index['cluster_summary'])} clusters, {len(index['cue_index'])} cue terms")
