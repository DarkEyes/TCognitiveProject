# Release Notes — TCog Field Basis Packages v0.3.5

**Release date:** 2026-04-30
**Bundle:** `tcog_field_basis_packages_v0_3_5.zip`
**Protocol version:** 0.3
**Previous release:** v0.3.4

## Summary

This release adds release-quality verification machinery and promotes
`statistics_core` from medium tier to focused-with-anchors tier. The bundle
now ships with mechanically verifiable claims: every architectural property it
asserts is testable by running `make verify`.

No new theoretical content. No new packages. The architectural skeleton is
unchanged.

## What's new

### Verification machinery

- **`validate_bundle.py`** — schema validator for v0.3 packages. Verifies
  every file in every package against the schema with line-level error
  reporting. Catches missing fields, cross-references to nonexistent ids,
  duplicate ids, blocking constraints without `repair`, and namespace
  violations. Strict mode treats warnings as errors. Exits 0 only if all
  packages pass.

- **`run_tests.py`** — Python port of the v0.3 retrieval engine. Runs all
  42 single-package tests and 6 cross-package tests. Produces identical
  results to the JavaScript engine in `tcog_demo.html`. The Python and
  JS implementations are now redundant verifications of each other.

- **`Makefile`** — single-command verification recipe. `make verify` runs
  schema validation, loader smoke test, and the test suite in sequence,
  exiting non-zero on any failure.

- **`.github/workflows/verify.yml`** — CI configuration. Runs `make verify`
  on every push, plus content-hash verification against `SHA256SUMS` and a
  focused-tier audit that fails the build if any focused-tier package has
  self-referential anchors.

- **`SHA256SUMS`** — content hashes of all 299 files in the bundle. Verify
  with `sha256sum -c SHA256SUMS`.

### Documentation

- **`PROVENANCE.json`** — honest per-package tier declaration with
  structural guarantees. Each tier (focused, medium, light) comes with a
  list of properties that mechanically verify, plus a list of cited sources
  for focused-tier packages.

- **`AUTHORING_GUIDE.md`** — step-by-step guide for authoring a new
  package, from light scaffold to focused tier. Documents the cue-tightening
  loop, common mistakes, and verification expectations.

### Statistics promotion

`statistics_core` was at medium tier in v0.3.4 with 3 of 10 units anchored.
In v0.3.5 the remaining 7 units are anchored to canonical works:

- `u_uncertainty_must_be_quantified` — Wasserman 2004; Gelman & Hennig 2017
- `u_base_rates_matter` — Tversky & Kahneman 1980; Gelman et al. 2013 BDA3
- `u_selection_bias_distorts_conclusions` — Heckman 1979; Rothman, Greenland, Lash 2008
- `u_measurement_error_matters` — Carroll et al. 2006
- `u_model_assumptions_are_part_of_the_claim` — Box 1976; McElreath 2020
- `u_overfitting_is_real` — Hastie, Tibshirani, Friedman 2009
- `u_significance_is_not_practical_importance` — Wasserstein & Lazar 2016 (ASA Statement); Ziliak & McCloskey 2008

`statistics_core` is now at focused-with-anchors tier alongside `economics_core`,
`medicine_diagnostic_safety_core`, `philosophy_ethics_core`, and
`counselling_practice_core`.

## Bundle totals

| Item | Count |
|---|---|
| Packages | 24 |
| Total units | 194 |
| Total clusters | 194 |
| Total constraints | 61 (11 blocking) |
| Total trajectories | 35 (16 with output_template, 1 branching) |
| Total relations | 39 |
| Total tests | 42 single-package + 6 cross-package = 48 |
| Anchors to external sources (focused tier) | 58+ |
| Self-referential anchors (light tier) | 156 |

## Verification status

```
$ make verify
>>> Schema validation (v0.3, strict mode)
=== SUMMARY ===
  Packages validated: 24
  Passed: 24
  Failed: 0
  Bundle errors: 0
  Total errors: 0
  Total warnings: 0

>>> Loader smoke test
Bundle: tcog_field_basis_packages_v0_3 with 24 packages
  loader: OK

>>> Test suite (single-package + cross-package)
===== SUMMARY =====
Single-package: 42/42 pass
Cross-package:  6/6 pass

===============================================
  All verification steps passed.
===============================================
```

```
$ sha256sum -c SHA256SUMS | grep -c OK
299
```

## What did NOT change in v0.3.5

- No new theoretical content. No new packages.
- The architectural schema is unchanged.
- The 19 light-tier packages retain self-referential anchors and
  templated content. They serve as breadth-of-domain scaffolds. Promoting
  them to medium or focused tier is a future authoring activity.
- The Anthropic API integration in `tcog_demo.html` is unchanged.
- All previously passing tests still pass.

## Honest disclosure

The 19 light-tier packages have self-referential anchors. This is correctly
declared in `PROVENANCE.json` and is mechanically distinguishable from
focused-tier packages. The CI workflow includes a check that fails the build
if any focused-tier package develops self-referential anchors, but does not
fail on light-tier packages.

The five focused-tier packages cite real published works. The excerpts are
short (under 500 characters each) and are presented in the spirit of fair-use
citation for academic and educational reference. If any rights-holder objects
to a specific excerpt, the affected anchor can be removed and replaced with a
citation-only stub without breaking the architecture.

## Migration from v0.3.4

No breaking changes. v0.3.4 packages load unchanged in v0.3.5. The bundle's
new top-level files (`validate_bundle.py`, `run_tests.py`, `Makefile`,
`PROVENANCE.json`, `AUTHORING_GUIDE.md`, `SHA256SUMS`,
`.github/workflows/verify.yml`) are additions; nothing in v0.3.4's package
contents was modified except `statistics_core`'s newly-added unit anchors and
its bumped `authoring_status`.

## Known limitations

The bundle as-shipped runs only on Python 3.8+. The retrieval engine in
`run_tests.py` does no caching of `package.combined.json` parsing across tests;
for a 24-package bundle this is fast enough that it doesn't matter, but a
1000-package bundle would want a single load.

The schema validator does not enforce stylistic conventions beyond the v0.3
required fields. It will pass packages whose units are aphoristic one-sentence
labels rather than authored content. The `tier` declaration in
`PROVENANCE.json` is the place where stylistic standards are asserted; the
focused-tier audit enforces the most important one (no self-referential anchors).

## Looking forward

The next round of work would be domain-expert authoring for one or more of
the 19 light-tier packages — particularly the cross-cutting ones (`law_admissibility_core`,
`computer_science_systems_core`, `psychology_core`) that other packages
have declared dependencies on. Each promotion is a real authoring effort,
not a polish pass.
