# TCog Package Authoring Guide

This document describes how to author a TCog v0.3 package, from a blank scaffold
to a focused-with-anchors package that demonstrates the architecture's
distinctive moves.

## What a package is

A TCog package is a folder of structured data describing one analytical domain:
its core distinctions, the cues that should activate it, the constraints that
should fire when its frame is misapplied, and the reasoning paths it supports.

A package is loadable into the multi-package retrieval engine. Loading it gives
the engine a way to recognize when this domain's frame is the right one for a
query, what to retrieve when it is, and what to refuse when the query is
malformed within this frame.

## File layout

```
your_package_core/
  manifest.json              package metadata, activation policy, frame limits
  units.jsonl                authored content with anchor citations
  clusters.jsonl             groupings of units by analytical distinction
  constraints.jsonl          rules with severity and optional blocks_answer
  transitions.jsonl          allowed transitions between clusters
  trajectories.jsonl         named reasoning paths through clusters
  relations.jsonl            cross-package relations to other packages
  tests.jsonl                test queries with expected behavior
  index.json                 derived index of cues to clusters (auto-generated)
  validation_report.json     per-package structural validation
  package.combined.json      single-file load of all of the above (auto-generated)
  README.md                  human-readable description
```

## Authoring tiers

A package is at one of three tiers. The tier is declared in `manifest.json`
under `authoring_status` and verified mechanically by `validate_bundle.py`.

### Light (scaffold)

Required to be a valid loadable package:
- Schema-valid v0.3 (verified by `validate_bundle.py`).
- Cluster labels identify real disciplinary distinctions, not topic labels.
- Activation policy with `avoid_when` conditions for frame discipline.
- At least one trajectory and at least one constraint.

Acceptable shortcuts at this tier:
- Anchors may have `source_id == package_id` (self-referential) as placeholders.
- `failure_modes` and `basis_role` may be derived from cluster labels.
- A single trajectory whose path is "all clusters in declaration order" is okay.
- Tests may be minimal.

### Medium

Adds:
- At least 3 units with anchors to external sources (`source_id != package_id`).
- At least one constraint with `blocks_answer: true` and severity in (high, critical).
- At least 2 distinct trajectories with separate trigger cues.
- Tests with populated `expected_activated_clusters`.

### Focused (with anchors)

Adds:
- Every unit anchored to canonical works (no self-referential anchors).
- Multiple blocking constraints that demonstrate the architecture's
  refusal-to-confabulate behavior on real queries.
- At least 3 trajectories with `output_template` specifying response structure.
- Substantive cross-package relations with real notes (not template noise).
- Tests that exercise specific trajectories.

## Step-by-step: authoring a focused package

Use one of the existing focused packages as a template. The five focused
packages in this bundle are: `economics_core`, `medicine_diagnostic_safety_core`,
`philosophy_ethics_core`, `counselling_practice_core`, `statistics_core`.

### 1. Identify the analytical distinctions

Before writing any JSON, list 6-10 distinctions that are the working vocabulary
of the field. For economics: scarcity, opportunity cost, incentives, marginal
analysis, equilibrium, externalities, etc. For medicine: red flags, differential
diagnosis, base rates, test imperfection, treatment-and-values, etc.

These are not topic labels ("microeconomics", "diagnosis"). They are
*distinctions a practitioner uses* — what they would correct a student for
missing.

Each distinction becomes a unit (the authored content) and a cluster (the
group with cues that activate it).

### 2. Write units with real anchors

For each distinction, find a canonical source — a textbook, foundational paper,
clinical guideline, or established treatise. Quote a short passage (10-400
characters) that the unit's definition is grounded in.

```json
{
  "id": "your_package:u_some_distinction",
  "label": "some distinction",
  "definition": "One or two sentences explaining the distinction in your own words.",
  "anchors": [
    {
      "type": "textbook_passage",
      "source_id": "smith_textbook_2020",
      "source_title": "Smith, A. (2020). The Definitive Textbook on Topic.",
      "location": "Chapter 3, Section 2",
      "excerpt": "The actual quoted passage from the source.",
      "excerpt_char_limit": 280
    }
  ]
}
```

Self-discipline: do not invent citations. If you cannot find a real source for
a distinction, leave it as self-referential at light tier. False citations are
worse than no citations.

### 3. Write clusters with discriminating cues

Each cluster groups one or more units and gives the engine cues that should
activate it.

```json
{
  "id": "your_package:k_some_distinction",
  "label": "some distinction",
  "description": "What this cluster captures.",
  "members": ["your_package:u_some_distinction"],
  "default_behavior": "What the system should do when this cluster activates.",
  "basis_role": "Why this distinction matters in the field's reasoning.",
  "cues": [
    "natural language phrase 1",
    "discipline-specific term",
    "common phrasing of the question"
  ],
  "negative_cues": [
    "phrasing that suggests this distinction is being misapplied"
  ],
  "activation_policy": {
    "activate_when": ["specific contexts where the cluster applies"],
    "avoid_when": ["contexts where the cluster should not fire"]
  },
  "failure_modes": [
    "specific recurring mistake when this distinction is missed"
  ]
}
```

Cue authoring discipline: cues should match natural-language queries that real
users produce, not just discipline jargon. "should we spend more on X" is a
better cue for the scarcity cluster than "scarcity" alone, because users don't
say "scarcity" — they say "should we spend more."

### 4. Write blocking constraints

Identify queries that the package's frame says are *malformed* — questions
where giving a direct answer would violate the discipline's standards.

```json
{
  "id": "your_package:c_required_completeness_check",
  "label": "required completeness check",
  "rule": "What requirement must be met for the analysis to be valid.",
  "severity": "high",
  "blocks_answer": true,
  "applies_to": ["query types this constraint applies to"],
  "trigger_cues": ["natural-language phrasings that should fire the constraint"],
  "related_clusters": [],
  "repair": "Concrete guidance on how to make the query answerable."
}
```

Discipline note: the `repair` field must contain *concrete, actionable guidance*
when `blocks_answer: true`. The user who hits this constraint needs a way
forward, not just a refusal.

### 5. Write multiple trajectories with output_templates

A trajectory is a named reasoning path. Different queries should fire
different trajectories.

```json
{
  "id": "your_package:tr_some_reasoning_path",
  "label": "some reasoning path",
  "description": "What kind of query this trajectory handles.",
  "trigger": {
    "cues": ["query phrasings that should fire this trajectory"]
  },
  "path": [
    "your_package:k_first_cluster",
    "your_package:k_second_cluster",
    "your_package:k_third_cluster"
  ],
  "output_template": [
    "First step of the response",
    "Second step",
    "Third step",
    "Acknowledge what the constraint refused, if any"
  ],
  "constraints": ["your_package:c_required_completeness_check"],
  "branch_of": null
}
```

If two trajectories share the same trigger cues, retrieval is ambiguous. Each
trajectory should have its own discriminating triggers.

### 6. Cross-package relations with substantive notes

Avoid template relations like `frame_limit → all_packages`. Real cross-package
relations identify a specific other package and explain in domain terms what
the relationship is.

```json
{
  "id": "your_package:rel_to_other_package",
  "source": "your_package",
  "target": "other_package",
  "type": "complements",
  "note": "Concrete explanation in domain terms of how the two packages relate.",
  "retrieval_behavior": "what the engine should do when both activate",
  "examples": ["queries that exercise this relation"]
}
```

### 7. Write tests with full expected_* fields

Each test should specify what the engine is expected to do. The tests are
mechanically run by `run_tests.py`.

```json
{
  "id": "your_package:test_descriptive_name",
  "input": "the query the user might ask",
  "expected_activated_clusters": ["your_package:k_some_cluster"],
  "expected_constraints_triggered": ["your_package:c_some_constraint"],
  "expected_trajectory": "your_package:tr_some_trajectory",
  "expected_disposition": "partial_with_blocking_constraints",
  "description": "What this test verifies."
}
```

## Iterating: the cue-tightening loop

The biggest effort in package authoring is not writing the units — it's
tightening the cues so the engine activates the right clusters on natural-
language queries. The loop:

1. Write a test with a realistic user query.
2. Run `run_tests.py --package your_package`.
3. If the test fails, examine which clusters/constraints/trajectories the
   engine actually activated.
4. Look at your cues vs. the query language. The query usually contains words
   the cues don't match.
5. Add discriminating cues without diluting precision. Avoid bare "should" or
   "ought" — these match too many queries. Prefer "should we sacrifice X for Y"
   or "is it morally required to."
6. Re-run. Repeat until the test passes.

This is the core authoring activity. Plan to spend at least as much time on
this loop as on writing the initial content.

## Cross-package noise: a real failure mode

Constraints from one package can fire on cross-package cluster activation if
their `related_clusters` triggering is too aggressive. The convention in this
bundle is:

- Constraints fire on their own `trigger_cues` and `applies_to` matches only.
- `related_clusters` is informational metadata, not a triggering condition.

If you set `related_clusters` and rely on it to fire your constraint, you will
discover that your constraint fires on queries from other packages that share
a cluster activation. Avoid this. Use specific trigger_cues.

## Verification

Before considering a package ready:

```bash
python3 validate_bundle.py --strict --package your_package
python3 run_tests.py --package your_package
```

Both must exit 0. Then run the full bundle to verify your package didn't break
anything else:

```bash
make verify
```

If everything passes, update `PROVENANCE.json` with your new package's tier and
anchor list, and submit.

## Common mistakes

- **Bare modal verbs as cues**: "should", "ought", "must". These match too many
  queries. Prefer specific phrases.
- **`related_clusters` as triggering condition**: causes cross-package noise.
- **Self-referential anchors at focused tier**: the schema validator does not
  catch this; it's caught by the `PROVENANCE.json` audit. Anchors at focused
  tier must cite external sources.
- **`blocks_answer: true` without a concrete `repair` field**: the validator
  flags this as an error.
- **Testing only happy-path queries**: include tests for out-of-frame queries
  (expected_activated_clusters: []) and for queries that should fire blocking
  constraints (expected_disposition: "partial_with_blocking_constraints").
- **Treating units as topic labels**: a unit is an authored claim with a
  source citation, not just a heading. If a unit's definition is just a
  rephrasing of its label, you have a label, not a unit.
