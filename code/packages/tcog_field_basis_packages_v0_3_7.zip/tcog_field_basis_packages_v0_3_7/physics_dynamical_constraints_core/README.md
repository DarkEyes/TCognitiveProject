# Physics and Dynamical Constraints Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core state variables, conservation, dynamics, equilibrium, stability, scale, noise, and idealization principles for TCog basis-package retrieval and reasoning.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`physics_dynamical_constraints_core:tr_core` — dynamical constraint trajectory
