# Statistics Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core statistical reasoning principles for variation, sampling, uncertainty, causal caution, base rates, bias, measurement, model assumptions, overfitting, and practical significance.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`statistics_core:tr_core` — statistical inference trajectory
