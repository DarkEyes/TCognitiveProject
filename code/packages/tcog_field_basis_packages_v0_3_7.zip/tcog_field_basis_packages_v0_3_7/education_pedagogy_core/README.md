# Education and Pedagogy Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core scaffolding, prerequisites, misconception, practice, transfer, and trajectory compilation principles for TCog basis-package retrieval and reasoning.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`education_pedagogy_core:tr_core` — learning diagnosis trajectory
