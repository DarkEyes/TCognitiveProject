# causal_inference_and_explanation_core v1.1.0

A TCog basis package: causal inference machinery integrated with the philosophy of explanation.

**v1.1.0 changelog (additive):** added g-methods, Granger causality (with explicit non-causation warning), Bradford Hill criteria, causal discovery / structure learning, Reichenbach's common cause principle, confounding (as concept), selection bias (distinct from collider bias), external validity / transportability, ideal intervention / manipulability, DAG misspecification, Hempel's I-S model, Wright vs Cummins functional accounts, van Fraassen's erotetic theory, asymmetry of explanation, mathematical / modal explanation. Plus 4 new constraints, 3 new cross-package relations, 15 new tests, 11 new covers entries.

## Why these in one package

Causal inference is one species of explanation, not a separate domain. Pearl's interventionist account *is* a theory of causal explanation; Hernán-Robins' epidemiological causal inference *is* methodology for producing explanatorily-adequate causal claims. The non-causal explanation types (mechanistic, functional, structural, statistical, intentional, narrative, unifying, mathematical/modal) are typically defined against the causal type. Failure modes overlap: a "just-so story" is often a hidden causal claim presented without the inferential machinery to support it.

Splitting causal inference from explanation creates a false boundary the literature itself doesn't respect. This package keeps them together so the explanatory framework and the inferential machinery share vocabulary, criteria, and trajectories.

## What this package owns

- The structure of explanation (explanans/explanandum, contrastive structure, D-N model and its problems, the pragmatic turn, van Fraassen's erotetic theory, asymmetry of explanation)
- The taxonomy of explanation types (causal, mechanistic, functional, teleological, structural, statistical, intentional, historical/narrative, unifying, mathematical/modal — plus Hempel's I-S model and Wright/Cummins on function)
- Criteria for explanatory quality (power, scope, depth, parsimony, unification, robustness, IBE, loveliness vs likeliness)
- Concepts of causation (cause vs correlation, Lewis counterfactual, Woodward interventionist, ideal intervention/manipulability, Reichenbach common cause, type vs token, INUS, transitivity failures, mechanism vs effect, causal pluralism, **Granger causality and why it is not causation**)
- Pearl's causal DAG framework (DAG, SCM, do-operator, three rungs, d-separation, backdoor, frontdoor, do-calculus, collider bias, **confounding, selection bias, DAG misspecification**)
- Rubin's potential outcomes framework (potential outcomes, ATE/ATT/CATE, SUTVA, ignorability, positivity, consistency, propensity scores)
- Identification strategies (RCT, IV, RDD, DiD, synthetic control, matching, mediation, sensitivity analysis, negative controls, natural experiments, **g-methods, causal discovery, Bradford Hill criteria, transportability**)
- Mechanistic explanation in the philosophy-of-science sense (MDC entities-and-activities, decomposition, levels, schemas, constitutive relevance)
- Standard explanatory failure modes (just-so story, ad hoc rescue, circular explanation, redescription, conflations, narrative fit)
- Framework comparison (Pearl vs Rubin, mechanistic vs unificationist, interventionist vs counterfactual)

## What this package does NOT own

- Domain-specific causal claims: a claim about drug efficacy needs `medicine_diagnostic_safety_core`; this package supplies the inferential framework that the clinical claim must meet.
- Reaction mechanism in chemistry: `chemistry_interactions_core` owns the chemistry-specific use of "mechanism".
- Mechanism design in economics/operations research: `operations_research_decision_core` owns that distinct concept.
- Statistical estimation theory: `probability_stats_core` owns frequentist and Bayesian estimation; this package uses those results in service of causal identification.
- Hypothesis testing: `statistics_core` owns hypothesis testing; this package uses it for conditional-independence tests in causal discovery.
- Time-series forecasting and ARIMA-style modeling: this package handles the causal interpretation of time series (Granger, g-methods) but not the forecasting machinery itself.
- Research design machinery generally: `scientific_methodology_core` owns research-design and the slogan "correlation is not causation"; this package supplies the formal machinery that turns the slogan into operational discipline.

## Coverage

| Element | Count |
|---|---|
| Clusters | 10 |
| Units | 99 |
| Constraints | 14 |
| Transitions | 11 |
| Trajectories | 5 |
| Relations | 14 |
| Tests | 42 |
| Covers entries | 37 |

## Clusters

1. **k_what_explanation_is** (9 units) — explanans/explanandum, description vs explanation, contrastive structure, D-N model, pragmatic turn, why-question structure, explanation vs prediction, **erotetic theory (van Fraassen), asymmetry of explanation**
2. **k_types_of_explanation** (12 units) — causal, mechanistic, functional, teleological, structural, statistical, intentional, historical/narrative, unifying, **Hempel I-S model, Wright vs Cummins functional, mathematical/modal**
3. **k_explanatory_quality** (10 units) — power, scope, depth, parsimony, unification, predictive vs accommodating, robustness, IBE, loveliness vs likeliness, dependency
4. **k_causation_concepts** (11 units) — cause vs correlation, counterfactual (Lewis), interventionist (Woodward), type vs token, INUS, transitivity, mechanism vs effect, causal pluralism, **Granger causality, Reichenbach common cause, ideal intervention**
5. **k_causal_dag_framework** (13 units) — DAG, SCM, do-operator, intervention vs observation, three rungs, d-separation, backdoor, frontdoor, do-calculus, collider bias, **confounding, selection bias, DAG misspecification**
6. **k_potential_outcomes_framework** (9 units) — potential outcomes, fundamental problem, ATE/ATT/CATE, heterogeneity, SUTVA, ignorability, positivity, consistency, propensity score
7. **k_identification_strategies** (14 units) — RCT, IV, RDD, DiD, synthetic control, matching, mediation, sensitivity analysis, negative control, natural experiment, **g-methods, Bradford Hill criteria, causal discovery, external validity / transportability**
8. **k_mechanism** (7 units) — MDC definition, decomposition, levels, schema, constitutive relevance, mechanism required-or-not, phenomenal vs mechanistic
9. **k_explanatory_failure_modes** (10 units) — just-so, ad hoc rescue, circular, redescription, conflations (correlation/causation, mechanism/cause, function/purpose), Texas sharpshooter, regress, narrative fit
10. **k_framework_comparison** (4 units) — Pearl vs Rubin, mechanistic vs unificationist, interventionist vs counterfactual, when to use which

## Constraints

- `c_causal_claim_requires_identification_strategy` (admissibility, high)
- `c_mechanism_claim_requires_entity_activity_specification` (admissibility, medium)
- `c_functional_explanation_requires_role_specification` (admissibility, medium)
- `c_counterfactual_claim_requires_alternative` (admissibility, medium)
- `c_interventional_must_distinguish_from_associational` (scope, high)
- `c_just_so_story_check` (admissibility, medium)
- `c_propensity_score_requires_overlap_check` (admissibility, high)
- `c_iv_requires_exclusion_restriction` (admissibility, high)
- `c_did_requires_parallel_trends_check` (admissibility, high)
- `c_three_rungs_question_must_match_method` (scope, medium)
- **`c_dag_edges_require_substantive_justification` (admissibility, high)** — new in v1.1
- **`c_g_methods_require_sequential_exchangeability` (admissibility, high)** — new in v1.1
- **`c_transportability_requires_target_specification` (scope, medium)** — new in v1.1
- **`c_granger_not_actual_causation` (scope, high)** — new in v1.1; explicitly catches Granger-causality results being interpreted as causation

All constraints are non-blocking (severity medium/high but `blocks_answer: false`). The package surfaces caveats and repair questions; it does not gate answers.

## Trajectories

- `tr_evaluate_causal_claim` — claim → rung → data type → identification strategy → assumptions → threats → sensitivity → verdict
- `tr_appraise_explanation_quality` — type → explanandum → quality criteria → failure modes → IBE comparison → verdict
- `tr_pearl_workflow` — DAG → estimand → backdoor/frontdoor → do-calculus → estimation → sensitivity
- `tr_rubin_workflow` — define treatment → estimand → ignorability → positivity → estimator → sensitivity
- `tr_choose_explanation_type` — explanandum → goal → type → compatibility check → deliver

## Cross-package relations (14)

- `extends` `scientific_methodology_core`'s correlation-is-not-causation principle with the causal-inference machinery
- `complements` `probability_stats_core`'s decision theory and `scientific_methodology_core`'s evidence-and-inference and research-design
- `uses` `graph_theory_core`'s directed-graph machinery; `statistics_core`'s hypothesis testing (for causal discovery); `probability_stats_core`'s conditional probability (for g-methods)
- `scope_distinguishes` from `chemistry_interactions_core`'s reaction-mechanism and `operations_research_decision_core`'s mechanism-design
- `supports` `medicine_diagnostic_safety_core`'s differential diagnosis, `statistics_core`'s observational studies, `history_path_dependence_core`'s counterfactual reasoning

## Source documents (16)

Causal inference: Pearl (Causality 2e, Book of Why), Hernán-Robins (What If), Imbens-Rubin (Causal Inference for Statistics), Morgan-Winship (Counterfactuals and Causal Inference 2e), Angrist-Pischke (Mostly Harmless Econometrics).

Philosophy of explanation: Salmon (Scientific Explanation; Four Decades), Lipton (IBE 2e), Strevens (Depth), Hempel (Aspects), Cartwright (Hunting Causes), Lewis (Causation 1973).

Mechanism: Machamer-Darden-Craver ("Thinking About Mechanisms"), Craver (Explaining the Brain).

Causation: Woodward (Making Things Happen).

All anchors are paraphrased excerpts ≤ 280 characters per the protocol.

## Verification

| Check | Result |
|---|---|
| Schema (v0.3.1) | 0 issues |
| Covers warnings | 0 |
| Internal tests | 42/42 |
| Constraints with malformed `blocks_answer` | 0 |

## Migration from v1.0.0

v1.1.0 is purely additive. All v1.0.0 ids and structures remain valid. New content added across existing clusters; no clusters renamed or removed; no breaking changes.
