# Management Execution Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core management-execution reasoning principles, organized as 7 deep clusters
anchored to canonical sources, for TCog basis-package retrieval and reasoning.

## Clusters
- `k_purpose_and_stakeholders` — Drucker, Freeman, Jensen-Meckling
- `k_strategy_and_fit` — Porter, Barney, Chandler
- `k_structure_and_coordination` — Mintzberg, Lawrence-Lorsch, Galbraith
- `k_culture_and_leading` — Schein, Barnard, Edmondson
- `k_metrics_and_control` — Anthony, Goodhart/Strathern, Kerr
- `k_execution_and_interfaces` — Bossidy-Charan, Galbraith, Nelson-Winter
- `k_learning_and_adaptation` — Argyris-Schön, March-Simon/Cyert-March, Kahneman

## Trajectories
- `tr_management_concept_intro` — for "what is X" queries
- `tr_diagnose_execution_failure` — for "project keeps slipping" queries
- `tr_evaluate_strategy_claim` — for "should we do X" queries
- `tr_design_a_metric` — branching off `tr_evaluate_strategy_claim` at
  `k_metrics_and_control`, for KPI/OKR/incentive-design questions

## Constraints
- `c_owner_process_metric_loop` — recommendation completeness (high)
- `c_strategy_fit_check` — strategy completeness (high)
- `c_metric_gaming_check` — Goodhart-aware metric design (high)
- `c_principal_agent_check` — agency-naïve recommendation guard (medium)
- `c_stakeholder_completeness_check` — shareholder-only framing guard (medium)
- `c_no_culture_handwave` — culture-as-explanation guard (medium)

## Cross-package relations
Complements: economics_core, psychology_core, political_science_governance_core,
systems_control_core, operations_research_decision_core, sociology_institutions_core.
Potential conflict: philosophy_ethics_core (stakeholder consequentialism vs broader
ethical theories).

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation
- not: a substitute for expert practitioner judgment

## Runtime use
Mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation
      → unit loading → constraint trigger check → trajectory match
      → frame-limit check → answer/state update
```

Semantic-augmented mode is allowed when cue coverage is insufficient.
