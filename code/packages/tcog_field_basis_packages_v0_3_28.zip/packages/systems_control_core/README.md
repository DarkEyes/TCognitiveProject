# Systems and Control Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core systems-and-control reasoning principles, organized as 7 deep clusters
anchored to canonical sources, for TCog basis-package retrieval. Cross-cutting
design threading classical control theory, cybernetics, and safety/system-
failure analysis through the existing 7-theme skeleton, with explicit Swiss-
cheese-vs-STAMP framing of safety.

## Clusters
- `k_system_boundary_and_state` — Kalman 1960, Astrom-Murray, Forrester 1961, Skogestad-Postlethwaite
- `k_observability_and_estimation` — Kalman 1960 (filter + general theory), Luenberger 1964, Astrom-Murray
- `k_feedback_changes_dynamics` — Black 1934, Nyquist 1932, Astrom-Murray
- `k_intervention_under_feedback` — Ashby 1956, Conant-Ashby 1970, Wiener 1948
- `k_stability_and_margins` — Lyapunov 1892, Khalil 2002, Skogestad-Postlethwaite, Astrom-Murray
- `k_system_dynamics_archetypes` — Forrester 1961, Sterman 2000, Senge 1990, Meadows 1999
- `k_failure_modes_and_safety` — Perrow 1984, Reason 1990, Leveson 2011

## Trajectories
- `tr_systems_concept_intro` — for "what is X" queries
- `tr_design_a_controller` — design path: boundary/state → observability → feedback → stability
- `tr_diagnose_intervention_failure` — cybernetic + system-dynamics path for ineffective interventions
- `tr_diagnose_safety_failure` — branches off tr_diagnose_intervention_failure at
  `k_intervention_under_feedback` for harmful (rather than ineffective) failures;
  goes through feedback → failure-modes/safety

## Constraints
- `c_system_boundary_declared` — system claims need declared boundary (high)
- `c_observability_check` — state-knowledge claims need observability (medium)
- `c_feedback_versus_open_loop_distinguished` — intervention claims need feedback structure (high)
- `c_stability_verified_before_performance` — performance claims need stability first (high)
- `c_full_system_effects_considered` — local-optimization claims need system-wide check (medium)
- `c_failure_modes_enumerated` — safety claims need failure-mode + control-structure analysis (medium)

## Cross-package relations
Internal: `rel_internal_swiss_cheese_vs_stamp` surfaces Reason's layered-defense and
Leveson's control-structure framings of safety as complementary frames.
Complements: physics_dynamical_constraints_core, operations_research_decision_core,
management_execution_core, medicine_diagnostic_safety_core,
computer_science_systems_core, economics_core, philosophy_ethics_core.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for
  systems/control/cybernetics/safety reasoning
- not: a substitute for domain expertise in any specific engineered system
