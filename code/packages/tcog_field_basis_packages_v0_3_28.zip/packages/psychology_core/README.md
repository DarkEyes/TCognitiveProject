# Psychology Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core psychological reasoning principles for appraisal, motivation, emotion, self-coherence, stress, attachment, and reconstructive memory.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`psychology_core:tr_core` — psychological appraisal trajectory
