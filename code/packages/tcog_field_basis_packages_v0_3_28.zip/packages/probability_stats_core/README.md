# probability_stats_core v1.0.0 — TCog basis package

**Major content revision and rename of `probability_stats_foundations_core` v0.2.0.** The "foundations" qualifier is dropped because the package no longer stops at probability foundations — it now covers the full statistical inference machinery (frequentist, Bayesian, regression, resampling, model evaluation).

This version was produced in response to the observation that the v0.2.0 package's bridge cluster `k_from_probability_to_inference` pointed at inference content that didn't exist anywhere in the package set. Hypothesis testing had only one introductory unit (in `scientific_methodology_core`); confidence interval and effect size were glued together in a single sciMethod unit; Bayesian inference, MCMC, ANOVA, t-test, F-test, MLE, posterior, prior, and the normal distribution itself had no anchored standalone units anywhere.

## What changed in v1.0.0

### Package identity

- `package_id` changes from `probability_stats_foundations_core` → `probability_stats_core`. **This is a breaking change** for any package that referenced the old prefix in cross-references; cross-package references must be updated. (No other shipped package currently references this prefix, so the cost is contained.)
- `version` 0.2.0 → 1.0.0 (major bump per semver, since the rename and substantive content changes break existing IDs)
- `protocol_version` 0.3 → 0.3.1

### Coverage

| Layer | v0.2.0 | v1.0.0 |
|---|---|---|
| Units | 25 | **138** |
| Clusters | 8 | **16** |
| Constraints | 6 | **16** |
| Transitions | 9 | **21** |
| Trajectories | 4 | **9** |
| Tests | 31 | **59** |
| Covers entries | 16 | **104** |

### New clusters (8)

| Cluster | Members | What it does |
|---|---|---|
| `k_frequentist_inference` | 25 | Hypothesis testing, p-values, confidence intervals, type I/II errors, power, t/z/F/chi-squared/ANOVA tests, nonparametric tests, multiple comparisons, effect size, Cohen's d |
| `k_estimation_theory` | 10 | MLE, method of moments, OLS, unbiasedness, efficiency, consistency, sufficient statistic, Fisher information, Cramér-Rao bound, asymptotic normality |
| `k_bayesian_inference` | 19 | The Bayesian framework itself, prior, posterior, marginal likelihood, conjugate prior, uninformative prior, Jeffreys prior, credible interval, HPD interval, posterior mean/median, MAP, posterior/prior predictive distributions, Bayes factor, hierarchical Bayesian model, empirical Bayes, subjective vs objective prior |
| `k_bayesian_computation` | 12 | MCMC, Metropolis-Hastings, Gibbs, HMC, NUTS, variational inference, mean-field VI, Laplace approximation, importance sampling, rejection sampling, MCMC diagnostics, posterior sampling vs optimization |
| `k_paradigm_comparison_and_decision_theory` | 9 | Frequentist vs Bayesian, likelihood principle, stopping rule paradox, calibration, decision theory, loss function, admissibility, minimax estimator, Bayes risk |
| `k_regression_and_linear_models` | 15 | Simple/multiple linear regression, OLS, GLMs, statistical logistic regression, residuals, R-squared, homoscedasticity, normality of residuals, multicollinearity, regression diagnostics, Bayesian linear/logistic regression, mixed effects, fixed vs random effects |
| `k_resampling_and_modern_inference` | 4 | Bootstrap, jackknife, statistical cross-validation, permutation inference |
| `k_bayesian_model_evaluation` | 4 | WAIC, LOO-CV, DIC, Bayesian model averaging |

### Distribution units (15 new)

`k_distributions_describe_outcomes` was extended from 5 members to **20**, adding standalone anchored units for: normal, Bernoulli, binomial, Poisson, uniform, exponential, geometric, negative binomial, gamma, beta, chi-squared, Student's t, F, multivariate normal, Dirichlet. Previously these were only mentioned inside `u_common_distributions` (a catalog unit). Now each has its own anchored unit with definition and source.

### Source documents (13 declared)

- Wasserman, *All of Statistics* (Springer, 2004)
- Casella & Berger, *Statistical Inference*, 2e (Duxbury, 2002)
- Gelman, Carlin, Stern, Dunson, Vehtari, Rubin, *Bayesian Data Analysis*, 3e (CRC, 2013)
- Robert, *The Bayesian Choice*, 2e (Springer, 2007)
- Cohen, *Statistical Power Analysis for the Behavioral Sciences*, 2e (Erlbaum, 1988)
- Brooks, Gelman, Jones, Meng (eds.), *Handbook of Markov Chain Monte Carlo* (CRC, 2011)
- Hastie, Tibshirani, Friedman, *Elements of Statistical Learning*, 2e (Springer, 2009)
- Blei, Kucukelbir, McAuliffe, "Variational Inference: A Review for Statisticians" (JASA, 2017)
- DeGroot & Schervish, *Probability and Statistics*, 4e (Pearson, 2012)
- Ross, *A First Course in Probability*, 10e (Pearson, 2018)
- Grimmett & Stirzaker, *Probability and Random Processes*, 4e (OUP, 2020)
- (plus axiomatic anchors for pedagogical primitives)

### New constraints (10)

- `c_p_value_misinterpretation` — p-value is not P(H0|data); claims about it must respect the conditional direction
- `c_significance_vs_effect_size` — statistical significance does not imply practical importance; report effect size with significance
- `c_confidence_interval_misinterpretation` — confidence interval is a procedure with long-run coverage, not a posterior probability
- `c_multiple_testing_correction` — multiple tests without correction inflate family-wise error rate
- `c_test_assumptions_check` — every parametric test requires assumption checking; assumption violations affect validity
- `c_prior_must_be_declared` — a Bayesian conclusion is incomplete without disclosure of the prior
- `c_prior_sensitivity` — Bayesian results that depend strongly on prior require sensitivity analysis
- `c_mcmc_diagnostics_required` — an MCMC inference is incomplete without convergence diagnostics
- `c_regression_diagnostics_required` — a linear regression analysis is incomplete without residual diagnostics
- `c_paradigm_declaration` — when both frequentist and Bayesian framings are possible, declare which paradigm is in use

### New trajectories (5)

- `tr_frequentist_hypothesis_testing_workflow` — formulate hypotheses → choose test → check assumptions → compute statistic → compute p-value → interpret with effect size
- `tr_bayesian_inference_workflow` — specify prior → likelihood → posterior → diagnostics → posterior predictive checks → reporting with credible intervals
- `tr_estimation_workflow` — specify estimator → evaluate properties (bias, variance, consistency) → compute standard error → confidence interval
- `tr_regression_analysis` — specify model → fit → residual diagnostics → influential observations → coefficient interpretation
- `tr_paradigm_choice` — when query admits both paradigms, surface the choice rather than collapsing it

### Covers manifest declaration (104 primary entries)

Most entries are inference-machinery primaries that didn't exist anywhere before this revision. Selected highlights:

```json
{"concept": "Bayesian inference", "scope": "prior-to-posterior updating framework"},
{"concept": "frequentist inference", "scope": "long-run-frequency framework"},
{"concept": "hypothesis testing", "scope": "frequentist inference framework"},
{"concept": "p-value", "scope": "tail probability under null"},
{"concept": "confidence interval", "scope": "frequentist interval estimate"},
{"concept": "credible interval", "scope": "Bayesian posterior interval"},
{"concept": "normal distribution", "scope": "Gaussian on the real line"},
{"concept": "ANOVA", "scope": "multi-group mean comparison"},
{"concept": "t-test", "scope": "frequentist mean comparison"},
{"concept": "F-test", "scope": "variance-ratio test family"},
{"concept": "MCMC", "scope": "posterior sampling family"},
{"concept": "maximum likelihood estimation", "scope": "likelihood-maximizing estimator"},
{"concept": "Bayes factor", "scope": "Bayesian model comparison statistic"},
{"concept": "frequentist vs Bayesian", "scope": "paradigm comparison"}
```

## Cross-package overlap discipline

`scientific_methodology_core` and `statistics_core` retain all their existing units. **No moves, no deletions.** The architecture is multi-package coverage with distinguishing scope qualifiers.

Concepts the user might ask about that are now legitimately covered by multiple packages:

| Concept | sciMethod | statistics_core | probability_stats_core |
|---|---|---|---|
| `hypothesis testing` | (intro framing — methodology in research design) | (treated through significance principle) | **machinery (frequentist inference framework)** |
| `effect size` | (intro framing — methodology in research design) | (treated through significance principle) | **machinery (magnitude separate from significance)** |
| `confidence interval` | (intro framing — methodology in research design) | (treated through uncertainty quantification) | **machinery (frequentist interval estimate)** |
| `multiple testing problem` | (intro framing — research integrity threat) | — | **machinery (family-wise error inflation)** |
| `selection bias` | (research design threat) | (missing-cases principle) | (not covered — distinct from `sampling bias`) |
| `correlation is not causation` | (foundation of causal inference) | (statistical reasoning principle) | — |
| `overfitting` | — | (in-sample vs out-of-sample principle) | — |
| `sampling bias` | — | (broader sampling treatment) | (estimator-distortion treatment) |

This is the productive-overlap pattern the architecture was designed for. A user query "what is hypothesis testing?" surfaces all three packages with their respective scope qualifiers; the user (or the LLM in the retrieval pipeline) picks the framing that matches the question's intent.

**sciMethod and statistics_core covers updates are still pending** — they need new entries with the `methodology in research design` and `statistical reasoning principle` scopes for `hypothesis testing`, `confidence interval`, `effect size`, `multiple testing`. Those revisions are deliberately deferred to a separate batch to keep this PR focused on the major content addition.

## Verification

| Suite | v0.2.0 | v1.0.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | **0 errors** |
| Covers validation (warnings) | 0 | **0 warnings** |
| Internal `tests.jsonl` | 31/31 | **59/59** (all preserved + 28 new) |
| Cross-package routing simulation | clean | **clean** — every previously-homeless inference concept now routes to PS; productive overlaps with sciMethod, statistics_core, ml_core preserved |

## All 16 clusters

| Cluster | Members |
|---|---|
| `k_probability_is_a_measure_on_a_sample_space` | 4 |
| `k_random_variables_are_functions` | 1 |
| `k_distributions_describe_outcomes` | 20 |
| `k_expectation_summarizes_distribution` | 3 |
| `k_conditional_probability_and_independence` | 4 |
| `k_limit_theorems_link_data_to_distribution` | 3 |
| `k_joint_distributions_capture_dependence` | 3 |
| `k_from_probability_to_inference` | 3 (bridge) |
| `k_frequentist_inference` | 25 |
| `k_estimation_theory` | 10 |
| `k_bayesian_inference` | 19 |
| `k_bayesian_computation` | 12 |
| `k_paradigm_comparison_and_decision_theory` | 9 |
| `k_regression_and_linear_models` | 15 |
| `k_resampling_and_modern_inference` | 4 |
| `k_bayesian_model_evaluation` | 4 |

## Pending follow-up work

1. **sciMethod covers update** (additive) — add covers entries for `hypothesis testing`, `effect size`, `confidence interval`, `multiple testing problem` with scope qualifier `"methodology in research design"`. Existing units stay.
2. **statistics_core covers update** (additive) — add covers entries for `effect size` with scope qualifier `"vs statistical significance principle"`. Existing units stay.
3. **Combinatorics and calculus packages** — covers rollout (the originally-planned next batch before this content revision)
