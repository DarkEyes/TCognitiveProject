# law_practice_core

Focused-tier package for general legal-reasoning information. Anchored throughout to
real primary and secondary sources.

## What this package does

- Distinguishes sources of legal authority (constitution, statute, regulation, common law)
- Walks through common-law reasoning by precedent and analogy
- Surfaces the legality/morality distinction with Hart, Fuller, Holmes, and Dworkin
- Covers the basic structure of contracts, negligence, and constitutional criminal procedure
- Refuses to substitute for licensed counsel: blocks specific advice, blocks unjurisdictioned
  legality questions

## What this package does NOT do

- Specific advice in actual or potential legal matters (blocked by `c_no_legal_advice`)
- Answers about whether a specific act is legal without jurisdiction (blocked by
  `c_jurisdiction_required`)
- Predictions of how a specific court will rule (`c_no_outcome_prediction`)
- Substitution for the lawyer-client relationship in any form

## Architectural moves demonstrated

This package showcases two architectural moves that are difficult to demonstrate
in a pure LLM:

1. **Jurisdiction discipline.** The constraint `c_jurisdiction_required` fires on
   "is X legal" queries lacking jurisdictional context, blocking a substantive answer
   and demanding the user specify location. This prevents the common LLM failure of
   confidently stating, e.g., recording-consent rules without noting state-by-state
   variation.

2. **Legality/morality separation.** The constraint `c_separate_legality_from_morality`
   fires on slides like "X was legal so it was fine" or "Y is illegal so it's wrong."
   The Hart/Fuller debate is canonical for the framing.

## Anchors

13 units, 13 anchors. Cases: Marbury (1803), Erie (1938), Carroll Towing (1947),
Miranda (1966), Katz (1967), Gideon (1963). Texts: Hart (1961), Fuller (1964),
Dworkin (1986), Holmes (1897), Llewellyn (1930), Restatement (2d) of Contracts (1981),
ABA Model Rule 5.5.

## Constraints

- `c_jurisdiction_required` (critical, **blocking**)
- `c_no_legal_advice` (critical, **blocking**)
- `c_separate_legality_from_morality` (high)
- `c_acknowledge_jurisdiction_variation` (medium)
- `c_no_outcome_prediction` (high)

## Trajectories

- `tr_legal_concept_intro` — for "what is X" doctrinal queries
- `tr_specific_situation` — for situational queries; routes through refusal
- `tr_legal_theory` — for jurisprudence questions

## Cross-package interactions

- With `philosophy_ethics_core`: legality vs. morality is the canonical cross-frame
  case. Both packages activate; `c_surface_value_conflict` (philosophy) and
  `c_separate_legality_from_morality` (law) fire together.
- With `economics_core`: law-and-economics framing (Hand formula, contract efficiency).
- With `counselling_practice_core`: distinguish a person's legal predicament from
  their emotional one; both packages may activate but address different facets.
