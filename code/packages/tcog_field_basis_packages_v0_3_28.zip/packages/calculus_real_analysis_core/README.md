# calculus_real_analysis_core v0.2.0 — TCog basis package

**Minor upgrade of v0.1.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus one feature alias on a load-bearing unit. All v0.1.0 substantive content (7 clusters, 28 units, 7 constraints, 12 transitions, 5 trajectories, 7 relations, 43 tests) preserved unchanged.

## What changed in v0.2.0

### Covers manifest declaration (12 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "calculus", "scope": "discipline of differentiation and integration"},
    {"concept": "real analysis", "scope": "rigorous foundations of calculus"},
    {"concept": "limit", "scope": "epsilon-delta approach to value"},
    {"concept": "continuity", "scope": "three-condition pointwise continuity"},
    {"concept": "derivative", "scope": "instantaneous rate of change"},
    {"concept": "differentiation", "scope": "computing derivatives"},
    {"concept": "integral", "scope": "Riemann integral as accumulation"},
    {"concept": "integration", "scope": "computing integrals"},
    {"concept": "Taylor series", "scope": "function as power series"},
    {"concept": "fundamental theorem of calculus", "scope": "differentiation-integration duality"},
    {"concept": "convergence", "scope": "sequence and series convergence"},
    {"concept": "real numbers", "scope": "complete ordered field"}
  ],
  "secondary_auto_indexed": true
}
```

### Cross-package handoff (intentional)

This package does **not** claim `function`. Calculus uses functions extensively as the objects of differentiation and integration, and the package contains plenty of unit content using functions. But the foundational concept "what is a function?" belongs to `set_theory_logic_core` (set-theoretic mapping). Calculus's specific contribution would be more like "real-valued function" or "continuous function" — these are auto-indexed via `continuity` rather than headlined.

This is the same hand-off pattern combinatorics uses with graph_theory_core: claim what you anchor as primary, hand off shared primitives to the package whose framing matches the foundational concept.

### Cross-package surface coincidences (productive but not "owned")

The cross-package routing simulation reveals several substring-matching artifacts that are productive rather than problematic:

- **`limit`** also surfaces `central limit theorem` from `probability_stats_core` — different concept (sequence/function limit vs CLT), but a user asking "limit" in a probabilistic context might want both
- **`function`** surfaces in three packages with different scopes (STL: set-theoretic mapping; PS: `loss function`; COMB: `generating function`) — useful for disambiguation

The covers framework's substring matching is doing what it was designed to do: surface related concepts across packages so the LLM in the retrieval pipeline can disambiguate based on context.

### What's NOT in covers (deliberate)

- **`function`** — STL owns; calculus uses but doesn't anchor as primary
- **Specialized theorems**: L'Hôpital's rule, mean value theorem (MVT), intermediate value theorem (IVT), extreme value theorem (EVT) — auto-indexed
- **Real-analysis primitives**: supremum, infimum, Archimedean property, density of rationals — auto-indexed under `real numbers` and `real analysis`
- **Limits sub-concepts**: limit at infinity, indeterminate forms, limit laws — auto-indexed under `limit`
- **Convergence sub-types**: absolute convergence, conditional convergence — auto-indexed under `convergence`
- **Differentiation sub-concepts**: critical points, local extrema — auto-indexed under `differentiation`
- **Integration sub-concepts**: Riemann integral specifically (auto-indexed under `integral`), integration by substitution/parts, improper integrals — auto-indexed
- **`epsilon-delta`** — pedagogical phrasing of `limit`; auto-indexed
- **`differentiability`** — auto-indexed under `derivative`

### Feature alias added (1 load-bearing unit)

| Unit | Features added |
|---|---|
| `u_real_numbers_field` | `real analysis` (anchors the discipline-overview entry) |

## Verification

| Suite | v0.1.0 | v0.2.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 43/43 | **43/43** (preserved) |
| Cross-package routing simulation | n/a | clean — `function` correctly routes to STL alone (calculus deliberately not claiming); `limit` and `function` surface productive cross-package coincidences |

## Coverage (unchanged from v0.1.0)

7 clusters · 28 units · 7 constraints · 12 transitions · 5 trajectories · 7 relations · 43 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "calculus_real_analysis_core",
  "base_version": "0.1.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-03",
  "covers_added": true,
  "refinements": 1,
  "summary": "Added covers manifest (12 primary entries) and 1 feature-alias addition. Hand-off to set_theory_logic_core preserved (function is STL's, not calculus's, even though calculus uses functions extensively)."
}
```
