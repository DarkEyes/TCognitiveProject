# Sociology and Institutions Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core sociological principles for TCog basis-package retrieval. Cross-cutting design
threading classical canon, mid-20th-c interactionism, Bourdieu, new institutionalism,
and intersectionality.

## Clusters
- `k_behavior_is_socially_situated` — Goffman 1959, Garfinkel 1967, Bourdieu 1977/1990
- `k_norms_regulate_without_law` — Bicchieri 2006/2017, Elster 1989/2007, Ostrom 1990
- `k_institutions_reproduce_patterns` — DiMaggio-Powell 1983/1991 + Meyer-Rowan 1977, North 1990, Coleman 1990
- `k_meaning_is_shared_and_contested` — Berger-Luckmann 1966, Geertz 1973, Swidler 1986
- `k_status_shapes_voice` — Weber 1922, Bourdieu 1984, Ridgeway 2011/2014
- `k_identity_shapes_admissibility` — Crenshaw 1989/1991, Hill Collins 1990, Tajfel-Turner 1971/1979
- `k_ritual_stabilizes_coherence` — Durkheim 1912, Collins 2004, Douglas 1966

## Trajectories
- `tr_concept_intro` — for "what is X" queries
- `tr_analyze_a_social_phenomenon` — full walkthrough across all 6 themes
- `tr_diagnose_inequality` — branches off tr_analyze_a_social_phenomenon at k_status_shapes_voice
- `tr_analyze_an_institution` — institutional persistence with methodological-frame surfacing

## Constraints
- `c_specify_population_or_context` (low)
- `c_consider_methodological_frame` (medium)
- `c_distinguish_norms_from_laws` (medium)
- `c_consider_intersectionality` (medium)
- `c_avoid_psychological_reduction_of_inequality` (medium)
- `c_specify_construction_or_essence` (low)

## Cross-package relations
Internal: `rel_internal_methodological_individualism_vs_holism` surfaces Coleman 1990
methodological individualism (Coleman's Boat, analytical sociology, ABM, computational
social science) vs Bourdieu 1977/1990 methodological holism (habitus, field, cultural
capital, following Durkheim 1895) — the canonical contemporary methodological
disagreement in sociology, directly relevant to AI bridge questions about agent-based
vs structural-critique framings of social phenomena.

Complements: political_science_governance_core, economics_core, psychology_core,
philosophy_ethics_core, communication_rhetoric_core, history_path_dependence_core,
management_execution_core, law_practice_core.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
