# graph_theory_core v0.3.1 — TCog basis package

**Patch upgrade of v0.3.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on three load-bearing units to align covers entries with unit features for validation cleanliness. All v0.3.0 substantive content (14 clusters, 78 units, 17 constraints, 19 transitions, 10 trajectories, 12 relations, 36 tests) preserved unchanged.

## What changed in v0.3.1

### Covers manifest declaration (17 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "graph theory", "scope": "discipline of graph structures"},
    {"concept": "graph", "scope": "graph-theoretic objects"},
    {"concept": "directed graph", "scope": "digraph and orientation"},
    {"concept": "tree", "scope": "graph-theoretic acyclic connected"},
    {"concept": "spanning tree", "scope": "spanning acyclic subgraph"},
    {"concept": "directed acyclic graph", "scope": "DAG structure"},
    {"concept": "topological ordering", "scope": "DAG linearization"},
    {"concept": "bipartite graph", "scope": "two-colorable graphs"},
    {"concept": "planar graph", "scope": "planar embedding"},
    {"concept": "graph coloring", "scope": "vertex coloring"},
    {"concept": "chromatic number", "scope": "minimum coloring"},
    {"concept": "matching", "scope": "graph-theoretic pairing"},
    {"concept": "vertex cover", "scope": "covering vertices"},
    {"concept": "graph isomorphism", "scope": "structural equivalence"},
    {"concept": "shortest paths", "scope": "graph-theoretic distances"},
    {"concept": "network flow", "scope": "graph-theoretic flow theory"},
    {"concept": "max-flow min-cut", "scope": "duality theorem"}
  ],
  "secondary_auto_indexed": true
}
```

### Cross-package overlaps (intentional)

Three entries deliberately overlap with `algorithm_design_core`. The `scope` qualifier distinguishes the two packages' treatments:

| Concept | GT scope | algorithm_design_core scope |
|---|---|---|
| `shortest paths` | graph-theoretic distances | algorithmic Dijkstra Bellman-Ford |
| `network flow` | graph-theoretic flow theory | algorithmic max flow min cut |
| `max-flow min-cut` | duality theorem | (only in AD via `network flow`) |

A query "what is network flow?" surfaces both packages with distinguishing scopes. A query "what is the max-flow min-cut theorem?" surfaces only GT (since AD treats it under network flow). A query "implement max flow with the Ford-Fulkerson algorithm" goes to AD (algorithmic phrasing matches AD's cue-based routing).

### Notable scope choices

- **`tree`** scoped to "graph-theoretic acyclic connected" — does NOT claim binary search trees (those are `algorithm_design_core`'s `data_structures` territory) or family trees (the v0.3.0 negative cues already exclude those phrasings).
- **`graph theory` is in primary** as the discipline-overview entry — common umbrella search target.
- **`vertex`, `edge`, `degree`, `cycle`, `path`, `walk` are NOT in primary** — too granular; `secondary_auto_indexed` catches these via cluster/unit labels.
- **No `Eulerian path` / `Hamiltonian cycle` entries** — these are specific graph-theoretic results, not concept-defining; `secondary_auto_indexed` handles definitional queries on them.

### Cross-package overlaps with future packages (anticipated)

- **`graph`** likely also claimed by `combinatorics_discrete_structures_core` with scope "as combinatorial object" (when that package is updated). GT covers the deep graph-theoretic treatment; combinatorics covers basic graph definitions and counting.
- **`tree`** likely also claimed by `combinatorics_discrete_structures_core` (combinatorial trees, Catalan numbers).

### Feature aliases added (3 load-bearing units)

To make user-friendly covers entries match unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_graph` | `graph theory`, `graph-theoretic` |
| `u_topological_order` | `topological ordering` (in addition to existing `topological sort`) |
| `u_flow_network` | `network flow`, `flow network theory` |

The cluster and unit labels are unchanged — these are additive feature aliases that improve `secondary_auto_indexed` recall.

## Verification

| Suite | v0.3.0 | v0.3.1 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 36/36 | **36/36** (preserved) |
| Cross-package routing simulation (algorithm_design_core overlaps) | n/a | clean — overlapping concepts surface both packages with distinguishing scopes |

## Coverage (unchanged from v0.3.0)

14 clusters · 78 units · 17 constraints · 19 transitions · 10 trajectories · 12 cross-package relations · 36 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "graph_theory_core",
  "base_version": "0.3.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 3,
  "summary": "Added covers manifest (17 primary entries) and 3 feature-alias additions on load-bearing units."
}
```
