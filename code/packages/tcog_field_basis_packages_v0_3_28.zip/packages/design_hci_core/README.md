# Design and HCI Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core HCI / design principles for TCog basis-package retrieval. Cross-cutting
design threading foundational HCI canon, cognitive engineering, automation/
trust, and AI-interaction.

## Clusters
- `k_users_act_through_affordances` — Gibson 1979, Norman 1988+1999 (signifiers retraction)
- `k_visibility_shapes_action` — Nielsen 1994 #1 + #2, Koffka 1935 (Gestalt)
- `k_cognitive_load_matters` — Miller 1956, Cowan 2001, Hick 1952, Fitts 1954, Sweller 1988
- `k_errors_are_often_design_failures` — Reason 1990, Norman 1988 seven stages
- `k_feedback_guides_repair` — Norman gulfs 1988, Nielsen 1993+1994
- `k_trust_needs_inspectability` — Lee-See 2004, Parasuraman-Riley 1997, Bainbridge 1983, Endsley 1995, Maes 1994
- `k_next_action_should_be_legible` — Shneiderman 1983+2022, Nielsen 1994 #4 + #8, Tufte 1983

## Trajectories
- `tr_concept_intro` — for "what is X" queries about HCI concepts
- `tr_evaluate_a_design` — heuristic-walkthrough path: affordances → visibility → load → errors → feedback → next action
- `tr_diagnose_user_struggle` — branches off tr_evaluate_a_design at
  `k_visibility_shapes_action`; localizes failure (design-error reframe + Reason
  taxonomy + Norman seven stages + cognitive load + feedback-gulf identification)
- `tr_design_an_ai_interaction` — AI/automation design path: trust calibration → direct-manipulation-vs-agents framing → feedback → error/recovery

## Constraints
- `c_treat_user_errors_as_design_failures_first` — error claims need design-first analysis (high)
- `c_specify_feedback_at_design_time` — design claims need feedback specification (medium)
- `c_acknowledge_cognitive_load` — feature-add claims need cognitive-load consideration (medium)
- `c_calibrate_trust_to_capability` — AI/automation claims need trust calibration (high)
- `c_recoverability_for_consequential_actions` — destructive-action claims need recovery (medium)
- `c_distinguish_signifier_from_affordance` — affordance claims need Norman 1999 distinction (low)

## Cross-package relations
Internal: `rel_internal_direct_manipulation_vs_agents` surfaces Shneiderman's
direct-manipulation paradigm and Maes's agents-delegation paradigm as
complementary frames in the canonical AI-interaction disagreement (Shneiderman-
Maes 1997 IUI debate; Shneiderman 2022 *Human-Centered AI*). Directly relevant
to LLM interface design.
Complements: cognitive_science_core, psychology_core, education_pedagogy_core
(Sweller cognitive load shared), systems_control_core (trust in automation
shared), management_execution_core, communication_rhetoric_core,
computer_science_systems_core (with AI-interface bridge note).

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for HCI /
  design / interaction / trust-in-AI reasoning
- not: a substitute for hands-on user research; not for research-method
  'design', architectural / fashion design, 'intelligent design', or non-HCI
  'agents'
