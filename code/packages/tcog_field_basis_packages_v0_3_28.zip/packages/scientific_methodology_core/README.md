# scientific_methodology_core v0.2.0 — TCog basis package

**Minor upgrade of v0.1.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on seven load-bearing units to align covers entries with unit features for validation cleanliness. All v0.1.0 substantive content (9 clusters, 34 units, 8 constraints, 12 transitions, 5 trajectories, 9 relations, 49 tests) preserved unchanged.

## What changed in v0.2.0

### Covers manifest declaration (17 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "causal inference", "scope": "research design and identification"},
    {"concept": "experimental design", "scope": "controlled studies and RCTs"},
    {"concept": "randomized controlled trial", "scope": "gold-standard experiment"},
    {"concept": "observational study", "scope": "non-experimental designs"},
    {"concept": "confounding", "scope": "spurious causal claim"},
    {"concept": "selection bias", "scope": "observational research threat"},
    {"concept": "potential outcomes", "scope": "Rubin-Neyman causal framework"},
    {"concept": "do-calculus", "scope": "Pearl intervention algebra"},
    {"concept": "causal DAG", "scope": "Pearl causal graph"},
    {"concept": "instrumental variable", "scope": "quasi-experimental design"},
    {"concept": "regression discontinuity", "scope": "quasi-experimental design"},
    {"concept": "difference-in-differences", "scope": "quasi-experimental design"},
    {"concept": "external validity", "scope": "generalizability of findings"},
    {"concept": "replication", "scope": "empirical robustness"},
    {"concept": "p-hacking", "scope": "research integrity threat"},
    {"concept": "Simpson's paradox", "scope": "causal-not-statistical reversal"},
    {"concept": "counterfactual", "scope": "causal inference primitive"}
  ],
  "secondary_auto_indexed": true
}
```

### Cross-package overlaps (intentional and productive)

| Concept | This package's scope | Other package | Overlap status |
|---|---|---|---|
| `causal DAG` | Pearl causal graph (variables + causal edges) | `graph_theory_core` has `directed acyclic graph` scoped "DAG structure" | **Productive overlap** — same notation, different uses |
| `selection bias` | observational research threat | `ml_core` has separate `sampling bias` (different concept) | **Non-overlapping** — different concepts |
| `p-hacking` | research integrity threat | `ml_core` has `data snooping` (broader, ML-specific) | **Non-overlapping** — related but distinct |
| `replication` | empirical robustness | (no other package claims) | **No overlap** |

The `causal DAG` ↔ `directed acyclic graph` overlap is exactly the kind of productive disambiguation covers was designed for: same three-letter abbreviation, very different uses. A query "what is a causal DAG?" routes to sciMethod (Pearl framework). A query "what is a directed acyclic graph?" surfaces graph_theory_core (structural/algorithmic). A query "what is a DAG?" should surface both — and does, via covers (sciMethod) plus `secondary_auto_indexed` (GT's `u_dag` unit).

### Anticipated cross-package overlaps (with future packages)

When `probability_stats_foundations_core` is updated, multiple statistical concepts mentioned in this package's units will move to it as primary covers:

- `hypothesis testing` (this package mentions it as supporting material; not its home)
- `confidence interval` and `effect size` (same)
- `multiple testing problem` (same)

Probability concepts deliberately not claimed here so the future probability/statistics package can own them cleanly.

### What's NOT in covers (deliberate)

- **Probability/statistics**: `hypothesis testing`, `effect size`, `confidence interval`, `multiple testing` — supporting material here, primary in `probability_stats_foundations_core` (to come)
- **`internal validity`** — covered by `causal inference` umbrella; cluster handles via cue-based routing
- **`randomization`, `blinding`, `intention-to-treat`** — methods inside RCT scope; auto-indexed
- **`cohort study`, `case-control study`, `cross-sectional study`** as separate primary entries — too granular; auto-indexed under `observational study`
- **`publication bias`, `Berkson's bias`, `survivorship bias`** — auto-indexed under `selection bias`
- **`mediation`, `collider bias`, `backdoor criterion`** — auto-indexed via cluster content (Pearl framework)

### Feature aliases added (7 load-bearing units)

To make user-friendly covers entries match unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_randomized_controlled_trial` | `experimental design` |
| `u_randomization_role` | `experimental design method` |
| `u_cohort_study` | `observational study` |
| `u_case_control_study` | `observational study` |
| `u_cross_sectional_study` | `observational study` |
| `u_directed_acyclic_graph` | `causal DAG`, `causal graph` |
| `u_do_calculus_dag_framework` | `causal DAG framework` |

Each alias is a synonym actively used in research methodology contexts. Cluster and unit labels are unchanged — these are additive feature aliases.

## Verification

| Suite | v0.1.0 | v0.2.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 49/49 | **49/49** (preserved) |
| Cross-package routing simulation | n/a | clean — sciMethod claims its concepts; correctly does NOT claim Turing machine, overfitting, set theory, or probability/statistics topics |

## Coverage (unchanged from v0.1.0)

9 clusters · 34 units · 8 constraints · 12 transitions · 5 trajectories · 9 relations · 49 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "scientific_methodology_core",
  "base_version": "0.1.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 7,
  "summary": "Added covers manifest (17 primary entries) and 7 feature-alias additions on load-bearing units."
}
```
