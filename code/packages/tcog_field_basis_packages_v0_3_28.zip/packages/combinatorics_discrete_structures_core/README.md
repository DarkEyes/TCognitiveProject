# combinatorics_discrete_structures_core v0.3.1 — TCog basis package

**Patch upgrade of v0.3.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus one feature alias on a load-bearing unit. All v0.3.0 substantive content (14 clusters, 56 units, 17 constraints, 17 transitions, 10 trajectories, 12 relations, 36 tests) preserved unchanged.

## What changed in v0.3.1

### Covers manifest declaration (15 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "combinatorics", "scope": "discipline of finite-set counting"},
    {"concept": "counting problem", "scope": "structured-set enumeration"},
    {"concept": "permutation", "scope": "ordered arrangement counting"},
    {"concept": "combination", "scope": "unordered selection counting"},
    {"concept": "binomial coefficient", "scope": "combinatorial n-choose-k"},
    {"concept": "binomial theorem", "scope": "combinatorial expansion"},
    {"concept": "pigeonhole principle", "scope": "existence by counting"},
    {"concept": "inclusion-exclusion", "scope": "overlap-counting principle"},
    {"concept": "stars and bars", "scope": "integer-solution counting"},
    {"concept": "generating function", "scope": "combinatorial sequence encoding"},
    {"concept": "recurrence relation", "scope": "sequential structure counting"},
    {"concept": "Catalan number", "scope": "balanced-structure counting sequence"},
    {"concept": "partition", "scope": "combinatorial set/integer decomposition"},
    {"concept": "graph", "scope": "combinatorial object for counting"},
    {"concept": "tree", "scope": "combinatorial object for counting"}
  ],
  "secondary_auto_indexed": true
}
```

### Cross-package overlaps (productive, with distinguishing scopes)

| Concept | This package's scope | Other package | Overlap status |
|---|---|---|---|
| `graph` | combinatorial object for counting | `graph_theory_core`: "graph-theoretic objects" | **Productive overlap** — counting framing vs structural framing |
| `tree` | combinatorial object for counting | `graph_theory_core`: "graph-theoretic acyclic connected" | **Productive overlap** — same |

The `graph` and `tree` overlaps are the textbook productive-overlap case: combinatorics asks "how many distinct objects of this kind are there satisfying property X?" (Cayley's formula for labeled trees, the chromatic polynomial, etc.); graph theory asks "what is the structural property of this object?" (connectivity, traversal, coloring number). Both legitimate framings of the same surface term. A query "what is a tree?" surfaces both packages; the LLM picks the framing matching the question's intent.

### What's NOT in covers (deliberate hand-off to graph_theory_core)

The package contains units for `vertex`, `edge`, `path`, `cycle`, `connected graph`, `degree`, `directed graph`, `topological ordering`, and `handshake lemma`, but does not claim them in covers. These are graph-theoretic primitives that `graph_theory_core` properly owns. Combinatorics has the units as supporting material so the package can use them in its own counting arguments, but doesn't headline them — the same pattern as ml_core having a `linear regression` unit while statistics owns the inference framing.

### Other deliberate omissions (auto-indexed via secondary)

- **Specialized identities**: Pascal, Vandermonde, double counting, bijection counting, combinatorial proof
- **Specialized counts**: Stirling numbers (second kind), derangements, Burnside lemma, circular permutations
- **Order structures**: Hasse diagram, chain, antichain, partial order, poset
- **Sub-types of partitions**: integer composition, set partition (auto-indexed under `partition`)
- **Sub-types of generating functions**: ordinary generating function, coefficient extraction (auto-indexed)
- **Discrete probability primitives**: discrete sample space, uniform sample space, counting probability — these belong to combinatorial probability and are deliberately not claimed here; `probability_stats_core` is the proper home for `probability` and `random variable`

### Feature alias added (1 load-bearing unit)

| Unit | Features added |
|---|---|
| `u_counting_problem` | `combinatorics` (anchors the discipline-overview entry) |

## Verification

| Suite | v0.3.0 | v0.3.1 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 36/36 | **36/36** (preserved) |
| Cross-package routing simulation | n/a | clean — productive overlaps with `graph_theory_core` on `graph` and `tree`; specialized graph concepts (directed graph, shortest paths, graph coloring) correctly route to GT alone |

## Coverage (unchanged from v0.3.0)

14 clusters · 56 units · 17 constraints · 17 transitions · 10 trajectories · 12 relations · 36 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "combinatorics_discrete_structures_core",
  "base_version": "0.3.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-03",
  "covers_added": true,
  "refinements": 1,
  "summary": "Added covers manifest (15 primary entries) and 1 feature-alias addition. Two productive overlaps with graph_theory_core (graph, tree) preserved with distinguishing scopes."
}
```
