# linear_algebra_core v0.2.0 — TCog basis package

**Minor upgrade of v0.1.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on four load-bearing units to align covers entries with unit features for validation cleanliness. All v0.1.0 substantive content (11 clusters, 31 units, 5 constraints, 12 transitions, 4 trajectories, 6 relations, 25 tests) preserved unchanged.

## What changed in v0.2.0

### Covers manifest declaration (16 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "linear algebra", "scope": "discipline overview"},
    {"concept": "vector space", "scope": "abstract algebraic structure"},
    {"concept": "vector", "scope": "vector space element"},
    {"concept": "matrix", "scope": "linear map representation"},
    {"concept": "linear transformation", "scope": "structure-preserving map"},
    {"concept": "basis", "scope": "vector space coordinates"},
    {"concept": "linear independence", "scope": "no redundant vectors"},
    {"concept": "span", "scope": "linear combinations of vectors"},
    {"concept": "rank", "scope": "matrix and map dimension"},
    {"concept": "null space", "scope": "kernel of linear map"},
    {"concept": "eigenvalue", "scope": "invariant scalars"},
    {"concept": "eigenvector", "scope": "invariant directions"},
    {"concept": "diagonalization", "scope": "eigenstructure simplification"},
    {"concept": "least squares", "scope": "best approximation"},
    {"concept": "singular value decomposition", "scope": "general factorization"},
    {"concept": "inner product", "scope": "geometric structure"}
  ],
  "secondary_auto_indexed": true
}
```

### Critical scope: `vector` as vector-space element

The `vector` entry's scope qualifier — "vector space element" — is doing essential routing work because *vector* is overloaded:

- **Linear algebra**: element of a vector space (closure under addition and scalar multiplication)
- **Physics**: directed quantity with magnitude and direction
- **Programming**: dynamic array (C++ `std::vector`, Python `list`)
- **ML**: feature vector (numerical representation of an example)

This package owns the algebraic-structure sense. Future physics, programming, and ML packages can claim `vector` with their own scopes; covers-routed retrieval will surface all relevant homes with role labels.

### Anticipated cross-package patterns

Linear algebra is foundational and not heavily contested between packages. The main interactions:

- **ml_core's `linear regression` and `linear classification`** are *uses* of LA, not competing claims on LA concepts. No covers conflict.
- **set_theory_logic_core's `function` (set-theoretic mapping)** doesn't conflict with `linear transformation` (specific kind of function with structure-preservation). Different scopes.
- **calculus_real_analysis_core's `function`** (when updated, likely scoped "real-valued analysis") also distinct from `linear transformation`.

### What's NOT in covers (deliberate)

- **LU, QR factorizations** as separate entries — `secondary_auto_indexed` catches them via `k_decompositions_simplify_problems`. Only `singular value decomposition` is primary because it's the most common standalone definitional query.
- **`condition number`, `norm`, `orthogonal matrix`, `projection`, `change of basis`** — auto-indexed via cluster/unit content; not headlining concepts.
- **`linear system`** — cluster `k_solving_linear_systems` handles Ax=b queries via cue-based routing. Keeping covers tight.
- **`dot product`, `cross product`** — `dot product` auto-indexed under inner product cluster; cross product is 3D-specific, package doesn't focus on it.
- **`determinant`** — left out because the package doesn't have a dedicated determinant unit; `secondary_auto_indexed` handles definitional queries via the eigenstructure cluster which mentions determinants.
- **Applied uses** (PCA in ML, stress tensors in physics, etc.) — outside this package's scope; those belong in respective applied packages.

### Feature aliases added (4 load-bearing units)

To make user-friendly covers entries match unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_vector_space` | `linear algebra` |
| `u_linear_map` | `linear transformation` |
| `u_kernel` | `null space` |
| `u_diagonalizability` | `diagonalization`, `spectral decomposition` |

Each alias is a synonym actively used by users when querying — `linear transformation` is more common in introductory texts than `linear map`; `null space` is more common than `kernel` in many curricula; `diagonalization` (the process) is the verb form of `diagonalizability` (the property). The cluster and unit labels are unchanged.

## Verification

| Suite | v0.1.0 | v0.2.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 25/25 | **25/25** (preserved) |
| Cross-package routing simulation | n/a | clean — LA claims its concepts; correctly does NOT claim Turing machine, overfitting, graph, set theory, or dynamic programming |

## Coverage (unchanged from v0.1.0)

11 clusters · 31 units · 5 constraints · 12 transitions · 4 trajectories · 6 relations · 25 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "linear_algebra_core",
  "base_version": "0.1.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 4,
  "summary": "Added covers manifest (16 primary entries) and 4 feature-alias additions on load-bearing units."
}
```
