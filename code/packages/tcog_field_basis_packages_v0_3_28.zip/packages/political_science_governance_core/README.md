# Political Science Governance Core Basis Package

TCog Protocol v0.3 draft basis package.

## Purpose
Core governance reasoning principles for power, institutions, legitimacy, collective action, veto players, agenda control, path dependence, and state capacity.

## Runtime use
This package is designed for mechanical-first retrieval:

```text
query → package routing → cue/negative-cue scan → cluster activation → unit loading → constraint trigger check → trajectory match → frame-limit check → answer/state update
```

## Status
- lifecycle_status: draft
- quality_level: axiom_bank_unvetted
- use: query routing, prototype testing, package-loader validation
- not: citation-grade disciplinary authority

## Main trajectory
`political_science_governance_core:tr_core` — governance analysis trajectory
