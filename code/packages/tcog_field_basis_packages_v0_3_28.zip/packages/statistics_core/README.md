# statistics_core v0.3.1 — TCog basis package

**Patch upgrade of v0.3.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on three load-bearing units to align covers entries with unit features for validation cleanliness. All v0.3.0 substantive content (10 clusters, 10 units, 3 constraints, 9 transitions, 2 trajectories, 2 relations, 5 tests) preserved unchanged.

## What changed in v0.3.1

### Covers manifest declaration (11 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "statistical reasoning", "scope": "principles for empirical claims"},
    {"concept": "sampling", "scope": "what inference a sample supports"},
    {"concept": "selection bias", "scope": "missing or selected cases distort"},
    {"concept": "base rate", "scope": "prevalence affects evidence weight"},
    {"concept": "measurement error", "scope": "construct vs measurement"},
    {"concept": "overfitting", "scope": "in-sample vs out-of-sample principle"},
    {"concept": "uncertainty quantification", "scope": "report uncertainty not just point estimate"},
    {"concept": "statistical significance", "scope": "significance vs practical importance"},
    {"concept": "model assumptions", "scope": "assumptions shape conclusions"},
    {"concept": "variation", "scope": "random vs signal"},
    {"concept": "correlation is not causation", "scope": "association vs causal claim"}
  ],
  "secondary_auto_indexed": true
}
```

### Scope: principles, not machinery

This is the smallest covers list of any updated package, reflecting `statistics_core`'s deliberately narrow scope. The package is a **principles** layer — 10 admonitory units about how statistical reasoning can go wrong — rather than a **machinery** layer (hypothesis tests, distributions, estimator theory, which live in `probability_stats_foundations_core`).

Every primary entry corresponds to a substantive cluster that operationalizes the principle:

| Primary entry | Cluster |
|---|---|
| `statistical reasoning` | (whole package — discipline overview) |
| `variation` | `k_variation_is_normal` |
| `sampling` | `k_sampling_determines_inference` |
| `selection bias` | `k_selection_bias_distorts_conclusions` |
| `base rate` | `k_base_rates_matter` |
| `measurement error` | `k_measurement_error_matters` |
| `overfitting` | `k_overfitting_is_real` |
| `uncertainty quantification` | `k_uncertainty_must_be_quantified` |
| `statistical significance` | `k_significance_is_not_practical_importance` |
| `model assumptions` | `k_model_assumptions_are_part_of_the_claim` |
| `correlation is not causation` | `k_correlation_is_not_causation` |

### Cross-package overlaps (productive, with distinguishing scopes)

| Concept | This package's scope | Other package | Overlap status |
|---|---|---|---|
| `selection bias` | missing or selected cases (principle) | `scientific_methodology_core`: "observational research threat" | **Productive overlap** — principle vs research-design framing |
| `overfitting` | in-sample vs out-of-sample principle | `ml_core`: "diagnostic phenomenon" | **Productive overlap** — principle vs ML-specific diagnostic |
| `correlation is not causation` | association vs causal claim | `scientific_methodology_core` has the same unit | **Genuine duplication** — both packages legitimately home it from different framings |

The `correlation is not causation` overlap is interesting: the same unit content (`u_correlation_is_not_causation`) exists in both packages. `scientific_methodology_core` treats it as the *foundation of causal inference* (it's the package's first cluster); `statistics_core` treats it as a *statistical reasoning principle*. Both should claim it. The covers framework surfaces both.

### What's NOT in covers (deliberate gap)

The package mentions the following concepts as **feature flags on units** but does NOT anchor them with dedicated units:

- `hypothesis testing`
- `confidence interval`
- `credible interval`
- `p-value`
- `effect size`
- `null hypothesis`

These remain unclaimed across the entire current package set:

- `scientific_methodology_core` mentions them in unit definitions but doesn't anchor primary units
- `probability_stats_foundations_core` has bridge content (`u_estimator`, `u_likelihood`) but no anchored hypothesis-testing unit
- `statistics_core` (this package) treats them as topic-feature flags, not anchored units

For now, definitional queries on these concepts fall through covers to **cue-based routing**. The activation policies of all three packages have these as triggers, so retrieval still works — it just doesn't surface a primary covers home with a scope qualifier.

**Future content addition:** anchoring a hypothesis-testing unit (with sources, integrated into a relevant cluster) and adding it to one of the three packages' covers would close this gap. That's a content revision, not a metadata revision.

### Other deliberate omissions

- **`survivorship bias`, `missing data`** — auto-indexed under `selection bias`
- **`construct validity`** — auto-indexed under `measurement error`
- **`independence`, `stationarity`** — auto-indexed under `model assumptions`

### Feature aliases added (3 load-bearing units)

To align user-facing covers entries with unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_variation_is_normal` | `statistical reasoning` (anchors the discipline-overview entry) |
| `u_uncertainty_must_be_quantified` | `uncertainty quantification` |
| `u_significance_is_not_practical_importance` | `statistical significance` |

## Verification

| Suite | v0.3.0 | v0.3.1 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 5/5 | **5/5** (preserved) |
| Cross-package routing simulation | n/a | clean — productive overlaps with sciMethod (`selection bias`, `correlation is not causation`) and ml_core (`overfitting`); homeless concepts (`hypothesis testing`, `confidence interval`, `p-value`, `effect size`) correctly fall through to cue-based routing |

## Coverage (unchanged from v0.3.0)

10 clusters · 10 units · 3 constraints · 9 transitions · 2 trajectories · 2 relations · 5 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "statistics_core",
  "base_version": "0.3.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 3,
  "summary": "Added covers manifest (11 primary entries) and 3 feature-alias additions on load-bearing units."
}
```
