# Information Science and Retrieval Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core IS / IR principles for TCog basis-package retrieval. Cross-cutting design
threading classical library science, computational IR, neural IR, archives /
preservation, and the retrieval-vs-LLM bridge.

## Clusters
- `k_classification_shapes_retrieval` — Cutter 1876, Ranganathan 1931+1933, Bowker-Star 1999
- `k_metadata_is_knowledge` — Dublin Core 1995, FRBR 1998, NISO 2017
- `k_controlled_vocabulary_reduces_ambiguity` — Soergel 1985, ANSI/NISO Z39.19, FRAD 2009, MeSH/LCSH, Berman 1971
- `k_ambiguity_requires_disambiguation` — Furnas et al. 1987, Mihalcea-Csomai 2007 + Hoffart 2011 (NER), Lesk 1986 + Yarowsky 1995 + Navigli 2009 (WSD)
- `k_provenance_supports_trust` — W3C PROV-O 2013, Jenkinson 1922 + Schellenberg 1956 (archival), Merton 1973 + Garfield 1955 (citation)
- `k_indexes_are_retrieval_infrastructure` — Sparck Jones 1972 + Manning-Raghavan-Schütze 2008 (TF-IDF / inverted index), Robertson-Walker 1994 (BM25), Mikolov 2013 + Karpukhin 2020 + Khattab 2020 + Lewis 2020 (dense retrieval / RAG)
- `k_preservation_needs_structure` — CCSDS 2012 / Lavoie 2014 (OAIS), Rothenberg 1995+1998 (format obsolescence), Heslop-Davis-Wilson 2002 + Duranti (significant properties / authenticity / InterPARES)

## Trajectories
- `tr_concept_intro` — for "what is X" queries about IS/IR concepts
- `tr_design_a_retrieval_system` — full design walkthrough: classification → metadata → controlled vocab → ambiguity → index → provenance
- `tr_diagnose_retrieval_failure` — branches off tr_design_a_retrieval_system at
  `k_indexes_are_retrieval_infrastructure`; localizes failure (vocabulary problem,
  NER, WSD, controlled-vocabulary mismatch, evaluation-metric inspection)
- `tr_design_a_rag_system` — RAG/search-design path: index → ambiguity → vocab → provenance, with explicit lexical-vs-neural framing

## Constraints
- `c_check_vocabulary_problem_assumed` — search-failure claims need vocabulary-problem framing (high)
- `c_specify_metadata_purpose` — metadata-design claims need descriptive/administrative/structural purpose specified (medium)
- `c_record_provenance_for_derived_data` — derived data / LLM outputs need provenance (high)
- `c_consider_preservation_at_design_time` — long-term-record claims need preservation strategy (medium)
- `c_disambiguate_when_ambiguous` — ambiguous-named-entity / polysemous-term claims need disambiguation (low)
- `c_evaluate_retrieval_with_relevance_metrics` — retrieval-system claims need precision/recall/MAP/NDCG specified (medium)

## Cross-package relations
Internal: `rel_internal_lexical_vs_neural_retrieval` surfaces controlled-
vocabulary indexing (Soergel/MeSH/LCSH thesauri) and learned-representation
retrieval (Mikolov→Karpukhin→Khattab→Lewis) as complementary frames in the
canonical lexical-vs-neural retrieval disagreement. Both have substantial 2024+
evidence; both apply to different conditions; modern best-practice is hybrid.
Directly relevant to RAG / LLM-application design. The disagreement is also
methodologically live for TCog itself: mechanical-mode-first is BM25-flavored;
semantic-augmented mode is dense-flavored.

Complements: computer_science_systems_core, design_hci_core, cognitive_science_core,
communication_rhetoric_core, statistics_core, philosophy_ethics_core,
history_path_dependence_core.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for IS / IR /
  RAG / archives / preservation reasoning
- not: a substitute for hands-on retrieval engineering or archival fieldwork; not
  for stock-market indexes, vector graphics, embedded systems, food preservation,
  art-historical provenance, vocabulary in language learning
