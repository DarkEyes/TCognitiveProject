# theory_of_computation_core v0.3.2 — TCog basis package

**Patch upgrade of v0.3.1 — bug fix only.** Fixed malformed `blocks_answer` field on 17 of 34 constraints. No content additions, no removals, no covers changes.

## What changed in v0.3.2

### The bug

17 of the package's 34 constraints had a non-boolean string written into the `blocks_answer` field where the protocol schema requires a boolean. The strings contained Sipser textbook chapter/section references — author metadata that ended up in the wrong field.

```jsonc
// BEFORE (malformed):
{
  "id": "...c_regular_expression_formal_scope_check",
  "severity": "medium",
  "blocks_answer": "Chapter 1, Section 1.3, Regular Expressions",  // ← string, should be boolean
  "anchors": [{"location": "Sipser, ITTOC 3e, General"}]            // ← vague placeholder
}
```

In JavaScript, any non-empty string is truthy. The mechanical constraint gate read `blocks_answer` as truthy and treated all 17 constraints as blocking. The real-world consequence: definitional queries that should produce direct answers were instead getting demands for clarification.

The user-facing demonstration that surfaced this bug:

> Query: "How is a regular expression different from context-free?"
>
> Result: `disposition: blocked_by_constraint`. The user is asked "Are you asking about *formal* regular expressions or practical regex-engine features?" — even though the query mentions context-free grammars, which is unambiguously formal-language-theory territory.

This was a **package data integrity bug**, not a pipeline or constraint-logic bug. The constraint's intent was correct (severity `medium`, scope reminder); the field was just malformed.

### The fix

For each of the 17 malformed constraints:

1. The Sipser chapter/section reference (which had been in `blocks_answer`) is moved into `anchors[0].location`, replacing the vague `"...General"` placeholder. Now the anchor records the actual specific chapter and section the rule comes from.
2. `blocks_answer` is set to `false`. None of these 17 constraints have `severity: critical`; they are scope and admissibility caveats meant to surface as warnings, not gate the answer.

The two **genuinely-blocking** constraints — `c_halting_universal_decider_blocks` (don't claim to decide halting universally) and `c_open_problem_separation_check` (don't claim P ≠ NP is settled) — are both `severity: critical` and were correctly set to `blocks_answer: true`. They are unchanged.

### Constraints fixed (17)

All severity-medium and severity-high scope/admissibility/definitional checks:

- `c_cfg_ambiguity_not_language_ambiguity_check`
- `c_cnf_scope_check`
- `c_crypto_assumption_scope_check`
- `c_decidable_problem_encoding_check`
- `c_dfa_total_transition_check`
- `c_dpda_acceptance_convention_check`
- `c_interactive_proof_roles_check`
- `c_kolmogorov_compression_model_check`
- `c_log_space_reduction_check`
- `c_mapping_reduction_membership_equivalence_check`
- `c_nfa_acceptance_branch_check`
- `c_np_membership_certificate_check`
- `c_polynomial_reduction_type_check`
- `c_pspace_completeness_two_part_check`
- `c_randomized_error_bound_check`
- `c_recursion_theorem_scope_check`
- `c_regular_expression_formal_scope_check`

### What constraints still do after the fix

The constraints continue to:

- Fire when their `trigger_cues` match a query (unchanged)
- Surface their `repair` guidance to the user (unchanged)
- Carry their `severity` for downstream weighting (unchanged)
- Anchor their authority via the proper `anchors[0].location` field (now properly set)

What they no longer do:

- Block the answer outright (unless they were genuinely critical, which the fixed 17 are not)

A query like "how is a regular expression different from context-free grammar?" should now get a direct answer about the language-class distinction, with `c_regular_expression_formal_scope_check` surfacing as a caveat ("note: this concerns formal regular expressions; practical regex engines extend the model") rather than as a gate that demands clarification before answering.

## What this package change does NOT fix

Two related issues are out of scope for this package patch and remain for follow-up work:

**1. Pipeline issue: constraints firing without trigger_cue match.** The screenshot showed `c_dfa_total_transition_check`, `c_cfg_ambiguity_not_language_ambiguity_check`, and `c_cnf_scope_check` firing on the regex-vs-CFG query, but their actual `trigger_cues` (`DFA`, `transition function`, `Chomsky normal form`, `CNF`, `ambiguous grammar`, `parse tree`, etc.) do not match the query at all. The pipeline appears to be over-fetching blocking constraints related to active clusters rather than only firing constraints whose trigger_cues actually match. With the v0.3.2 fix these constraints no longer block, but they may still surface as caveats inappropriately. **This is a Claude Code pipeline issue, not a package issue.**

**2. Validation rule for `blocks_answer`.** The TCog Schema validator should warn when a `blocks_answer` value is not a boolean. The protocol's §11 validation rules mention required fields by type but do not explicitly check this. **This is a protocol-tooling improvement for v0.3.2 of the spec, not this package.**

## Verification

| Suite | v0.3.1 | v0.3.2 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | **0 errors** |
| Constraints with malformed `blocks_answer` | 17 | **0** |
| Genuinely-blocking constraints (severity=critical, blocks_answer=true) | 2 | **2** (unchanged) |
| Internal `tests.jsonl` | 53/64 | **53/64** (no regression — same 11 pre-existing test failures, all due to constraint trigger_cue gaps unrelated to this fix) |

The 11 pre-existing test failures are a separate issue: they expect specific constraints to fire on test inputs whose actual wording doesn't match the constraint's trigger_cues (e.g. `c_decidable_vs_recognizable_check` is expected to fire on "what is the difference between a decider and a recognizer?" but its trigger cues don't include "difference between"). These are constraint-cue gaps that would benefit from a separate cue-coverage audit, similar to what was done for `probability_stats_core`. Out of scope for this patch.

## Coverage (unchanged from v0.3.1)

- Units: 119
- Clusters: 17
- Constraints: 34
- Transitions: 32
- Trajectories: 9
- Relations: 11
- Tests: 64
- Covers entries: 17

## merge_intent

```json
{
  "type": "extension",
  "base_package": "theory_of_computation_core",
  "base_version": "0.3.1",
  "source_added": "blocks_answer_field_repair",
  "merge_date": "2026-05-03",
  "fixed_constraints": 17,
  "kept_blocking_constraints": 2,
  "summary": "Repaired malformed blocks_answer field on 17 constraints. No content changes, no covers changes; pure data integrity fix."
}
```
