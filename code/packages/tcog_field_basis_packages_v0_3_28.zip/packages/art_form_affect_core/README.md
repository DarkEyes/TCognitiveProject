# Art, Form, and Affect Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core aesthetic-theoretical and cognitive-aesthetic principles for TCog
basis-package retrieval. Cross-cutting design threading classical/formalist
criticism, reader-response and reception aesthetics, affect theory, and
cognitive aesthetics through the existing 6-theme skeleton.

## Clusters
- `k_form_carries_meaning` — Wimsatt-Beardsley 1946+1949, Goodman 1968, Shklovsky 1917, Jakobson 1960
- `k_style_is_constraint` — Goodman 1968, Auerbach 1946, Tsur 1992 (OuLiPo tradition)
- `k_aesthetic_coherence_differs_from_logic` — Beardsley 1958, Brooks 1947, Stockwell 2002
- `k_genre_frames_interpretation` — Jauss 1982, Frye 1957, Bakhtin 1986, Todorov 1973
- `k_affect_is_structured` — Aristotle Poetics, Ngai 2012, Leder et al. 2004, Damasio 1994
- `k_ambiguity_can_be_functional` — Empson 1930, Iser 1978, Eco 1962+1979

## Trajectories
- `tr_concept_intro` — for "what is X" queries about aesthetic concepts
- `tr_interpret_a_work` — interpretation path: genre → form → coherence → affect → ambiguity
- `tr_diagnose_aesthetic_failure` — branches off tr_interpret_a_work at
  `k_aesthetic_coherence_differs_from_logic`; localizes failure (form-content
  mismatch, stylistic clash, unproductive opacity)
- `tr_compare_styles_or_works` — comparison path: style → form → genre

## Constraints
- `c_form_meaning_distinguished` — meaning claims must include form's contribution (medium)
- `c_genre_declared_for_interpretation` — interpretation needs declared genre frame (medium)
- `c_aesthetic_affect_not_idiosyncratic_reaction` — affect claims need structured-vs-personal distinction (medium)
- `c_ambiguity_distinguished_from_failure` — ambiguity claims need productive-vs-failure distinction (medium)
- `c_paraphrase_does_not_replace_work` — paraphrase claims need acknowledgment of loss (low)
- `c_aesthetic_coherence_not_propositional` — coherence claims need aesthetic criteria not logic (medium)

## Cross-package relations
Internal: `rel_internal_formalism_vs_reader_response` surfaces Wimsatt-Beardsley's
text-centered formalism and Iser's reader-response as complementary frames placing
meaning's locus differently.
Complements: philosophy_ethics_core, communication_rhetoric_core,
cognitive_science_core, psychology_core, education_pedagogy_core,
counselling_practice_core (only when aesthetic experience is therapeutic).

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for
  aesthetic / formal / interpretive / affective reasoning about artworks
- not: a substitute for clinical affect assessment, non-aesthetic communicative
  ambiguity analysis, or technical-style usages
