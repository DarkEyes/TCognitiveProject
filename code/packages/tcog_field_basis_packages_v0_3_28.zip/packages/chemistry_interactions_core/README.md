# Chemistry Interaction Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core chemistry-reasoning principles for TCog basis-package retrieval.
Cross-cutting design threading general, organic, physical, and biochemistry
through the existing 6-theme skeleton.

## Clusters
- `k_structure_determines_interaction` — Pauling 1939, Lewis 1916, March 2007, Pearson 1963 (HSAB)
- `k_conditions_matter` — Arrhenius 1889, Reichardt-Welton 2010, Carey-Sundberg 2007 (kinetic-vs-thermodynamic)
- `k_equilibrium_is_dynamic` — Le Chatelier 1884, van't Hoff 1884, Atkins 2018, Gibbs 1876
- `k_catalysts_change_pathways` — Eyring 1935, Bell-Evans-Polanyi 1938, Sabatier 1911, Michaelis-Menten 1913, Pauling 1948
- `k_small_structural_changes_matter` — Eliel-Wilen 1994, Hammett 1937, Hammond 1955, Curtin-Hammett 1954
- `k_stoichiometry_constrains_transformation` — Lavoisier 1789, Atkins 2018, Marcus 1956 (electron transfer)

## Trajectories
- `tr_concept_intro` — for "what is X" queries about chemistry concepts
- `tr_predict_reaction_outcome` — prediction path: structure → conditions → catalysts → small changes
- `tr_diagnose_unexpected_product` — branches off tr_predict_reaction_outcome at
  `k_conditions_matter`; localizes failure (kinetic-vs-thermodynamic mismatch,
  unexpected pathway, condition-driven selectivity)
- `tr_quantitative_yield_calculation` — yield path: balanced equation → limiting reagent → theoretical yield → redox

## Constraints
- `c_distinguish_kinetic_thermodynamic_control` — product claims need frame specification (high)
- `c_specify_reaction_conditions` — reactivity claims need conditions (medium)
- `c_balance_equation_before_yield` — yield claims need balanced equation (medium)
- `c_acknowledge_stereochemistry` — product claims need stereochemistry (medium)
- `c_catalyst_does_not_shift_equilibrium` — catalyst claims need correct mechanism (high)
- `c_redox_balance_includes_electrons` — redox claims need explicit electron accounting (medium)

## Cross-package relations
Internal: `rel_internal_thermodynamic_vs_kinetic_control` surfaces Gibbs
thermodynamic-control evidence and kinetic-control evidence as complementary
frames in the canonical chemistry-frame disagreement.
Complements: physics_dynamical_constraints_core, biology_adaptation_core,
medicine_diagnostic_safety_core, statistics_core, systems_control_core,
education_pedagogy_core, philosophy_ethics_core.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for
  chemistry / organic / physical / biochemistry reasoning
- not: a substitute for hands-on synthetic chemistry expertise; not for
  metaphorical 'chemistry', cooking, or marketing 'organic'/'natural'
