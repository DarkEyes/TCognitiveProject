# ml_core v0.2.0 — TCog basis package

**Minor upgrade of v0.1.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on five load-bearing units to align covers entries with unit features for validation cleanliness. All v0.1.0 substantive content (19 clusters, 119 units, 13 constraints, 26 transitions, 7 trajectories, 13 relations, 12 tests) preserved unchanged.

## What changed in v0.2.0

### Covers manifest declaration (16 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "machine learning", "scope": "supervised learning theory and core models"},
    {"concept": "supervised learning", "scope": "labeled data learning paradigm"},
    {"concept": "generalization", "scope": "in-sample vs out-of-sample"},
    {"concept": "overfitting", "scope": "diagnostic phenomenon"},
    {"concept": "regularization", "scope": "constraint on hypothesis complexity"},
    {"concept": "bias-variance tradeoff", "scope": "expected error decomposition"},
    {"concept": "VC dimension", "scope": "hypothesis class complexity"},
    {"concept": "linear regression", "scope": "real-valued supervised model"},
    {"concept": "logistic regression", "scope": "probabilistic binary classification"},
    {"concept": "linear classification", "scope": "perceptron and hyperplane classifiers"},
    {"concept": "cross-validation", "scope": "held-out validation method"},
    {"concept": "hypothesis class", "scope": "set of candidate functions"},
    {"concept": "Occam's razor", "scope": "ML simplicity principle"},
    {"concept": "sampling bias", "scope": "ML data hygiene principle"},
    {"concept": "data snooping", "scope": "learning hygiene principle"},
    {"concept": "learning theory", "scope": "PAC and VC framework"}
  ],
  "secondary_auto_indexed": true
}
```

### Scope: classical statistical learning theory

This package covers the Abu-Mostafa-style classical learning theory frame: the seven-component supervised learning setup, VC-style generalization analysis, bias-variance decomposition, hypothesis class complexity, regularization, validation. Scope qualifiers explicitly mark this lineage.

**Deliberately not claimed in covers:**

- Neural networks / deep learning (no cluster coverage; future `deep_learning_core` would handle)
- Reinforcement learning, unsupervised learning beyond paradigm-mention
- Specific applied algorithms (SVMs, random forests, gradient boosting, k-means, decision trees)
- Probabilistic graphical models, Bayesian inference, MCMC

If users ask "what is a neural network?" or "what is k-means?", ml_core's covers will NOT claim authority — the secondary_auto_indexed fallback also misses these because no cluster or unit anchors them. Cue-based routing handles them.

### Cross-package overlaps

- **`Occam's razor`** is a general philosophical principle. ml_core operationalizes it for model selection (scope: "ML simplicity principle"). A future philosophy package would claim it with scope "epistemic principle." Both legitimate; covers-routed retrieval surfaces both with role labels.
- **`sampling bias`** likely will overlap with a future `probability_stats_foundations_core` covers update (scope distinction: "ML data hygiene principle" vs likely "selection bias in inference"). Tracked for that update.

### Feature aliases added (5 load-bearing units)

To make the user-friendly covers entries match unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_supervised_learning` | `machine learning`, `ML` |
| `u_learning_vs_design` | `machine learning` |
| `u_two_question_feasibility` | `learning theory framework` |
| `u_vc_generalization_bound` | `learning theory`, `statistical learning theory` |
| `u_bias_variance_decomposition` | `bias-variance tradeoff`, `bias variance tradeoff` |

Rationale: the package's clusters and units use phrasings like "bias-variance decomposition" (technical) where users typically search "bias-variance tradeoff" (colloquial). Adding the colloquial form as a feature alias preserves the technical label while making `secondary_auto_indexed` retrieval more robust.

## Verification

| Suite | v0.1.0 | v0.2.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings (all 16 entries match labels/features) |
| Internal `tests.jsonl` | 12/12 | **12/12** (preserved) |
| Cross-package routing simulation (algorithm_design_core, theory_of_computation_core) | n/a | clean — ml_core claims ML topics, doesn't claim Turing machine or dynamic programming |

## Coverage (unchanged from v0.1.0)

19 clusters · 119 units · 13 constraints · 26 transitions · 7 trajectories · 13 relations · 12 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "ml_core",
  "base_version": "0.1.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 5,
  "summary": "Added covers manifest (16 primary entries) and 5 feature-alias additions on load-bearing units."
}
```
