# Operations Research and Decision Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core OR and decision-theory reasoning principles, organized as 7 deep
clusters anchored to canonical sources, for TCog basis-package retrieval.
Cross-cutting design threading mathematical programming, decision theory,
queueing, Theory of Constraints, and robustness/regret through the existing
7-theme skeleton, with explicit normative-vs-descriptive framing of decision
theory.

## Clusters
- `k_objectives_and_preferences` — Keeney-Raiffa, Steuer, Manheim-Garrabrant (Goodhart)
- `k_constraints_and_feasibility` — Dantzig, Bertsimas-Tsitsiklis, Boyd-Vandenberghe, Kuhn-Tucker (1951)
- `k_bottlenecks_and_throughput` — Goldratt (TOC), Ford-Fulkerson (1956), Kelley-Walker (1959, CPM)
- `k_optimization_landscape` — Boyd-Vandenberghe, Garey-Johnson (1979), Kirkpatrick et al. (1983), Wolpert-Macready (1997)
- `k_decision_under_uncertainty` — vNM (1944), Savage (1954), Tversky-Kahneman (1979, 1992), Ellsberg (1961), Allais (1953)
- `k_robustness_and_regret` — Bertsimas-Sim (2004), Ben-Tal-Nemirovski (2002), Wald (1950), Savage (1951), Kelly (1956)
- `k_queues_and_congestion` — Little (1961), Kingman (1961), Smith (1956), Pinedo

## Trajectories
- `tr_or_concept_intro` — for "what is X" queries
- `tr_formulate_optimization_problem` — design path: objectives → constraints → landscape → uncertainty → robustness
- `tr_decide_under_uncertainty` — decision path with normative-vs-descriptive framing
- `tr_robust_decision_under_ambiguity` — branches off `tr_decide_under_uncertainty` at
  `k_decision_under_uncertainty` for deep-uncertainty / ambiguity questions

## Constraints
- `c_objective_specified` — optimum claim requires declared objective (high)
- `c_constraints_listed` — feasibility claim requires explicit constraints (high)
- `c_local_vs_global_disclosed` — optimum claim must specify local/global + convex (high)
- `c_uncertainty_treatment_declared` — risk vs uncertainty vs ambiguity must be named (medium)
- `c_robustness_criterion_named` — robustness claim requires uncertainty set + criterion (medium)
- `c_queue_assumptions_named` — queueing claim requires distributions + discipline (medium)

## Cross-package relations
Internal: `rel_internal_normative_vs_descriptive_decision_theory` surfaces both EU and
prospect theory / Ellsberg as complementary frames for different questions.
Complements: economics_core, management_execution_core, statistics_core,
physics_dynamical_constraints_core, computer_science_systems_core,
psychology_core, philosophy_ethics_core.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for OR
  and decision-theory reasoning
- not: a substitute for domain knowledge in finance, supply-chain, or logistics
