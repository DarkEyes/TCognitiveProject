# algorithm_design_core v0.4.0 — TCog basis package

**Minor content addition over v0.3.0**, closing a real package gap exposed by demo testing: queries like "What is an algorithm?" previously failed because the package had cues for *specific* algorithms (greedy, Dijkstra, Tarjan, etc.) and *aspects* of algorithms (complexity, correctness, design paradigms) but no foundational unit or cluster for the basic concept itself.

## What changed in v0.4.0

### New cluster `k_algorithmic_foundations`

A foundational entry-point cluster placed at the front of the cluster list. Activates on definitional queries like "what is an algorithm?" and hands off to specific paradigm clusters when the question is about a particular algorithm or aspect.

```json
"cues": [
  "what is an algorithm",
  "what is algorithm",
  "what are algorithms",
  "definition of algorithm",
  "define algorithm",
  "algorithm design",
  "algorithm analysis",
  "what is algorithm design",
  "what is algorithm analysis",
  "introduction to algorithms",
  "what does algorithm mean",
  "model of computation",
  "RAM model",
  "abstract machine model",
  "what is a computational procedure"
]
```

Cues are deliberately phrase-level. Bare `"algorithm"` is **not** a cue — it would over-fire on every paradigm query in the package's domain. The cues capture the linguistic shape of *foundational* questions, not just the presence of the word.

### 4 new anchored units

| Unit | Anchor source |
|---|---|
| `u_algorithm` | CLRS 4e (MIT, 2022) Ch. 1; Kleinberg & Tardos (Pearson, 2006) Ch. 1 |
| `u_algorithm_design` | Kleinberg & Tardos Ch. 1 |
| `u_algorithm_analysis` | CLRS 4e Ch. 2-3 |
| `u_model_of_computation` | CLRS 4e Ch. 2 (RAM); Sipser 3e (Cengage, 2013) Ch. 3 |

These four units close a hole in the covers entries: previously `algorithm`, `algorithm design`, and `algorithm analysis` were declared in the covers manifest but had no anchored unit homes. Now each covers entry is backed by a real unit with anchored content.

### 3 new source documents declared

- CLRS (Cormen, Leiserson, Rivest, Stein), *Introduction to Algorithms*, 4e (MIT Press, 2022)
- Kleinberg & Tardos, *Algorithm Design* (Pearson, 2006)
- Sipser, *Introduction to the Theory of Computation*, 3e (Cengage, 2013) — for the model-of-computation anchor

### Hand-off discipline (preserved)

- **`theory_of_computation_core`** owns the *formalization* of algorithms (Turing machines, decidability, complexity classes P/NP/PSPACE)
- **`algorithm_design_core`** (this package) owns the *practitioner* concept of algorithm + design paradigms + analysis methodology

The covers framework already declared this overlap with distinguishing scopes (`algorithm` scope: "design and analysis" here, "formalization and limits" in TOC). v0.4.0 just makes sure the anchor structure backs the claim.

## Why this gap existed

The package was authored from a paradigm-first viewpoint: greedy, divide-and-conquer, dynamic programming, network flow, NP-completeness, etc. Each paradigm has its own cluster and units. The package never explicitly defined "algorithm" because the term was treated as background — the reader was assumed to already know what algorithms were.

This works for a textbook reading audience but not for a retrieval system: a user asking "what is an algorithm?" got the activation policy match (cue: `algorithm design`) but no firing cluster (no cluster's cues matched the query). Result: `disposition: no_match`, the demo shown.

The fix is the same pattern the probability_stats_core v1.0.0 revision used: when covers declares a concept as primary, an anchored unit and a cluster with appropriate cues must back it up. Covers metadata routes the query, but the package's content has to actually answer it.

## Verification

| Suite | v0.3.0 | v0.4.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | **0 errors** |
| Covers validation (warnings) | 0 | **0 warnings** |
| Internal `tests.jsonl` | 52/52 | **52/52** (all preserved) |
| `"What is an algorithm?"` query | `no_match` | **fires `k_algorithmic_foundations`** |
| Specific paradigm queries (greedy/dijkstra/etc.) | clean routing | **clean routing preserved** (foundations does not over-fire) |

### Spot check — paradigm queries still route correctly

| Query | Foundations fires? | Other clusters fire? |
|---|---|---|
| `"what is dynamic programming"` | no | `k_dynamic_programming` |
| `"How does Dijkstra work?"` | no | `k_greedy_design`, `k_shortest_paths_and_weighted_graphs` |
| `"prove correctness of greedy algorithm"` | no | `k_greedy_design` (etc.) |
| `"what is NP-completeness"` | no | `k_np_intractability_and_reductions` |
| `"what is algorithm analysis"` | **yes** | `k_algorithm_analysis_and_tractability` (both fire — both are correct) |

Foundations only fires when the query is genuinely foundational (asks "what is X" for X = algorithm, algorithm design, algorithm analysis, etc.).

## Coverage

| Layer | v0.3.0 | v0.4.0 |
|---|---|---|
| Units | 137 | **141** (+4) |
| Clusters | 18 | **19** (+1) |
| Constraints | unchanged | unchanged |
| Transitions | unchanged | unchanged |
| Trajectories | unchanged | unchanged |
| Tests | 52 | **52** (preserved) |
| Source documents | 7 | **10** (+3) |

## merge_intent

```json
{
  "type": "extension",
  "base_package": "algorithm_design_core",
  "base_version": "0.3.0",
  "source_added": "foundational_cluster_addition",
  "merge_date": "2026-05-03",
  "summary": "Added foundational cluster k_algorithmic_foundations with 4 anchored units (u_algorithm, u_algorithm_design, u_algorithm_analysis, u_model_of_computation) closing the gap that caused 'What is an algorithm?' demo queries to fail. Hand-off to theory_of_computation_core preserved.",
  "additions": 1,
  "units_added": 4,
  "sources_added": ["clrs_4e_2022", "kleinberg_tardos_2006", "sipser_3e_2013"]
}
```

## Pipeline note (separate from this package change)

This v0.4.0 fixes the package gap. There is also a separate **pipeline** issue worth flagging: when a covers PRIMARY match exists but no cluster fires, the pipeline currently disposes `no_match` rather than letting the covers match itself surface a unit/cluster from the package's structure.

That's a Claude Code pipeline issue, not a package issue. The package change in v0.4.0 means the question now activates a cluster mechanically *and* matches via covers — both routes succeed. But other packages in the bundle may have similar gaps (covers PRIMARY entries with no cluster cues), and the pipeline could be made more robust to that case independently of patching every package one by one.

A first-pass fix in the pipeline would be: when a covers PRIMARY match returns clusters via `members → cluster_memberships`, those clusters should be treated as fired even if their cue list didn't match the query directly. This would make the package's covers declaration fully sufficient for definitional queries.
