# Counselling Practice Core Basis Package

**Domain:** counselling

Meta-disciplinary stance of counselling practice — what counsellors would not do, what they would explore, what kinds of distress require professional referral. The package disciplines the system's response to emotional content rather than providing therapy.

## Frame limits

This package disciplines responses to emotional or distress-laden content. It is not a substitute for therapy, professional counselling, or crisis intervention. When indicators of acute risk appear, the package's safety constraints direct the user to professional resources. It is a frame for handling emotional content with care, not a frame for providing therapy.

## Contents

- 10 units with anchors to canonical works
- 10 clusters
- 4 constraints (2 blocking)
- 4 trajectories with output templates
- 4 cross-package relations
- 6 tests
