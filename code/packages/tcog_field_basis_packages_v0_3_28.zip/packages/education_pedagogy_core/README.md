# Education and Pedagogy Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core learning-sciences and pedagogy principles for TCog basis-package
retrieval. Cross-cutting design threading cognitive learning sciences,
sociocultural/Vygotskyan, constructivism / conceptual change, assessment
& feedback, and transfer literature through the existing 6-theme skeleton.

## Clusters
- `k_knowing_differs_from_using` — Anderson 1983 (ACT-R), Whitehead 1929, Bjork-Bjork 1992 + Bjork 1994
- `k_learning_requires_scaffolding` — Vygotsky 1978, Wood-Bruner-Ross 1976, Pearson-Gallagher 1983
- `k_misunderstanding_may_signal_missing_prerequisites` — Driver-Easley 1978, diSessa 1988, Vosniadou-Brewer 1992 + Chi 2008
- `k_practice_compiles_trajectories` — Ericsson-Krampe-Tesch-Römer 1993, Sweller 1988 + 1998, Roediger-Karpicke 2006
- `k_transfer_requires_structural_recognition` — Detterman 1993, Gick-Holyoak 1983, Schwartz-Bransford 1998 + Hmelo-Silver-Duncan-Chinn 2007
- `k_feedback_guides_improvement` — Black-Wiliam 1998, Hattie-Timperley 2007, Sadler 1989

## Trajectories
- `tr_concept_intro` — for "what is X" queries about pedagogy concepts
- `tr_design_instruction` — design path: prerequisites → scaffolding → practice → feedback → transfer
- `tr_diagnose_learning_struggle` — branches off tr_design_instruction at
  `k_learning_requires_scaffolding`; localizes failure (missing prerequisite,
  active misconception, declarative/procedural gap, cognitive load)
- `tr_evaluate_learning_claim` — performance-vs-learning + assessment-validity + transfer-evidence path

## Constraints
- `c_distinguish_performance_from_learning` — performance claims need Bjork distinction (high)
- `c_prerequisite_check` — instructional-effectiveness claims need prerequisite verification (medium)
- `c_load_within_capacity` — instructional-design claims need cognitive-load analysis (medium)
- `c_acknowledge_transfer_gap` — generalization claims need transfer evidence (medium)
- `c_feedback_must_be_actionable` — feedback claims need three-questions / multi-level analysis (medium)
- `c_misunderstanding_diagnostic_not_punitive` — wrong-answer claims need structural diagnosis (medium)

## Cross-package relations
Internal: `rel_internal_direct_instruction_vs_productive_failure` surfaces Sweller's
cognitive-load direct-instruction evidence and Schwartz-Bransford's productive-
failure / preparation-for-future-learning evidence as complementary frames in
the canonical Kirschner-Sweller-Clark vs Hmelo-Silver-Duncan-Chinn pedagogy
disagreement.
Complements: cognitive_science_core, psychology_core, communication_rhetoric_core,
management_execution_core, philosophy_ethics_core, art_form_affect_core,
computer_science_systems_core (with explicit AI-bridge note).

## AI-bridge anchors
Three anchors explicitly support cross-references with ML literature without
collapsing the two domains:
- `u_performance_is_not_learning` (Bjork) ↔ ML overfitting / train-test gap
- `u_near_vs_far_transfer` (Detterman) ↔ ML out-of-distribution generalization
- `u_preparation_for_future_learning` (Schwartz-Bransford) ↔ ML curriculum learning

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for
  pedagogical / instructional / assessment / transfer reasoning about
  human learning
- not: a model of ML training (bridge anchors support cross-references only)
