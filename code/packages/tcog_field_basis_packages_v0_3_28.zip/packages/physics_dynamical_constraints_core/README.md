# Physics and Dynamical Constraints Core Basis Package

TCog Protocol v0.3 — focused-tier basis package.

## Purpose
Core physics and dynamical-systems reasoning principles, organized as 7 deep
clusters anchored to canonical sources, for TCog basis-package retrieval.
Cross-cutting design threading mechanics, dynamical systems, and stochastic
dynamics through constraints, symmetries, and scales.

## Clusters
- `k_symmetry_and_conservation` — Noether (1918), Arnold, Wigner, Earman
- `k_state_space_and_dynamics` — Arnold, Goldstein, Lanczos
- `k_equilibrium_and_stability` — Strogatz, Lyapunov (1892), Khalil, Milnor, Hirsch-Smale-Devaney
- `k_bifurcation_and_chaos` — Strogatz, Guckenheimer-Holmes, Lorenz (1963), Poincaré, Feigenbaum (1978), May (1976)
- `k_scale_and_separation` — Buckingham (1914), Barenblatt, Wilson (1971), Anderson (1972), Norton, Batterman
- `k_noise_and_stochastic_dynamics` — Einstein (1905), Kubo (1966), Callen-Welton (1951), Van Kampen, Gardiner
- `k_models_and_idealization` — Cartwright (1983), McMullin (1985), Norton (2012), Anderson (1972), Batterman (2002)

## Trajectories
- `tr_physics_concept_intro` — for "what is X" queries
- `tr_diagnose_dynamical_failure` — for "model fails" / "unpredictable" queries; walks through all 7 clusters
- `tr_stability_analysis` — for "is this stable" / "find equilibria" queries
- `tr_validate_a_model` — branching off `tr_diagnose_dynamical_failure` at
  `k_models_and_idealization`, for model-adequacy questions

## Constraints
- `c_state_variables_specified` — dynamics claim completeness (high)
- `c_conservation_completeness` — symmetry source for conservation (medium)
- `c_equilibrium_vs_stability_distinction` — stability sense must be named (high)
- `c_scale_separation_check` — explicit scale assumptions (medium)
- `c_noise_treatment_check` — noise model disclosure (medium)
- `c_idealization_disclosure` — idealization must be named (medium)

## Cross-package relations
Complements: systems_control_core, statistics_core,
operations_research_decision_core, biology_adaptation_core,
computer_science_systems_core, philosophy_ethics_core.
Potential conflict: computer_science_systems_core over strong reductionism
vs explanatory autonomy of emergent laws.

## Status
- lifecycle_status: draft
- quality_level: reviewed
- authoring_status: focused_with_anchors
- protocol_version: 0.3
- version: 0.3.1
- use: query routing, mechanical retrieval, basis-state activation for physics
  and dynamical-systems reasoning
- not: a substitute for general physics curriculum (no E&M, QM, GR, particle physics)
