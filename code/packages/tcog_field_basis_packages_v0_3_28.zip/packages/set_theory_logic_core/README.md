# set_theory_logic_core v0.2.0 — TCog basis package

**Minor upgrade of v0.1.0** to add `covers` manifest declaration per TCog Schema v0.3.1, plus feature aliases on four load-bearing units to align covers entries with unit features for validation cleanliness. All v0.1.0 substantive content (8 clusters, 33 units, 6 constraints, 37 tests) preserved unchanged.

## What changed in v0.2.0

### Covers manifest declaration (15 primary entries)

```json
"covers": {
  "primary": [
    {"concept": "set", "scope": "set theory primitive"},
    {"concept": "set theory", "scope": "naive and working set theory"},
    {"concept": "subset", "scope": "set inclusion relation"},
    {"concept": "cardinality", "scope": "size of sets"},
    {"concept": "function", "scope": "set-theoretic mapping"},
    {"concept": "relation", "scope": "binary relations on sets"},
    {"concept": "propositional logic", "scope": "truth-functional logic"},
    {"concept": "predicate logic", "scope": "first-order with quantifiers"},
    {"concept": "quantifier", "scope": "universal and existential"},
    {"concept": "validity", "scope": "logical validity"},
    {"concept": "logical consequence", "scope": "semantic entailment"},
    {"concept": "truth table", "scope": "evaluation of propositions"},
    {"concept": "material implication", "scope": "logical conditional"},
    {"concept": "De Morgan's laws", "scope": "set and logical duality"},
    {"concept": "countable set", "scope": "infinite cardinality"}
  ],
  "secondary_auto_indexed": true
}
```

### Scope: foundational substrate

This package is designed as the formal-language layer underneath `math_proof_core`, and as substrate for `probability_stats_foundations_core` and `calculus_real_analysis_core`. Scope qualifiers explicitly mark this lineage:

- **Naive/working set theory**, NOT axiomatic ZFC. Axioms of choice, replacement, foundation, and large cardinal axioms are out of scope.
- **Classical propositional + predicate logic**, NOT modal, intuitionistic, or fuzzy logic.
- **Function as set-theoretic mapping**, NOT calculus's continuous/differentiable functions or programming functions.

### Anticipated cross-package overlaps

| Concept | This package's scope | Future package's likely scope |
|---|---|---|
| `cardinality` | size of sets | `combinatorics_discrete_structures_core`: counting |
| `function` | set-theoretic mapping | `calculus_real_analysis_core`: real-valued analysis |
| `set` | set theory primitive | `combinatorics_discrete_structures_core`: as combinatorial object |

When those packages are updated, queries like "what is a function?" will surface multiple homes with distinguishing scopes — the user (or the retrieval pipeline) chooses the appropriate frame.

### What's NOT in covers (deliberate)

- **Axiomatic set theory** (ZFC, axiom of choice, large cardinals) — package is naive/working
- **Modal logic, intuitionistic logic, fuzzy logic** — package is classical only
- **Proof techniques** (induction, contradiction, contrapositive) — substrate for a future `math_proof_core`; this package gives the *language* used in proofs (validity, inference) but not the techniques themselves
- **Specific inference rules** (modus ponens, modus tollens) — covered by `validity` and `logical consequence` umbrellas; specific names auto-indexed via cluster/unit content
- **Equivalence relations / partial orders** as separate entries — auto-indexed under `relation`
- **`logic` as a bare umbrella** — too broad (could mean programming logic, philosophical logic). Specific entries `propositional logic` and `predicate logic` are tighter.

### Feature aliases added (4 load-bearing units)

To make user-friendly covers entries match unit features for validation cleanliness:

| Unit | Features added |
|---|---|
| `u_set` | `set theory` |
| `u_proposition` | `propositional logic` |
| `u_predicate` | `predicate logic`, `first-order logic` |
| `u_countable_uncountable` | `countable set`, `countably infinite`, `uncountable set` |

The cluster and unit labels are unchanged — these are additive feature aliases that improve `secondary_auto_indexed` recall and make `covers.primary` entries match content cleanly.

## Verification

| Suite | v0.1.0 | v0.2.0 |
|---|---|---|
| Schema (v0.3.1 §11) | 0 errors | 0 errors |
| Covers validation (warnings) | n/a | 0 warnings |
| Internal `tests.jsonl` | 37/37 | **37/37** (preserved) |
| Cross-package routing simulation | n/a | clean — STL claims foundational concepts; correctly does NOT claim Turing machine, dynamic programming, overfitting, graph, or chromatic number |

## Coverage (unchanged from v0.1.0)

8 clusters · 33 units · 6 constraints · 4 trajectories · 5 relations · 11 transitions · 37 tests.

## merge_intent

```json
{
  "type": "extension",
  "base_package": "set_theory_logic_core",
  "base_version": "0.1.0",
  "source_added": "covers_metadata_addition",
  "merge_date": "2026-05-02",
  "covers_added": true,
  "refinements": 4,
  "summary": "Added covers manifest (15 primary entries) and 4 feature-alias additions on load-bearing units."
}
```
