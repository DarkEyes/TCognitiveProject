# ml_core v0.1.0

**Domain:** Machine learning (classical statistical learning theory frame)
**Founding source:** Abu-Mostafa, Magdon-Ismail & Lin, *Learning From Data: A Short Course* (AMLbook, 2012)
**Status:** Draft. Not yet expert-vetted. Founded on a single source.
**Protocol:** TCog Schema v0.3, TCog Ingestion v0.3.

---

## What this package is

`ml_core` is a TCog basis package for machine learning — installed to be activated as a cognitive frame, not a knowledge dump. It provides:

- **119 anchored units** — distinctions the source genuinely deploys
- **19 clusters** — basis-state coordinates, each with default behavior, activation policy, and frame limits
- **13 constraints** — admissibility rules, including 6 high-severity (the data-snooping family)
- **26 transitions** — typed edges between clusters
- **7 trajectories** — reusable reasoning paths (top-level, feasibility diagnosis, overfitting diagnosis, data-snooping audit, model selection, sampling-bias diagnosis, VC analysis)
- **13 relations** — refinements and conflicts within and across the package
- **12 tests** — including non-activation tests for grief and emergency triage to verify package overreach prevention

## What this package is NOT

This is v0.1, founded on a single source. It reflects Abu-Mostafa et al's specific commitments: classical PAC framing, VC-style generalization analysis, regularization-as-Occam, three named hygiene principles. It does not yet cover:

- Bayesian learning, model evidence, posterior inference
- Deep learning, neural network architectures, learned features
- Kernel methods (beyond their feature-transform interpretation)
- Reinforcement learning, online learning, bandits
- Causal inference, identification
- Modern empirical phenomena like benign overparametrization

These are intentional v0.1 scope limits, declared in the manifest's `frame_limits`. The user intends to extend this package via merge ingestion of additional sources, at which point conflicts (notably: deep-learning observations vs Occam-as-architectural-principle, modern generalization theories vs strict VC) will surface as `conflicts_with` relations rather than silent overrides.

## Build history

This package was built in two protocol passes following TCog Ingestion v0.3:

**Pass 1 (extraction):** 17 chunks corresponding to the book's 5 chapters + Appendix A. Chunked by sub-section to keep each chunk in the 2,000–5,000 word range. Each unit anchored to a specific source location with a copyright-safe excerpt under 280 characters.

| Chunk | Section | Units | Notes |
|---|---|---|---|
| 1 | §1.1 | 13 | Frame setup: target function, hypothesis set, perceptron, PLA |
| 2 | §1.2 | 5 | Learning paradigms (supervised, unsupervised, RL, etc.) |
| 3 | §1.3 | 12 | Feasibility: bin model, Hoeffding, in/out-of-sample, fixed-h vs chosen-g |
| 4 | §1.4 | 9 | Error measures, noisy targets, joint distribution |
| 5 | §2.1 | 17 | VC machinery: dichotomy, growth function, Sauer, VC dimension, VC bound |
| 6 | §2.2 | 10 | Bound interpretation: sample complexity, complexity penalty, test set |
| 7 | §2.3 | 9 | Bias-variance, learning curves |
| 8 | §3.1–3.2 | 6 | Pocket, linear regression, pseudoinverse |
| 9 | §3.3 | 6 | Logistic regression, gradient descent, SGD |
| 10 | §3.4 | 5 | Nonlinear transform, Z-space, transform-data-independence |
| 11 | §4.1 | 5 | Overfitting, deterministic noise, simpler-model-wins |
| 12 | §4.2 | 6 | Regularization, augmented error, weight decay |
| 13 | §4.3 | 5 | Validation, model selection, cross-validation |
| 14 | §5.1 | 3 | Occam's razor, non-falsifiability |
| 15 | §5.2 | 2 | Sampling bias |
| 16 | §5.3 | 5 | Data snooping (umbrella for 4+ constraints from earlier chapters) |
| 17 | App A | 1 | VC proof three-lemma decomposition |

**Pass 2 (consolidation):** Cluster formation, constraint extraction, transition derivation, trajectory derivation, relation typing, test generation, index construction.

## Reading order

The lazy reading-order trajectory `tr_top_level_reading` traces the book's spine:

```
k_learning_problem_setup → k_learning_paradigms → k_data_generation → k_error_measure
→ k_generalization_concern → k_in_out_sample → k_h_complexity
→ k_test_set_estimation → k_bias_variance
→ k_linear_classification → k_linear_regression → k_logistic_regression → k_nonlinear_transform
→ k_overfitting → k_regularization → k_validation_and_model_selection
→ k_occam → k_sampling_bias → k_data_snooping
```

For active reasoning, prefer the targeted trajectories (feasibility diagnosis, overfitting diagnosis, data-snooping audit, etc.) over the top-level reading-order one.

## High-severity constraints

The package's structural backbone is six high-severity admissibility constraints, all variants of "data used for a decision is no longer data for evaluating that decision":

- `c_iid_sampling_required` — train/test distribution match required for VC bounds
- `c_no_hoeffding_on_chosen_g` — Hoeffding applies to fixed h, not data-dependent g
- `c_test_set_must_be_held_out` — test set valid only if no decisions used it (`blocks_answer: true`)
- `c_validation_not_test` — validation contamination grows with decisions made
- `c_transform_must_be_data_independent` — Φ chosen before seeing data
- `c_lambda_chosen_independently` — λ via validation, not E_in
- `c_no_data_dependent_choices` — umbrella for the family above (`blocks_answer: true`)

Plus medium-severity constraints around scope (VC binary-only, bias-variance squared-loss-only, separability before PLA), error-measure specification, and sample complexity heuristic.

## Known epistemic posture

- **Honest frame limits.** The package's `frame_limits` declares this is classical statistical learning theory only, not balanced contemporary ML.
- **Source-grade, not expert-vetted.** Status is `draft`. Vetting requires an ML domain expert reviewing the cluster organization, constraint severities, and unit definitions.
- **Heuristic principles preserved as heuristics.** The N ≥ 10·d_VC rule of thumb, Occam's razor, and the empirical claim that "lower d_VC tends to generalize better in practice" are all flagged as heuristic, not theorem.
- **Anticipated conflicts with future merges flagged.** Several units' notes anticipate that deep-learning, Bayesian, or modern-generalization sources will refine or conflict with v0.1's claims. These should surface as relations on merge.

## File layout

```
ml_core/
  manifest.json          # package metadata, activation policy, frame limits
  units.jsonl            # 119 anchored units
  clusters.jsonl         # 19 clusters with cues, negative cues, default behavior
  constraints.jsonl      # 13 admissibility rules
  transitions.jsonl      # 26 typed cluster edges
  trajectories.jsonl     # 7 reusable reasoning paths
  relations.jsonl        # 13 refinements and contrasts
  tests.jsonl            # 12 activation/non-activation/constraint tests
  index.json             # mechanical retrieval surface (cues, negative cues, triggers)
  README.md              # this file
```

## Suggestions for vetting and merge

Before promoting this package to `human_vetted` or `expert_vetted`:

1. Have an ML domain expert review the 19 cluster organization, particularly the split between `k_h_complexity` (worst-case capacity) and `k_bias_variance` (averaged-case decomposition).
2. Validate that the 6 high-severity constraints cover the major operational hygiene failures observed in real ML pipelines.
3. Run the 12 tests against a retrieval system to verify activation behavior and non-activation guards.

For merge ingestion of subsequent sources:

1. **Bishop PRML or Murphy** — expect refinement of bias-variance terminology (`u_bias` as `(ḡ−f)²` vs `ḡ−f`), conflicts on probabilistic vs frequentist framing
2. **ESL (Hastie/Tibshirani/Friedman)** — expect refinement of regularization (lasso vs ridge), additions to model selection (AIC, BIC), additions to learning curves
3. **Goodfellow et al deep learning** — expect conflicts on Occam-as-architectural-principle, expect promotion of `u_gradient_descent` and `u_sgd` to a separate `k_optimization` cluster
4. **Causal inference sources** — expect refinement of `u_sampling_bias_principle` with selection-on-the-outcome distinctions

Each merge should produce a `delta` document per the protocol (additions, refinements, conflicts, branches) for user review before commit.
