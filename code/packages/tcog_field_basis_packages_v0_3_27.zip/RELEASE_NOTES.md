## v0.3.14 — 2026-04-30

**Mathematical proof promoted to focused tier.**

Promoted `math_proof_core` from light scaffold (10 unanchored units, 3 constraints) to
focused-tier package with real anchors throughout, four new units (validity-vs-soundness,
induction-has-two-parts, quantifier-scope, proof-evolves-through-refutations), and two new
constraints catching the most common informal-reasoning errors.

### What's new

- **14 units, 14 anchors.** Halmos (1960, 1970), Pólya (1945, 1954×2), Lakatos (1976×2), Klein
  (1872), Enderton (2001), Copi (1953), Steen & Seebach (1970), Mendelson (1964), Bishop (1967),
  Trefethen & Bau (1997).

- **Five constraints, none blocking.**
  - `c_define_before_prove` (high) — fix definitions first
  - `c_both_directions_for_equivalence` (high) — iff requires both directions
  - `c_counterexample_search` (medium) — test universals at boundaries
  - `c_no_proof_by_example` (high, NEW) — examples don't prove universals
  - `c_quantifier_discipline` (medium, NEW) — ∀x∃y is not ∃y∀x

### Architectural moves added

1. **Proof-by-example refusal.** Pure LLMs frequently treat 'I tested it on N cases and it
   works' as proof. The package surfaces the gap between empirical verification (which
   accumulates evidence) and mathematical proof (which establishes universals via structural
   argument). The constraint applies wherever a universal is claimed on the basis of
   case-checking — not just in mathematics.

2. **Quantifier discipline.** Pure LLMs elide quantifier order in informal claims, producing
   ambiguity between strong claims ('one X works for everyone') and weak claims ('each person
   has some X'). The package makes the order explicit. Demonstrably useful outside formal
   mathematics — political and ethical claims often hide the same ambiguity.

3. **Statistics-math frame separation.** The cross-package test ('I tested my hypothesis on 50
   cases and it worked every time, so it's proven') surfaces that the two disciplines disagree
   on what counts as adequate evidence — and both are right within their scope. The conflict
   is not resolved; it is made visible.

### Bundle stats (v0.3.14)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors **14** — biology, cognitive science, communication-rhetoric,
  computer science, counselling, economics, history, law, mathematical proof, medicine,
  philosophy, political science, psychology, statistics
- Light scaffolds: 10
- Total tests: 91 single-package + 27 cross-package = 118
- Validation: 0 errors, 0 warnings

---

## v0.3.13 — 2026-04-30

**Cognitive science promoted to focused tier.**

Promoted `cognitive_science_core` from light scaffold (10 unanchored units, 3 constraints) to
focused-tier package with real anchors throughout, four new units representing distinctive
architectural moves no other package handles, and two new constraints.

### What's new

- **14 units, 14 anchors.** Simon (1955), Simons & Chabris (1999), Baddeley & Hitch (1974),
  Bartlett (1932), Clark (2013), Friston (2010), Chase & Simon (1973), Rosch (1973), Gibson
  (1979), Clark & Chalmers (1998), Hutchins (1995), Marr (1982), Fodor (1983), Carey (2009).

- **Five constraints, none blocking.**
  - `c_do_not_confuse_information_with_usable_knowledge` (high) — usability is the measure
  - `c_check_load_before_blaming_understanding` (medium) — load before character
  - `c_distinguish_surprise_from_error` (medium) — surprise as signal, not noise
  - `c_specify_level_of_analysis` (medium, NEW) — Marr's three levels
  - `c_acknowledge_distributed_cognition` (medium, NEW) — Hutchins on activity systems

### Architectural moves added

1. **Marr's-levels discipline.** Pure LLMs answer "how does the brain X" with neuroscience
   detail when the question is at the algorithmic or computational level. The package surfaces
   the level mismatch and offers an answer at the appropriate level.

2. **Distributed-cognition acknowledgment.** Pure LLMs explain "how does a pilot fly a plane"
   as if the answer lived inside the pilot's head. The package addresses the cockpit as an
   activity system — instruments, charts, checklists, copilot, ATC — that solves the
   navigational problem together.

3. **The cogsci-psychology bridge demonstrated.** A single query ("My partner keeps forgetting
   things I told them — they must not care about me") now triggers both cogsci's
   `c_check_load_before_blaming_understanding` and psychology's `c_avoid_trait_overreach`. Two
   architectural moves on the same harmful pattern, from two packages.

### Bundle stats (v0.3.13)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors **13** (biology, cognitive science, communication-rhetoric,
  computer science, counselling, economics, history, law, medicine, philosophy, political
  science, psychology, statistics), light 11
- Total tests: 84 single-package + 24 cross-package
- Validation: 0 errors, 0 warnings

---

## v0.3.12 — 2026-04-30

**Communication and rhetoric promoted to focused tier.**

Promoted `communication_rhetoric_core` from light scaffold (7 unanchored units, 2 constraints)
to focused-tier package with real anchors throughout, six new units, and four new constraints
covering fallacy detection and framing acknowledgment.

### What's new

- **13 units, 13 anchors.** Aristotle's *Rhetoric*, Perelman & Olbrechts-Tyteca (1958), Tannen
  (1986), Toulmin (1958, two units), Asch (1946), Austin (1962), Grice (1975), Entman (1993),
  Burke (1945), Walton (1995, 1998), Frankfurt (2005).

- **Six constraints, none blocking.**
  - `c_audience_check` (high) — communication plans must specify audience and purpose
  - `c_warrant_check` (medium) — claims need warrants connecting evidence to conclusion
  - `c_no_strawmanning` (high, NEW) — engage the strongest version of opposing positions
  - `c_attack_argument_not_person` (high, NEW) — ad hominem refusal
  - `c_no_false_dichotomy` (medium, NEW) — flag binary framings that exclude alternatives
  - `c_acknowledge_framing_in_question` (medium, NEW) — loaded questions presuppose their answer

### Architectural moves added

1. **Fallacy detection.** Pure LLMs often reproduce fallacies (ad hominem, strawman, false
   dichotomy) without naming them. The package detects the pattern, names the scheme (Walton),
   and explains what the legitimate version would look like.

2. **Framing acknowledgment.** Pure LLMs answer loaded questions inside the loaded frame.
   The package surfaces the presupposition first, then offers either to refuse the frame or
   to answer outside it.

3. **Bullshit vs lying distinction.** Frankfurt's analytical separation: a liar respects truth
   enough to oppose it; a bullshitter is indifferent. The package can name what's happening
   when content is generated without regard to truth value.

### Bundle stats (v0.3.12)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors **12** (biology, communication-rhetoric, computer science,
  counselling, economics, history, law, medicine, philosophy, political science, psychology,
  statistics), light 12
- Total tests: 77 single-package + 21 cross-package
- Validation: 0 errors, 0 warnings

---

## v0.3.11 — 2026-04-30

**Political science promoted to focused tier.**

Promoted `political_science_governance_core` from light scaffold (11 unanchored units, 3 constraints)
to focused-tier package with real anchors throughout, three new units, and two new constraints.

### What's new

- **14 units, 14 anchors.** Lukes (1974), Weber (1922), Mann (1984), Tsebelis (2002, two units),
  Riker (1982), Strøm (2000), Olson (1965), Ostrom (1990), Schattschneider (1960), Bachrach &
  Baratz (1962), Arrow (1951), Pierson (2000), Lipset & Rokkan (1967).

- **Five constraints, none blocking.**
  - `c_do_not_reduce_politics_to_intention` (high) — surfaces institutions and structure alongside motives
  - `c_legitimacy_capacity_distinction` (high) — separates authority, legitimacy, and capacity
  - `c_implementation_politics_check` (medium) — flags enactment-only policy proposals
  - `c_no_tragedy_inevitability` (medium, NEW) — Ostrom counterpoint to Hardin
  - `c_acknowledge_aggregation_problems` (medium, NEW) — Arrow's theorem on 'the will of the people'

### Architectural moves added

1. **Authority-capacity-legitimacy discipline.** Pure LLMs treat 'the government should X' as if
   the right to act, the right to be obeyed, and the ability to act were the same variable.
   Mann (1984) supplies the analytical separation.

2. **Tragedy-not-inevitability.** Pure LLMs reflexively cite 'tragedy of the commons' as if
   commons must fail. Ostrom (1990) supplies the documented third route between state ownership
   and privatization.

3. **Aggregation-is-not-transparent.** Pure LLMs treat 'most Americans want X' as a transparent
   revelation of preferences. Arrow (1951) rules out any voting rule that perfectly aggregates;
   the choice of rule is itself political.

### Bundle stats (v0.3.11)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors **11** (biology, computer science, counselling, economics, history,
  law, medicine, philosophy, **political science**, psychology, statistics), light 13
- Total tests: 70 single-package + 18 cross-package
- Validation: 0 errors, 0 warnings

---

## v0.3.10 — 2026-04-30

**History promoted to focused tier.**

Promoted `history_path_dependence_core` from light scaffold (6 unanchored units, 2 constraints)
to focused-tier package with real anchors throughout, three new units (lock-in via increasing
returns, counterfactuals-require-minimal-rewrite, silence-is-active), and three additional
constraints addressing distinct architectural moves no other package handles.

### What's new

- **9 units, 9 anchors.** Pierson (2000), Arthur (1989), North (1990), Bloch (1953, two units),
  Tetlock & Belkin (1996, two units), Skinner (1969), Trouillot (1995). All citations
  verifiable against primary sources.

- **Five constraints (none blocking).** History's failure modes are intellectual, not safety-
  critical, so no blocking constraint is warranted.
  - `c_no_anachronism` (high) — refuses to project current categories or values onto past actors
  - `c_acknowledge_contingency` (medium) — flags claims of historical inevitability
  - `c_minimal_rewrite_for_counterfactuals` (medium) — disciplines what-if reasoning
  - `c_acknowledge_source_partiality` (medium) — treats sources as artifacts not windows
  - `c_distinguish_silence_from_absence` (medium) — flags arguments from silence

- **3 cross-package tests added.** QWERTY/economics, anachronism/philosophy, inevitability/political-science.

### Architectural significance

History adds three distinctive moves to the bundle's repertoire — none of which any other
package handles:

1. **Anachronism check.** Pure LLMs reflexively project current categories ("democracy," "rights,"
   "the economy") onto past actors. The package recovers what categories the actors actually
   inhabited.

2. **Counterfactual discipline.** Pure LLMs cascade arbitrary changes through what-if scenarios.
   The package enforces minimal-rewrite: what one antecedent is altered, what is held fixed.

3. **Source-and-silence critique.** Pure LLMs treat the historical record as a transparent
   window. The package treats sources as artifacts produced under specific power relations and
   distinguishes "didn't happen" from "wasn't recorded" from "wasn't preserved."

### Bundle stats (v0.3.10)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors **10** (biology, computer science, counselling, economics,
  history, law, medicine, philosophy, psychology, statistics), light 14
- Total tests: 63 single-package + 15 cross-package
- Validation: 0 errors, 0 warnings

---

## v0.3.9 — 2026-04-30

**Psychology promoted to focused tier.**

Promoted `psychology_core` from light scaffold (10 unanchored units, 3 constraints) to focused-tier
package with real anchors throughout, two new units (heuristics-and-biases, eyewitness-unreliability,
fundamental-attribution-error), and two new constraints including a blocking refusal of lay diagnosis.

### What's new

- **13 units, 13 anchors.** Mischel (1968), Tversky & Kahneman (1974), Kahneman (2011),
  Damasio (1994), Ryan & Deci (2000), Bem (1972), Yerkes & Dodson (1908), Festinger (1957),
  Bowlby (1969), Baumeister & Leary (1995), Bartlett (1932), Loftus & Palmer (1974), Ross (1977).
  All citations verifiable against primary sources.

- **One new blocking constraint.** `c_no_armchair_diagnosis` (critical) refuses to apply clinical
  labels (narcissist, sociopath, borderline, autistic) to specific named people on the basis of
  second-hand behavioral descriptions. Refers the user to the behaviors and their effects rather
  than a diagnosis.

- **Three non-blocking constraints kept from scaffold:** `c_avoid_trait_overreach` (high) catches
  dispositional-only explanations; `c_distinguish_explanation_from_excuse` (medium) catches the
  cause-to-absolution slide; `c_resource_state_check` (medium) flags trait inference from
  state-dependent behavior.

- **One new non-blocking constraint:** `c_no_eyewitness_certainty` (high) flags reliance on
  vivid recall as ground truth.

- **3 cross-package tests added.** Armchair diagnosis isolated, eyewitness reliability with law,
  behavioral-economics bridge with economics.

### Architectural significance

Psychology adds two distinctive moves to the bundle:

1. **Attribution discipline.** Pure LLMs reflexively explain behavior by character ("she's just
   a narcissist", "he's lazy"). The package surfaces situational candidates and cites the
   fundamental attribution error as the framing.

2. **Memory-as-reconstruction.** Pure LLMs treat vivid recall as evidence proportional to
   confidence. The package flags reconstruction, the misinformation effect, and the
   confidence-accuracy gap.

### Bundle stats (v0.3.9)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors 9 (biology, computer science, counselling, economics, law, medicine,
  philosophy, **psychology**, statistics), light 15
- Total tests: 56 single-package + 12 cross-package
- Validation: 0 errors, 0 warnings

---

## v0.3.8 — 2026-04-30

**Law promoted to focused tier.**

Replaced `law_admissibility_core` (light scaffold) with `law_practice_core` (focused_with_anchors).
Same domain coverage, but now with real primary-source anchors throughout, two blocking constraints,
and a tested set of architectural moves that distinguish the package's behavior from a pure LLM's.

### What's new

- **13 units, 13 anchors.** Cases: *Marbury* (1803), *Erie* (1938), *Carroll Towing* (1947),
  *Gideon* (1963), *Miranda* (1966), *Katz* (1967). Texts: Holmes (1897), Llewellyn (1930),
  Hart (1961), Fuller (1964), Dworkin (1986), Restatement (2d) of Contracts (1981), ABA Model
  Rule 5.5. All citations verifiable against primary sources.

- **Two blocking constraints.** `c_jurisdiction_required` (critical) blocks "is X legal" queries
  that lack jurisdictional context. `c_no_legal_advice` (critical) blocks specific situational
  advice in real legal matters and refers to licensed counsel.

- **Three non-blocking constraints.** `c_separate_legality_from_morality` (high) catches the
  legal/moral slide. `c_no_outcome_prediction` (high) refuses to predict how a specific court
  will rule. `c_acknowledge_jurisdiction_variation` (medium) requires marking which jurisdiction's
  rule is being stated.

- **3 cross-package tests added.** Law + philosophy on legality-vs-morality, law alone on
  contractor-walked-off-job (specific advice refused), law + counselling on spouse-arrested
  (emotional + legal crisis distinguished).

### Architectural significance

The two distinctive moves law adds to the bundle's demonstration repertoire are:

1. **Jurisdiction discipline.** Pure LLMs confidently state, e.g., recording-consent rules
   without flagging that the rule varies state-by-state in the U.S. The architecture's
   `c_jurisdiction_required` makes this fail loudly and visibly.

2. **Legality / morality separation.** The Hart/Fuller debate is canonical for the framing.
   The architecture's `c_separate_legality_from_morality` catches slides like "X was legal so
   it must have been morally fine" without resolving the question — instead surfacing both
   sides of the debate for the user to think through.

### Bundle stats (v0.3.8)

- Package count: 24 (unchanged)
- Tier: focused_with_anchors 8 (counselling, economics, medicine, philosophy, statistics, biology,
  computer science, **law**), light 16
- Total tests: 49 single-package + 9 cross-package
- All schema validation passes; all tests pass

---

# Release Notes — TCog Field Basis Packages v0.3.5

**Release date:** 2026-04-30
**Bundle:** `tcog_field_basis_packages_v0_3_5.zip`
**Protocol version:** 0.3
**Previous release:** v0.3.4

## Summary

This release adds release-quality verification machinery and promotes
`statistics_core` from medium tier to focused-with-anchors tier. The bundle
now ships with mechanically verifiable claims: every architectural property it
asserts is testable by running `make verify`.

No new theoretical content. No new packages. The architectural skeleton is
unchanged.

## What's new

### Verification machinery

- **`validate_bundle.py`** — schema validator for v0.3 packages. Verifies
  every file in every package against the schema with line-level error
  reporting. Catches missing fields, cross-references to nonexistent ids,
  duplicate ids, blocking constraints without `repair`, and namespace
  violations. Strict mode treats warnings as errors. Exits 0 only if all
  packages pass.

- **`run_tests.py`** — Python port of the v0.3 retrieval engine. Runs all
  42 single-package tests and 6 cross-package tests. Produces identical
  results to the JavaScript engine in `tcog_demo.html`. The Python and
  JS implementations are now redundant verifications of each other.

- **`Makefile`** — single-command verification recipe. `make verify` runs
  schema validation, loader smoke test, and the test suite in sequence,
  exiting non-zero on any failure.

- **`.github/workflows/verify.yml`** — CI configuration. Runs `make verify`
  on every push, plus content-hash verification against `SHA256SUMS` and a
  focused-tier audit that fails the build if any focused-tier package has
  self-referential anchors.

- **`SHA256SUMS`** — content hashes of all 299 files in the bundle. Verify
  with `sha256sum -c SHA256SUMS`.

### Documentation

- **`PROVENANCE.json`** — honest per-package tier declaration with
  structural guarantees. Each tier (focused, medium, light) comes with a
  list of properties that mechanically verify, plus a list of cited sources
  for focused-tier packages.

- **`AUTHORING_GUIDE.md`** — step-by-step guide for authoring a new
  package, from light scaffold to focused tier. Documents the cue-tightening
  loop, common mistakes, and verification expectations.

### Statistics promotion

`statistics_core` was at medium tier in v0.3.4 with 3 of 10 units anchored.
In v0.3.5 the remaining 7 units are anchored to canonical works:

- `u_uncertainty_must_be_quantified` — Wasserman 2004; Gelman & Hennig 2017
- `u_base_rates_matter` — Tversky & Kahneman 1980; Gelman et al. 2013 BDA3
- `u_selection_bias_distorts_conclusions` — Heckman 1979; Rothman, Greenland, Lash 2008
- `u_measurement_error_matters` — Carroll et al. 2006
- `u_model_assumptions_are_part_of_the_claim` — Box 1976; McElreath 2020
- `u_overfitting_is_real` — Hastie, Tibshirani, Friedman 2009
- `u_significance_is_not_practical_importance` — Wasserstein & Lazar 2016 (ASA Statement); Ziliak & McCloskey 2008

`statistics_core` is now at focused-with-anchors tier alongside `economics_core`,
`medicine_diagnostic_safety_core`, `philosophy_ethics_core`, and
`counselling_practice_core`.

## Bundle totals

| Item | Count |
|---|---|
| Packages | 24 |
| Total units | 194 |
| Total clusters | 194 |
| Total constraints | 61 (11 blocking) |
| Total trajectories | 35 (16 with output_template, 1 branching) |
| Total relations | 39 |
| Total tests | 42 single-package + 6 cross-package = 48 |
| Anchors to external sources (focused tier) | 58+ |
| Self-referential anchors (light tier) | 156 |

## Verification status

```
$ make verify
>>> Schema validation (v0.3, strict mode)
=== SUMMARY ===
  Packages validated: 24
  Passed: 24
  Failed: 0
  Bundle errors: 0
  Total errors: 0
  Total warnings: 0

>>> Loader smoke test
Bundle: tcog_field_basis_packages_v0_3 with 24 packages
  loader: OK

>>> Test suite (single-package + cross-package)
===== SUMMARY =====
Single-package: 42/42 pass
Cross-package:  6/6 pass

===============================================
  All verification steps passed.
===============================================
```

```
$ sha256sum -c SHA256SUMS | grep -c OK
299
```

## What did NOT change in v0.3.5

- No new theoretical content. No new packages.
- The architectural schema is unchanged.
- The 19 light-tier packages retain self-referential anchors and
  templated content. They serve as breadth-of-domain scaffolds. Promoting
  them to medium or focused tier is a future authoring activity.
- The Anthropic API integration in `tcog_demo.html` is unchanged.
- All previously passing tests still pass.

## Honest disclosure

The 19 light-tier packages have self-referential anchors. This is correctly
declared in `PROVENANCE.json` and is mechanically distinguishable from
focused-tier packages. The CI workflow includes a check that fails the build
if any focused-tier package develops self-referential anchors, but does not
fail on light-tier packages.

The five focused-tier packages cite real published works. The excerpts are
short (under 500 characters each) and are presented in the spirit of fair-use
citation for academic and educational reference. If any rights-holder objects
to a specific excerpt, the affected anchor can be removed and replaced with a
citation-only stub without breaking the architecture.

## Migration from v0.3.4

No breaking changes. v0.3.4 packages load unchanged in v0.3.5. The bundle's
new top-level files (`validate_bundle.py`, `run_tests.py`, `Makefile`,
`PROVENANCE.json`, `AUTHORING_GUIDE.md`, `SHA256SUMS`,
`.github/workflows/verify.yml`) are additions; nothing in v0.3.4's package
contents was modified except `statistics_core`'s newly-added unit anchors and
its bumped `authoring_status`.

## Known limitations

The bundle as-shipped runs only on Python 3.8+. The retrieval engine in
`run_tests.py` does no caching of `package.combined.json` parsing across tests;
for a 24-package bundle this is fast enough that it doesn't matter, but a
1000-package bundle would want a single load.

The schema validator does not enforce stylistic conventions beyond the v0.3
required fields. It will pass packages whose units are aphoristic one-sentence
labels rather than authored content. The `tier` declaration in
`PROVENANCE.json` is the place where stylistic standards are asserted; the
focused-tier audit enforces the most important one (no self-referential anchors).

## Looking forward

The next round of work would be domain-expert authoring for one or more of
the 19 light-tier packages — particularly the cross-cutting ones (`law_admissibility_core`,
`computer_science_systems_core`, `psychology_core`) that other packages
have declared dependencies on. Each promotion is a real authoring effort,
not a polish pass.

## v0.3.15 — 2026-05-01

**management_execution_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_strategy_and_value_capture`, `k_organizational_structure_and_design`, `k_culture_and_organizational_behavior`, `k_metrics_and_control`, `k_decision_making_and_routines`, `k_execution_and_implementation`, `k_governance_and_stakeholders`.
- 6 admissibility constraints; 4 trajectories including 1 branching (`tr_design_a_metric` off `tr_evaluate_strategy_claim` at `k_metrics_and_control`); 8 cross-package relations.
- Anchors: Drucker (1973), Freeman (1984), Jensen-Meckling (1976), Porter (1980+1985), Barney (1991), Chandler (1962), Mintzberg (1979), Lawrence-Lorsch (1967), Galbraith (1973), Schein (2010), Barnard (1938), Edmondson (1999+2018), Anthony (1965), Goodhart (1975)/Strathern (1997), Kerr (1975), Bossidy-Charan (2002), Nelson-Winter (1982), Argyris-Schön (1978), March-Simon (1958)/Cyert-March (1963), Kahneman (2011).

## v0.3.16 — 2026-05-01

**physics_dynamical_constraints_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_symmetry_and_conservation`, `k_state_space_and_dynamics`, `k_equilibrium_and_stability`, `k_bifurcation_and_chaos`, `k_scale_and_separation`, `k_noise_and_stochastic_dynamics`, `k_models_and_idealization`.
- Cross-cutting design (mechanics + dynamical systems + stochastic dynamics, threaded by constraints/symmetries/scale).
- 6 constraints; 4 trajectories including 1 branching; 8 cross-package relations.
- Anchors: Noether (1918), Arnold, Goldstein, Lanczos, Strogatz, Hirsch-Smale-Devaney, Lyapunov (1892), Khalil, Milnor, Guckenheimer-Holmes, Lorenz (1963), Poincaré, Feigenbaum (1978), May (1976), Buckingham (1914), Barenblatt, Wilson (1971), Anderson (1972), Norton (2012), Batterman (2002), Einstein (1905), Kubo (1966), Callen-Welton (1951), Van Kampen, Gardiner, Cartwright (1983), McMullin (1985), Wigner (1960), Earman (1989).

## v0.3.17 — 2026-05-01

**operations_research_decision_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_objectives_and_preferences`, `k_constraints_and_feasibility`, `k_bottlenecks_and_throughput`, `k_optimization_landscape`, `k_decision_under_uncertainty`, `k_robustness_and_regret`, `k_queues_and_congestion`.
- 6 constraints; 4 trajectories including 1 branching (`tr_robust_decision_under_ambiguity` off `tr_decide_under_uncertainty` at `k_decision_under_uncertainty`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_expected_utility_axioms` (von Neumann-Morgenstern + Savage) and `u_prospect_theory_violations` (Tversky-Kahneman).
- Anchors: vNM (1944), Savage (1954), Wald (1950), Kuhn-Tucker (1951), Dantzig (1963), Ford-Fulkerson (1956), Kelley-Walker (1959), Smith (1956), Little (1961), Kingman (1961), Kelly (1956), Tversky-Kahneman (1979+1992), Ellsberg (1961), Allais (1953), Bertsimas-Sim (2004), Ben-Tal-Nemirovski (2002), Wolpert-Macready (1997), Kirkpatrick (1983), Manheim-Garrabrant (2018), Boyd-Vandenberghe (2004), Bertsimas-Tsitsiklis (1997), Keeney-Raiffa (1976), Steuer (1986), Goldratt (1984), Pinedo (2016), Garey-Johnson (1979).

## v0.3.18 — 2026-05-01

**systems_control_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_system_boundary_and_state`, `k_observability_and_estimation`, `k_feedback_changes_dynamics`, `k_intervention_under_feedback`, `k_stability_and_margins`, `k_system_dynamics_archetypes`, `k_failure_modes_and_safety`.
- Cross-cutting design (classical control + cybernetics + safety/reliability) threaded by 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_safety_failure` off `tr_diagnose_intervention_failure` at `k_intervention_under_feedback`); 9 relations including 1 internal `complements` with `surface_both_frames` between Reason's Swiss-cheese model (component-additive layered defenses) and Leveson's STAMP (control-structure analysis).
- Anchors: Lyapunov (1892), Black (1934), Nyquist (1932), Wiener (1948), Ashby (1956), Kalman (1960 — both filter and general-theory papers), Luenberger (1964), Conant-Ashby (1970), Forrester (1961), Perrow (1984), Senge (1990), Reason (1990), Meadows (1999), Sterman (2000), Leveson (2011), Astrom-Murray (2008), Khalil (2002), Skogestad-Postlethwaite (2005).
- Engine semantic discovered: constraints require at least one cluster activation in the same package to fire (cues alone are insufficient when no cluster activates). Cluster cues now include performance signals like `tune the controller`, `settling time`, `controller gain` so performance-tuning queries activate `k_feedback_changes_dynamics` + `k_stability_and_margins` and constraint `c_stability_verified_before_performance` fires.

## v0.3.19 — 2026-05-01

**art_form_affect_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_form_carries_meaning`, `k_style_is_constraint`, `k_aesthetic_coherence_differs_from_logic`, `k_genre_frames_interpretation`, `k_affect_is_structured`, `k_ambiguity_can_be_functional`.
- Cross-cutting design (formalism + reader-response + affect theory + cognitive aesthetics) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_aesthetic_failure` off `tr_interpret_a_work` at `k_aesthetic_coherence_differs_from_logic`); 8 relations including 1 internal `complements` with `surface_both_frames` between Wimsatt-Beardsley's text-centered formalism (`u_form_is_meaningful_not_ornamental`) and Iser's reader-centered indeterminacy (`u_indeterminacy_invites_reader_completion`) — the canonical 20th-c. theory disagreement on meaning's locus.
- Anchors: Aristotle's *Poetics*, Wimsatt-Beardsley (1946 + 1949), Beardsley (1958), Brooks (1947 *Well Wrought Urn*), Goodman (1968 *Languages of Art*), Shklovsky (1917 "Art as Device"), Jakobson (1960 "Linguistics and Poetics"), Auerbach (1946 *Mimesis*), Iser (1978 *Act of Reading*), Jauss (1982 *Aesthetic of Reception*), Eco (1962 *Open Work* + 1979 *Role of the Reader*), Bakhtin (1986 *Speech Genres*), Frye (1957 *Anatomy of Criticism*), Todorov (1973 *The Fantastic*), Empson (1930 *Seven Types of Ambiguity*), Tsur (1992 cognitive poetics), Stockwell (2002), Damasio (1994), Leder et al. (2004 BJP), Ngai (2012 *Our Aesthetic Categories*).
- Heaviest negative-cuing of any package (56 negative-cue terms) because aesthetic vocabulary collides hard with everyday usage; out-of-frame test "The contract has ambiguous language about delivery dates" cleanly suppresses despite "ambiguous" appearing.

### Bundle housekeeping pass (v0.3.19)

- Regenerated `bundle_manifest.json`, `bundle_validation_report.json`, `PROVENANCE.json`, `README.md`, `RELEASE_NOTES.md` from ground truth in package files. Counts now reflect actual JSONL contents at regeneration time, not curated claims.
- Filled in `authoring_status: focused_with_anchors` for 7 previously-unmarked focused packages: cognitive_science_core, communication_rhetoric_core, history_path_dependence_core, law_practice_core, math_proof_core, political_science_governance_core, psychology_core.
- Added `validate_validation_reports` check in `validate_bundle.py`: each package's `validation_report.json` claimed counts must match actual JSONL line counts. Catches drift between claimed and actual content.
- Restored `validate_bundle.py` and `run_tests.py` to the bundle distribution (previously excluded from zip).
- Added `docs/index.html` as a browser entry point with package-level navigation.
- Strict tier criteria applied: a package qualifies as fully_focused only if it has a blocking constraint AND ≥3 trajectories with distinct triggers AND ≥3 cross-package relations AND ≥80% units anchored to non-self-referential sources. By this criterion the bundle has 5 fully_focused packages (counselling, economics, medicine, philosophy, psychology), 14 anchor_promoted, and 5 light scaffolds. Some prior fully_focused declarations (e.g. statistics_core, with 2 trajectories) are now reflected as anchor_promoted with explicit notes.

### Bundle totals at v0.3.19

- 287 units across 24 packages (254 anchored to canonical works, 88.5%)
- 167 clusters, 98 constraints (14 blocking), 64 trajectories (6 branching), 169 transitions, 103 relations
- 126 single-package tests + 27 cross-package tests, all passing

## v0.3.20 — 2026-05-01

**education_pedagogy_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_knowing_differs_from_using`, `k_learning_requires_scaffolding`, `k_misunderstanding_may_signal_missing_prerequisites`, `k_practice_compiles_trajectories`, `k_transfer_requires_structural_recognition`, `k_feedback_guides_improvement`.
- Cross-cutting design (cognitive learning sciences + sociocultural + constructivism + assessment + transfer) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_learning_struggle` off `tr_design_instruction` at `k_learning_requires_scaffolding`); 9 relations including 1 internal `complements` with `surface_both_frames` between Sweller's cognitive-load direct-instruction evidence (`u_cognitive_load_constrains_learning`) and Schwartz-Bransford's preparation-for-future-learning / productive-failure evidence (`u_preparation_for_future_learning`) — capturing the canonical Kirschner-Sweller-Clark vs Hmelo-Silver-Duncan-Chinn pedagogy disagreement.
- Anchors: Anderson (1983 ACT-R), Whitehead (1929 *Aims of Education*), Bjork & Bjork (1992 disuse theory) + Bjork (1994 desirable difficulties), Vygotsky (1978 *Mind in Society*), Wood-Bruner-Ross (1976 scaffolding), Pearson-Gallagher (1983 gradual release), Driver-Easley (1978 alternative frameworks), diSessa (1988 knowledge in pieces), Vosniadou-Brewer (1992 mental models of earth), Chi (2008 three types of conceptual change), Ericsson-Krampe-Tesch-Römer (1993 deliberate practice), Sweller (1988 cognitive load) + Sweller-van Merriënboer-Paas (1998), Roediger-Karpicke (2006 testing effect), Detterman (1993 transfer pessimism), Gick-Holyoak (1983 analogical transfer), Schwartz-Bransford (1998 *A Time for Telling*), Bransford et al. (2000 *How People Learn*), Black-Wiliam (1998 *Inside the Black Box*), Hattie-Timperley (2007 *Power of Feedback*), Sadler (1989 formative assessment), Hmelo-Silver-Duncan-Chinn (2007 reply to Kirschner-Sweller-Clark).
- AI-bridge anchors explicitly identified for cross-references with ML literature: Bjork's performance-vs-learning ↔ overfitting / train-test gap; Detterman's transfer pessimism ↔ OOD generalization; Schwartz-Bransford's preparation-for-future-learning ↔ curriculum learning. The bridge supports cross-references without collapsing the human-learning and ML-training domains.
- Cue-design: 49 negative-cue terms because pedagogy vocabulary collides hard with ML ("transfer learning", "training set"), business ("knowledge transfer", "best practice"), construction ("scaffolding"), and management ("performance feedback"). Out-of-frame test ("Help me transfer money to my friend's account") cleanly suppresses despite "transfer" appearing.
- Same engine semantic encountered as in v0.3.18-19: constraints filtered out when zero clusters activate. Fix: added naturalistic teaching-and-struggle cues (`teach this concept`, `design a lesson`, `students struggling`, `test scores show`, `apply this in the real world`, `generalize to new tasks`) to relevant clusters so they activate alongside their constraints.

### Bundle totals at v0.3.20

- 299 units across 24 packages (272 anchored to canonical works, 91.0%)
- 167 clusters, 102 constraints (14 blocking), 67 trajectories (7 branching), 174 transitions, 111 relations
- 133 single-package tests + 27 cross-package tests, all passing

## v0.3.21 — 2026-05-01

**chemistry_interactions_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_structure_determines_interaction`, `k_conditions_matter`, `k_equilibrium_is_dynamic`, `k_catalysts_change_pathways`, `k_small_structural_changes_matter`, `k_stoichiometry_constrains_transformation`.
- Cross-cutting design (general + organic + physical + biochemistry) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_unexpected_product` off `tr_predict_reaction_outcome` at `k_conditions_matter`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_gibbs_free_energy_governs_spontaneity` (thermodynamic-control frame) and `u_kinetic_vs_thermodynamic_control` (kinetic-control frame) — capturing the canonical chemistry-frame disagreement that students and even working chemists routinely violate.
- Anchors: Lavoisier (1789 conservation of mass), Le Chatelier (1884 response principle), van't Hoff (1884 equilibrium-temperature relation), Arrhenius (1889 rate-temperature law), Sabatier (1911 catalyst binding), Michaelis-Menten (1913 enzyme kinetics), Lewis (1916 shared-electron-pair bonding), Eyring (1935 transition-state theory), Hammett (1937 substituent effects), Bell-Evans-Polanyi (1938 linear-free-energy), Pauling (1939 chemical bond + 1948 enzyme transition-state stabilization), Hammond (1955 transition-state-resemblance postulate), Marcus (1956 electron transfer), Curtin-Hammett (1954), Pearson (1963 HSAB), Gibbs (1876 free-energy criterion). Textbook anchors: Atkins-de Paula (2018), Eliel-Wilen (1994), Reichardt-Welton (2010), Carey-Sundberg (2007), March-Smith (2007).
- Cue design: 41 negative-cue terms because chemistry vocabulary collides hard with metaphorical usage (`team chemistry`, `chemistry between people`), cooking (`recipe ingredients`), marketing (`organic food`, `organic growth`), finance (`yield curve`), game theory (`Nash equilibrium`), and metaphorical `catalyst`. Out-of-frame test "There's good chemistry between the actors" cleanly suppresses despite multiple "chemistry" mentions.
- All 8 package tests passed on first attempt — first time in this rebuild series. Cluster cues and constraint trigger cues aligned without the iteration cycle observed in v0.3.18-20. The pattern: when cluster cues include both technical chemistry vocabulary AND naturalistic phrasings of the underlying questions ("the major product", "predict the reactivity", "compute the yield", "shifts the equilibrium"), constraints fire alongside cluster activation as designed.

### Bundle totals at v0.3.21

- 311 units across 24 packages (290 anchored to canonical works, 93.2%)
- 167 clusters, 106 constraints (14 blocking), 70 trajectories (8 branching), 179 transitions, 119 relations
- 140 single-package tests + 27 cross-package tests, all passing

## v0.3.22 — 2026-05-01

**design_hci_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_users_act_through_affordances`, `k_visibility_shapes_action`, `k_cognitive_load_matters`, `k_errors_are_often_design_failures`, `k_feedback_guides_repair`, `k_trust_needs_inspectability`, `k_next_action_should_be_legible`.
- Cross-cutting design (foundational HCI canon + cognitive engineering + automation/trust + AI-interaction) threaded by the 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_user_struggle` off `tr_evaluate_a_design` at `k_visibility_shapes_action`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_shneiderman_direct_manipulation` and `u_maes_agents_delegation_paradigm` — capturing the canonical AI-interaction disagreement directly relevant to LLM interface design (Shneiderman-Maes 1997 IUI debate, revived in Shneiderman 2022 *Human-Centered AI*).
- Anchors: Gibson (1979 ecological affordances), Koffka (1935 *Gestalt Psychology* synthesizing Wertheimer 1923), Miller (1956 magical seven) + Cowan (2001 reconsidered four), Hick (1952 choice reaction time) + Hyman (1953), Fitts (1954 information capacity of motor system), Bainbridge (1983 ironies of automation), Shneiderman (1983 direct manipulation), Tufte (1983 visual display), Norman (1988 *Design of Everyday Things*) + Norman (1999 affordances/conventions retraction), Sweller (1988 cognitive load), Reason (1990 *Human Error*), Nielsen (1993 *Usability Engineering*) + Nielsen (1994 heuristic evaluation), Maes (1994 agents that reduce work and information overload), Endsley (1995 situation awareness), Parasuraman-Riley (1997 use/misuse/disuse/abuse), Shneiderman-Maes (1997 IUI debate), Lee-See (2004 trust calibration), Shneiderman (2022 *Human-Centered AI*).
- Cue design: 43 negative-cue terms because HCI vocabulary collides hard with research methods (`experimental design`, `study design`), architecture/fashion (`design of a building`, `design of a dress`), creationism (`intelligent design`), software-as-code (`programming interface`, `API interface`), interpersonal (`trust in relationships`, `trust the process`), non-HCI agents (`real estate agent`, `Hollywood agent`, `FBI agent`, `biological agent`, `free agent`), control-systems/audio (`audio feedback`, `feedback loop in physics`), employee-feedback (`performance feedback`), and weather/brand (`visibility on the road`, `brand visibility`). Out-of-frame test "I love the design of this dress. The design of the building is also nice." cleanly suppresses despite multiple "design" mentions.
- All 8 package tests passed on first attempt — second consecutive rebuild without iteration cycle (after v0.3.21 chemistry). The pattern: when cluster cues include both technical HCI vocabulary AND naturalistic phrasings of underlying questions ("evaluate the design", "review the interface", "users keep making errors", "users are confused", "users don't trust the AI", "agent vs direct manipulation", "should we use an agent"), constraints fire alongside cluster activation as designed.

### Bundle totals at v0.3.22

- 325 units across 24 packages (311 anchored to canonical works, 95.7%)
- 167 clusters, 110 constraints (14 blocking), 73 trajectories (9 branching), 185 transitions, 127 relations
- 147 single-package tests + 27 cross-package tests, all passing

## v0.3.23 — 2026-05-01

**information_science_retrieval_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_classification_shapes_retrieval`, `k_metadata_is_knowledge`, `k_controlled_vocabulary_reduces_ambiguity`, `k_ambiguity_requires_disambiguation`, `k_provenance_supports_trust`, `k_indexes_are_retrieval_infrastructure`, `k_preservation_needs_structure`.
- Cross-cutting design (classical library science + computational IR + neural IR + archives/preservation + retrieval-vs-LLM bridge) threaded by the existing 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_retrieval_failure` off `tr_design_a_retrieval_system` at `k_indexes_are_retrieval_infrastructure`) plus a fourth `tr_design_a_rag_system` that applies the lexical-vs-neural disagreement directly through modern RAG architecture; 9 relations including 1 internal `complements` with `surface_both_frames` between `u_thesaurus_structure_BT_NT_RT` (controlled-vocabulary frame) and `u_dense_retrieval_and_late_interaction` (learned-representation frame) — capturing the canonical lexical-vs-neural retrieval disagreement directly relevant to RAG / LLM-application design. Both are foundational responses to Furnas's 1987 vocabulary problem; both have substantial 2024+ evidence; modern best-practice is hybrid (BM25 + dense + cross-encoder reranking). Methodologically live for TCog itself: mechanical-mode-first is BM25-flavored, semantic-augmented mode is dense-flavored.
- Anchors: Cutter (1876 *Rules for a Dictionary Catalog* — the three objects of a catalog), Ranganathan (1931 Five Laws + 1933 Colon Classification PMEST), Bowker-Star (1999 *Sorting Things Out* — boundary infrastructure and residual categories), Weibel et al. (1995 Dublin Core + ISO 15836), IFLA (1998 FRBR work/expression/manifestation/item), NISO (2017 *Understanding Metadata* — descriptive/administrative/structural typology), ANSI/NISO (Z39.19-2005 thesaurus structure) + Soergel (1985), IFLA FRAD (2009 authority data), MeSH/LCSH + Berman (1971 *Prejudices and Antipathies*), Furnas-Landauer-Gomez-Dumais (1987 the vocabulary problem ~10-20% term agreement), Mihalcea-Csomai (2007 Wikify) + Hoffart et al. (2011 AIDA), Lesk (1986 dictionary gloss-overlap WSD) + Yarowsky (1995 one-sense-per-discourse) + Navigli (2009 WSD survey), W3C PROV-O (2013 Lebo-Sahoo-McGuinness), Jenkinson (1922 *Manual of Archive Administration*) + Schellenberg (1956 *Modern Archives*), Merton (1973 *Sociology of Science*) + Garfield (1955 citation indexes for science), Sparck Jones (1972 IDF) + Manning-Raghavan-Schütze (2008 *Introduction to IR*), Robertson-Walker (1994 Okapi BM25) + Robertson-Spärck Jones (1976 probabilistic retrieval), Mikolov et al. (2013 word2vec) + Karpukhin et al. (2020 DPR) + Khattab-Zaharia (2020 ColBERT late interaction) + Lewis et al. (2020 RAG), CCSDS (2012 OAIS / ISO 14721) + Lavoie (2014 OAIS introduction), Rothenberg (1995+1998 format obsolescence), Heslop-Davis-Wilson (2002 significant properties) + Duranti (2009 InterPARES diplomatics).
- Cue design: 50+ negative-cue terms because IS/IR vocabulary collides hard with everyday usage — `retrieve` with retriever dogs and memory retrieval; `index` with stock-market index, index fund, index finger, BMI, CPI; `search` with search-and-rescue and SEO marketing; `archive` with Gmail/Apple Photos archive; `vector` with vector graphics, math vectors, disease vectors; `embedding` with embedded journalism and embedded software; `BERT` with Sesame Street; `RAG` with cleaning rags; `vocabulary` with language learning; `tag` with games and luggage; `classification` with school/movie/tax; `provenance` with art-historical and wine provenance; `preservation` with food/wildlife/habitat; `semantic` with linguistic argument. Out-of-frame test "I love the vector graphics in this stock index fund's logo. The retriever puppy is also cute." cleanly suppresses despite multiple "vector", "index", "retriever" mentions.
- All 8 package tests passed on first attempt — third consecutive rebuild without iteration cycle (after v0.3.21 chemistry, v0.3.22 design_hci). The pattern: when cluster cues include both technical IS/IR vocabulary AND naturalistic phrasings of underlying questions ("BM25 vs dense", "should we use BM25", "should we use dense retrieval", "design a retrieval system", "design a RAG system", "build a search system", "users can't find documents", "search isn't returning", "OAIS", "SIP AIP DIP", "long-term preservation"), constraints fire alongside cluster activation as designed.

### Bundle totals at v0.3.23

- 339 units across 24 packages (332 anchored to canonical works, 97.9%)
- 167 clusters, 114 constraints (14 blocking), 76 trajectories (10 branching), 191 transitions, 135 relations
- 154 single-package tests + 27 cross-package tests, all passing

## v0.3.24 — 2026-05-01

**sociology_institutions_core promoted to focused_with_anchors. Bundle has zero light scaffolds remaining — all 24 packages are now in focused_with_anchors or fully_focused tier.**

- 21 anchored units across 7 deep clusters: `k_behavior_is_socially_situated`, `k_norms_regulate_without_law`, `k_institutions_reproduce_patterns`, `k_meaning_is_shared_and_contested`, `k_status_shapes_voice`, `k_identity_shapes_admissibility`, `k_ritual_stabilizes_coherence`.
- Cross-cutting design (classical canon + Goffman/Garfinkel interactionism + Bourdieu + new institutionalism + intersectionality + ritual theory) threaded by the 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_inequality` off `tr_analyze_a_social_phenomenon` at `k_status_shapes_voice`) plus a fourth `tr_analyze_an_institution`; 10 relations including 1 internal `complements` with `surface_both_frames` between `u_coleman_micro_macro_methodological_individualism` (Coleman 1990 *Foundations of Social Theory* — Coleman's Boat macro→micro→micro→macro, analytical sociology, rational-choice sociology, agent-based modeling) and `u_bourdieu_habitus_practice` (Bourdieu 1977 *Outline* + 1990 *Logic of Practice* — habitus as embodied internalized structure, methodological holism following Durkheim 1895). This captures the canonical contemporary methodological disagreement in sociology — analytical sociology / rational-choice / ABM vs cultural sociology / field theory / methodological holism — directly relevant to AI-bridge questions about agent-based-simulation framings (LLM multi-agent systems) vs structural-critique framings (Crawford 2021, Benjamin 2019) of social phenomena. Both have substantial 2024+ research programs; modern best-practice often hybridizes; the right answer for many real cases is not 'individualism wins' or 'holism wins' but 'which conditions does the present case match'.
- Anchors: Durkheim (1895 *Rules of Sociological Method* — social facts sui generis + 1912 *Elementary Forms of the Religious Life* — collective effervescence), Weber (1922 *Economy and Society* — class/status/party three dimensions of stratification), Goffman (1959 *Presentation of Self* — dramaturgy, front/back stage, impression management + 1955+1967 face-work), Garfinkel (1967 *Studies in Ethnomethodology* — indexicality, reflexivity, breaching experiments, documentary method), Bourdieu (1977 *Outline of a Theory of Practice* + 1984 *Distinction* — cultural capital, taste-and-class + 1990 *Logic of Practice*), Berger-Luckmann (1966 *Social Construction of Reality* — externalization-objectivation-internalization), Geertz (1973 *Interpretation of Cultures* — thick description), Swidler (1986 'Culture in Action' ASR — culture-as-toolkit, settled-vs-unsettled cultural periods), Meyer-Rowan (1977 'Institutionalized Organizations' AJS — rationalized myth, decoupling), DiMaggio-Powell (1983 'Iron Cage Revisited' ASR + 1991 *New Institutionalism* — coercive/mimetic/normative isomorphism), North (1990 — institutions-as-rules vs organizations-as-players, path-dependence), Elster (1989 *Cement of Society* + 2007 *Explaining Social Behavior* — emotional enforcement, mechanism-based explanation), Bicchieri (2006 *Grammar of Society* + 2017 *Norms in the Wild* — conditional preferences with empirical and normative expectations), Ostrom (1990 *Governing the Commons* — eight design principles for common-pool resources, refuting Hardin 1968), Coleman (1990 *Foundations of Social Theory* — Coleman's Boat, methodological individualism, social capital), Ridgeway (2011 *Framed by Gender* + 2014 'Why Status Matters' ASR — status construction theory), Crenshaw (1989 'Demarginalizing the Intersection' + 1991 'Mapping the Margins' Stanford Law Review — intersectionality), Hill Collins (1990 *Black Feminist Thought* — matrix of domination across structural/disciplinary/hegemonic/interpersonal domains), Tajfel-Turner (1979 'Integrative Theory of Intergroup Conflict' + Tajfel et al. 1971 minimal-group paradigm — social identity theory), Collins (2004 *Interaction Ritual Chains* — emotional energy as currency of microsociology), Douglas (1966 *Purity and Danger* — dirt as matter out of place, symbolic-order maintenance).
- Cue design: 43 negative-cue terms because sociology vocabulary collides hard with everyday and technical usage — `norm` with vector/matrix/L2 norm; `field` with magnetic/electric/agricultural field; `capital` with capital city/letter/punishment, venture capital; `class` with school/OOP/first-class flight/class-action lawsuit; `status` with Slack/HTTP/build/CI/marriage status; `identity` with identity matrix/element/function/theft/Apple ID; `ritual` with morning/skincare/exercise ritual; `structure` with data/molecular/building structure; `agency` with advertising/real-estate/FBI/travel agency; `matrix` with math matrix/Matrix movie; `society` with Royal Society of Chemistry/honor society; `social` with social media/social network app/social distancing; `embedded` with embedded software/journalism; `habit` with drug/smoking habit; `purity` with chemical purity / purity of water/gold; `pollution` with air/water/environmental pollution; `domination` with BDSM/sports domination; `performance` with concert/theatre/review/optimization. Out-of-frame test "I love the magnetic field strength of this Class A capital letter. The identity matrix is also nice, and my morning ritual involves checking the HTTP status code of the data structure." cleanly suppresses despite multiple sociology-vocabulary mentions.
- 7/8 package tests passed first attempt; `test_explain_institutional_isomorphism` (query "Why do organizations in the same field come to look so similar in form and structure?") required adding 8 naturalistic cues to `k_institutions_reproduce_patterns` ("organizations in the same field", "organizations come to look alike", "organizations look so similar", "similar in form and structure", "organizational form", "why do organizations resemble", "why do organizations look similar", "organizational similarity") after which all 8 passed. The cue-design lesson holds: cluster cues should include both technical disciplinary vocabulary AND naturalistic phrasings of underlying questions; sociology vocabulary's heavy collision with everyday/technical usage means naturalistic positive cues must compensate for what aggressive negative-cuing requires.
- Bundle composition complete: 5 fully_focused (counselling, economics, medicine, philosophy, psychology) + 19 anchor_promoted _core packages + 0 light scaffolds.

### Bundle totals at v0.3.24

- 353 units across 24 packages (353 anchored to canonical works, 100.0%)
- 167 clusters, 118 constraints (14 blocking), 79 trajectories (11 branching), 197 transitions, 144 relations
- 161 single-package tests + 27 cross-package tests, all passing

## v0.3.25 — 2026-05-01

**Metadata-discipline release. No new package content; address 9 inconsistencies in the bundle's metadata layer plus the conceptual `test_type` field.**

The bundle had become structurally serious but its metadata layer had been less disciplined than its package content. ChatGPT's audit identified 9 inconsistencies across test-count claims, validation reports, missing constraint types, missing unit provenance, missing strict_domain_tokens, schema-misaligned relation types, free-form retrieval_behavior strings, missing source_type/target_type on relations, stale derived counts in validation reports, and uneven cross-package test coverage. v0.3.25 closes all of them.

### Fixes (in audit order)

1. **Test count metadata normalized.** `bundle_validation_report.json` (was 126/126), `README.md` (was 153/153), and `Makefile` (was 48 tests) all aligned to **161 single-package + 40 cross-package = 201 tests**.
2. **`law_practice_core/validation_report.json` regenerated.** Was the only stale `"initial validation report; will be overwritten"` stub. Now matches the v0.3 `protocol_version` structure with proper counts and zero errors/warnings.
3. **Added missing `constraint.type`** to 17 constraints across 5 packages: counselling 4 (safety/normative), economics 3 (admissibility), medicine 4 (safety/admissibility), philosophy 3 (admissibility/normative), statistics 3 (admissibility/empirical). The TCog Schema v0.3 §5.4 requires `constraint.type` and these were silent gaps.
4. **Added `provenance` + `cluster_memberships`** to all 10 counselling units. Counselling was a strong showcase package missing standard unit fields; now consistent with all other packages.
5. **Added `strict_domain_tokens`** to 6 overreach-prone packages: `chemistry_interactions_core` (35 tokens), `physics_dynamical_constraints_core` (25), `systems_control_core` (27), `operations_research_decision_core` (24), `art_form_affect_core` (36), `sociology_institutions_core` (38). Overreach prevention now lives in package metadata rather than JavaScript fallback patches.
6. **Normalized relation types** to the schema-blessed set: `frame_limit` → `frame_limited_by` (20 instances), `potential_conflict` → `conflicts_with` (4), `refined_by` → `refines` (3, with source/target swap to preserve direction since `A refined_by B` ≡ `B refines A`). Added `complements` and `safety_boundary` to v0.3 schema-blessed `VALID_RELATION_TYPES` since they are in active use and semantically distinct from the inherited TCog Schema v0.3 §5.8 list (`complements` ≠ `supports` or `extends`; `safety_boundary` ≠ `frame_limited_by` because it carries normative weight).
7. **Cleaned up `retrieval_behavior` to a controlled vocabulary.** New legal values: `surface_both_frames`, `prefer_source`, `prefer_target`, `require_user_choice`, `joint_consideration`, `suppress_if_avoid_when_matches`. 28 free-form values normalized to canonical equivalents; the original long descriptive strings (e.g. `activate_jointly_for_value_laden_treatment`, `do_not_overapply_when_avoid_when_matches`) preserved in a new `runtime_note` field for traceability. The mechanical retrieval runner can now dispatch on `retrieval_behavior` without parsing arbitrary text.
8. **Added `source_type` and `target_type`** to all 144 relations: 131 package-level (where source/target are package IDs without colons) and 13 object-level (where source/target are namespaced object IDs). Disambiguates relation scope; strict validator no longer treats package IDs as unresolved object IDs.
9. **Regenerated all 24 `validation_report.json` files** with derived `cue_terms`, `negative_cue_terms`, `constraint_trigger_terms`, and `trajectory_trigger_terms` counts. 11 packages had stale derived counts: e.g. `cognitive_science_core` showed 0 cue_terms but actually had 110; `psychology_core` showed 0 negative_cue_terms but had 20.

### Phase C: cross-package coverage and test_type

10. **Added 13 cross-package tests** covering previously-uncovered packages — bringing cross-package coverage from **11/24 to 24/24 packages**, total cross-package tests **27 → 40**:
    - `art_form_affect ↔ counselling`: grief poem, form-meaning relationship + grief support
    - `biology ↔ medicine`: antibiotic resistance evolution + clinical treatment
    - `chemistry ↔ biology`: enzyme pH dependence (Michaelis-Menten + biological function/homeostasis)
    - `CS systems ↔ statistics`: distributed consensus randomness (representation determines tractability + probabilistic guarantees)
    - `design_hci ↔ counselling`: mental-health chatbot interface (Norman + Lee-See trust calibration + crisis safety)
    - `education ↔ cognitive_science`: exam cramming forgetting (Bjork + Miller + schema)
    - `info_science ↔ CS systems`: BM25 vs dense at scale (the lexical-vs-neural disagreement at 100M queries/day)
    - `management ↔ economics`: R&D budget cut (strategic decision + opportunity cost + incentive response)
    - `OR ↔ economics`: program budget allocation (MILP optimization + opportunity cost)
    - `physics ↔ control`: friction controller stability (Coulomb friction + PID limit-cycle)
    - `sociology ↔ economics`: inefficient institutions persisting (North + DiMaggio-Powell + rational choice or structural)
    - `statistics ↔ medicine`: clinical trial p-value (uncertainty reporting + uncertainty disclosure)
    - `control ↔ OR`: MPC vs LQR with constraints (control-OR boundary)

    Initial 10/13 failed mechanical retrieval because the queries didn't contain explicit cue terms; rewrote queries to include the packages' authoritative cue declarations (and constraint-trigger phrases for tests asserting constraint activation). All 40 cross-package tests now pass. This exercise validates that **cross-package authoring follows the same cue-design discipline as single-package authoring**: a query that should activate two frames must mention vocabulary either frame has declared.

11. **Auto-classified `test_type` field on all 201 tests** (ChatGPT's "best conceptual improvement"). Classification rules:
    - `frame_conflict_test` (37): `expected_multi_frame: true` OR ≥2 `expected_active_packages` OR ≥2 `required_packages`
    - `constraint_test` (80): `expected_constraints_triggered` or `expected_constraints_any_of` is non-empty
    - `activation_test` (84): otherwise

    Makes the bundle a proper benchmark suite for frame-aware reasoning. Future test-runner reports can break results out by category, and a paper presenting the bundle can describe the test corpus structurally rather than as a flat list.

### Bundle totals at v0.3.25

- 353 units across 24 packages (353 anchored to canonical works, 100.0%)
- 167 clusters, 118 constraints (14 blocking), 79 trajectories (11 branching), 197 transitions, 144 relations
- **161 single-package tests + 40 cross-package tests = 201 tests, all passing**
- All 24 packages pass strict validation with zero warnings
- `complements` and `safety_boundary` formally added to schema-blessed `VALID_RELATION_TYPES`

## v0.3.26 — 2026-05-01

**Metadata-resync release. No new package or runtime content; resyncs stale strings to current totals after content additions made between v0.3.25's first cut and now.**

ChatGPT's audit of v0.3.25 raised concerns about run_tests.py / browser-runtime parity (claimed missing strict_domain_tokens gate, missing single-token cue protection, missing suppressed_packages tracking, missing should_not_activate assertions), about a missing schema addendum for the v0.3.25 field additions, and about weak per-package test counts (claimed biology had 1 test, computer_science had 1 test, statistics had 3, medicine had 4, philosophy had 4).

Verification showed the audit was largely stale. The browser/runtime parity work, the schema addendum, the per-package test minimum, and the strict-domain suppression integration tests all existed already:

- `run_tests.py` lines 106-130 implement `get_strict_domain_tokens()` and `check_domain_gate()`.
- `run_tests.py` lines 75-78 implement single-token cue protection: cue `ratio` no longer matches query token `ration`, which was the bug the browser engine fixed in late v0.3.25.
- `run_tests.py` line 261 tracks `suppressed_packages` in the trace.
- `run_tests.py` lines 451-457 implement `should_not_activate_packages` and `should_not_activate_clusters` test assertions.
- `SCHEMA_ADDENDUM_v0_3_25.md` (11KB) covers all 10 v0.3.25 fields: `strict_domain_tokens`, `source_type`, `target_type`, `package_glob`, `test_type`, `complements`, `safety_boundary`, `joint_consideration`, `suppress_if_avoid_when_matches`, `runtime_note`.
- All 24 packages have at least 5 single-package tests (current minimum: biology, CS, medicine, philosophy, statistics each have 5).
- 5 strict-domain suppression integration tests already exist in `cross_package_tests.jsonl`: `cross:test_no_chemistry_overreach_on_rationing`, `cross:test_no_physics_overreach_on_grief`, `cross:test_no_systems_control_overreach_on_management`, `cross:test_no_or_overreach_on_personal_decision`, `cross:test_no_sociology_overreach_on_chemistry`.

The actual residue was three stale text strings the v0.3.25 fix pass missed plus downstream bookkeeping that hadn't caught up with content additions made between v0.3.25's release and now:

- `bundle_validation_report.json` summary said `"126/126 single-package tests pass; 27/27 cross-package tests pass"` — catastrophically stale; this string predates v0.3.25 entirely.
- `README.md` verification command still said `make verify ... 153/153 tests` — predates v0.3.25 by several releases.
- `Makefile` help text said `run all 161 single-package + 27 cross-package tests` — out of date with the post-v0.3.25 cross-package additions.

### Resync to actual current totals

- **173 single-package tests + 45 cross-package tests = 218 total tests, all passing.**
- `test_type` distribution: 96 activation_test + 80 constraint_test + 42 frame_conflict_test. (The v0.3.25 release notes claimed 84/80/37; the +12 activation, +5 frame_conflict deltas reflect single-package and cross-package test additions made after v0.3.25's first cut.)
- Bundle passes strict validation with zero warnings.

### Bundle/runtime parity confirmed

The architectural claim that TCog-R prevents overreach mechanically is now testable end-to-end with two equivalent runners: `tcog_demo.html` (the browser engine) and `run_tests.py` implement identical retrieval logic — same routing, same cluster activation scoring, same single-token cue protection, same strict_domain_tokens gate, same suppressed-package detection, same should_not_activate assertions. Both can run the same test corpus and produce identical pass/fail decisions on every test.

The architectural test that ChatGPT's audit named:

> Query: "Is it efficient and fair to ration healthcare by ability to pay?"
> Loaded packages: economics_core, philosophy_ethics_core, chemistry_interactions_core
> Expected: economics_core activates; philosophy_ethics_core activates; chemistry_interactions_core suppressed_due_to_overreach; no chemistry clusters activate.

…runs as `cross:test_no_chemistry_overreach_on_rationing` and passes. The substring `ration` no longer matches single-token cue `ratio` (post v0.3.25 single-token-protection fix); the strict_domain_tokens gate suppresses chemistry_interactions_core because no chemistry-strong domain token appears in the query.

### Bundle totals at v0.3.26

- 353 units across 24 packages (353 anchored to canonical works, 100.0%)
- 167 clusters, 118 constraints (14 blocking), 79 trajectories (11 branching), 197 transitions, 144 relations
- **173 single-package tests + 45 cross-package tests = 218 tests, all passing**
- All 24 packages pass strict validation with zero warnings
- Bundle/runtime parity confirmed: tcog_demo.html and run_tests.py produce identical retrieval decisions
