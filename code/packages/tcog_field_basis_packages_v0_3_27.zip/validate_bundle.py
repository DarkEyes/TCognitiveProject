#!/usr/bin/env python3
"""
TCog v0.3 schema validator.

Validates every file in every package against the protocol schema and produces
a pass/fail report. Designed to be:
- Run from the bundle root with no arguments
- Exit code 0 only if all packages pass
- Produce per-package and per-file error lists with line numbers
- Catch the kinds of drift that produce silent breakage (missing fields,
  cross-references to nonexistent ids, etc.)

Usage:
  python3 validate_bundle.py [--strict] [--package PKG] [--quiet]

Exit codes:
  0 — all packages pass all checks
  1 — one or more packages have errors
  2 — bundle-level errors (manifest issues, missing files)
"""
import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


# Required fields per file type. Empty value means "field must exist", checked
# below. Lists indicate "field must be a list" (possibly empty).
UNIT_REQUIRED = {'id', 'label', 'definition', 'anchors'}
CLUSTER_REQUIRED = {'id', 'label', 'description', 'members', 'cues',
                    'default_behavior', 'activation_policy'}
CONSTRAINT_REQUIRED = {'id', 'label', 'rule', 'severity'}
TRAJECTORY_REQUIRED = {'id', 'label', 'description', 'trigger', 'path'}
TRANSITION_REQUIRED = {'id', 'from', 'to'}
RELATION_REQUIRED = {'id', 'source', 'target', 'type'}
TEST_REQUIRED = {'id', 'input'}

VALID_SEVERITIES = {'low', 'medium', 'high', 'critical'}
VALID_RELATION_TYPES = {
    # schema-aligned (TCog Schema v0.3 §5.8)
    'supports', 'extends', 'refines', 'contrasts_with', 'conflicts_with',
    'depends_on', 'supersedes', 'frame_limited_by',
    # v0.3.25 additions to schema (in active use, semantically distinct)
    'complements', 'safety_boundary',
    # legacy (still accepted; will be normalized away in future passes)
    'potential_conflict', 'refined_by', 'frame_limit',
}
VALID_AUTHORING_STATUS = {'light', 'medium', 'focused_with_anchors',
                           'focused', 'partial', 'extracted'}
VALID_QUALITY_LEVEL = {'extracted', 'reviewed', 'expert_vetted',
                        'axiom_bank_unvetted'}
VALID_LIFECYCLE_STATUS = {'draft', 'review', 'release_candidate', 'released',
                           'deprecated'}


class ValidationReport:
    """Accumulates errors and warnings per package, per file, with locations."""

    def __init__(self):
        self.bundle_errors: List[str] = []
        self.bundle_warnings: List[str] = []
        # package_id -> file -> list of (line_or_index, message)
        self.errors: Dict[str, Dict[str, List[Tuple[Any, str]]]] = {}
        self.warnings: Dict[str, Dict[str, List[Tuple[Any, str]]]] = {}

    def err(self, pkg: str, file: str, where: Any, msg: str) -> None:
        self.errors.setdefault(pkg, {}).setdefault(file, []).append((where, msg))

    def warn(self, pkg: str, file: str, where: Any, msg: str) -> None:
        self.warnings.setdefault(pkg, {}).setdefault(file, []).append((where, msg))

    def bundle_err(self, msg: str) -> None:
        self.bundle_errors.append(msg)

    def bundle_warn(self, msg: str) -> None:
        self.bundle_warnings.append(msg)

    def total_errors(self) -> int:
        n = len(self.bundle_errors)
        for pkg_errs in self.errors.values():
            for file_errs in pkg_errs.values():
                n += len(file_errs)
        return n

    def total_warnings(self) -> int:
        n = len(self.bundle_warnings)
        for pkg_warns in self.warnings.values():
            for file_warns in pkg_warns.values():
                n += len(file_warns)
        return n

    def package_passed(self, pkg: str) -> bool:
        return pkg not in self.errors

    def render(self, quiet: bool = False) -> str:
        out = []
        if self.bundle_errors:
            out.append("=== BUNDLE ERRORS ===")
            for m in self.bundle_errors:
                out.append(f"  ✗ {m}")
            out.append("")
        if self.bundle_warnings and not quiet:
            out.append("=== BUNDLE WARNINGS ===")
            for m in self.bundle_warnings:
                out.append(f"  ⚠ {m}")
            out.append("")

        all_pkgs = sorted(set(self.errors.keys()) | set(self.warnings.keys()))
        for pkg in all_pkgs:
            if pkg in self.errors:
                out.append(f"=== {pkg}: FAIL ===")
                for file, errs in sorted(self.errors[pkg].items()):
                    for where, msg in errs:
                        loc = f"{file}" if where is None else f"{file}:{where}"
                        out.append(f"  ✗ {loc} — {msg}")
            elif pkg in self.warnings and not quiet:
                out.append(f"=== {pkg}: PASS (with warnings) ===")
            if pkg in self.warnings and not quiet:
                for file, warns in sorted(self.warnings[pkg].items()):
                    for where, msg in warns:
                        loc = f"{file}" if where is None else f"{file}:{where}"
                        out.append(f"  ⚠ {loc} — {msg}")
            if pkg in self.errors or (pkg in self.warnings and not quiet):
                out.append("")
        return '\n'.join(out)


def load_jsonl_with_lines(path: Path) -> List[Tuple[int, Dict[str, Any]]]:
    """Load a JSONL file and return list of (line_number, parsed_object).
    Skips empty lines. Raises ValueError on JSON parse errors with line number."""
    out = []
    with open(path) as f:
        for i, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                out.append((i, json.loads(stripped)))
            except json.JSONDecodeError as e:
                raise ValueError(f"line {i}: {e.msg}")
    return out


def validate_id_namespace(item_id: str, package_id: str, expected_kind: str) -> Optional[str]:
    """Validate that an id has the expected namespace and prefix."""
    if not isinstance(item_id, str):
        return f"id must be a string, got {type(item_id).__name__}"
    if ':' not in item_id:
        return f"id '{item_id}' missing colon namespace separator"
    ns, local = item_id.split(':', 1)
    if ns != package_id:
        return f"id '{item_id}' has namespace '{ns}', expected '{package_id}'"
    if not local.startswith(expected_kind):
        return f"id '{item_id}' local part should start with '{expected_kind}' (e.g. {expected_kind}_something)"
    return None


def validate_manifest(pkg_dir: Path, package_id: str, report: ValidationReport) -> Dict[str, Any]:
    """Validate manifest.json. Returns parsed manifest if valid."""
    mpath = pkg_dir / 'manifest.json'
    if not mpath.exists():
        report.err(package_id, 'manifest.json', None, "file does not exist")
        return {}
    try:
        m = json.loads(mpath.read_text())
    except json.JSONDecodeError as e:
        report.err(package_id, 'manifest.json', f'line {e.lineno}', f"JSON parse error: {e.msg}")
        return {}

    required = ['package_id', 'name', 'version', 'protocol_version', 'domain',
                'description', 'activation_policy']
    for field in required:
        if field not in m:
            report.err(package_id, 'manifest.json', field, "required field missing")

    if m.get('package_id') != package_id:
        report.err(package_id, 'manifest.json', 'package_id',
                   f"package_id '{m.get('package_id')}' does not match directory name '{package_id}'")

    if m.get('protocol_version') != '0.3':
        report.warn(package_id, 'manifest.json', 'protocol_version',
                    f"protocol_version is '{m.get('protocol_version')}', expected '0.3'")

    auth = m.get('authoring_status')
    if auth is not None and auth not in VALID_AUTHORING_STATUS:
        report.err(package_id, 'manifest.json', 'authoring_status',
                   f"unknown authoring_status '{auth}', expected one of {sorted(VALID_AUTHORING_STATUS)}")

    ql = m.get('quality_level')
    if ql is not None and ql not in VALID_QUALITY_LEVEL:
        report.err(package_id, 'manifest.json', 'quality_level',
                   f"unknown quality_level '{ql}', expected one of {sorted(VALID_QUALITY_LEVEL)}")

    lc = m.get('lifecycle_status')
    if lc is not None and lc not in VALID_LIFECYCLE_STATUS:
        report.err(package_id, 'manifest.json', 'lifecycle_status',
                   f"unknown lifecycle_status '{lc}'")

    activate_policy = m.get('activation_policy', {})
    if not isinstance(activate_policy, dict):
        report.err(package_id, 'manifest.json', 'activation_policy',
                   "must be an object")
    else:
        for f in ('activate_when', 'avoid_when'):
            if f not in activate_policy:
                report.warn(package_id, 'manifest.json', f'activation_policy.{f}',
                            "field missing (recommended for retrieval)")

    return m


def validate_units(pkg_dir: Path, package_id: str, report: ValidationReport) -> Dict[str, Dict[str, Any]]:
    """Validate units.jsonl. Returns dict of unit_id -> unit."""
    upath = pkg_dir / 'units.jsonl'
    if not upath.exists():
        report.err(package_id, 'units.jsonl', None, "file does not exist")
        return {}

    try:
        items = load_jsonl_with_lines(upath)
    except ValueError as e:
        report.err(package_id, 'units.jsonl', None, str(e))
        return {}

    units = {}
    for line_no, u in items:
        for field in UNIT_REQUIRED:
            if field not in u:
                report.err(package_id, 'units.jsonl', line_no,
                           f"unit missing required field '{field}'")
        uid = u.get('id', '')
        err = validate_id_namespace(uid, package_id, 'u_')
        if err:
            report.err(package_id, 'units.jsonl', line_no, err)
        if uid in units:
            report.err(package_id, 'units.jsonl', line_no,
                       f"duplicate unit id '{uid}' (also at line {units[uid][0]})")
            continue

        # Anchors
        anchors = u.get('anchors', [])
        if not isinstance(anchors, list):
            report.err(package_id, 'units.jsonl', line_no, "anchors must be a list")
        elif len(anchors) == 0:
            report.err(package_id, 'units.jsonl', line_no, "unit has empty anchors list")
        else:
            for j, a in enumerate(anchors):
                if not isinstance(a, dict):
                    report.err(package_id, 'units.jsonl', line_no,
                               f"anchor {j} is not an object")
                    continue
                for af in ('type', 'source_id', 'excerpt'):
                    if af not in a:
                        report.err(package_id, 'units.jsonl', line_no,
                                   f"anchor {j} missing field '{af}'")
                # Excerpt length sanity
                excerpt = a.get('excerpt', '')
                if isinstance(excerpt, str):
                    if len(excerpt) > 500:
                        report.warn(package_id, 'units.jsonl', line_no,
                                    f"anchor {j} excerpt is {len(excerpt)} chars (recommend <500 for fair use)")
                    if len(excerpt) < 10:
                        report.warn(package_id, 'units.jsonl', line_no,
                                    f"anchor {j} excerpt is suspiciously short ({len(excerpt)} chars)")

        # Definition
        defn = u.get('definition', '')
        if not isinstance(defn, str):
            report.err(package_id, 'units.jsonl', line_no, "definition must be a string")
        elif len(defn.strip()) < 10:
            report.warn(package_id, 'units.jsonl', line_no, "definition is suspiciously short")

        units[uid] = (line_no, u)

    return {uid: u for uid, (_, u) in units.items()}


def validate_clusters(pkg_dir: Path, package_id: str, unit_ids: Set[str],
                       report: ValidationReport) -> Dict[str, Dict[str, Any]]:
    cpath = pkg_dir / 'clusters.jsonl'
    if not cpath.exists():
        report.err(package_id, 'clusters.jsonl', None, "file does not exist")
        return {}

    try:
        items = load_jsonl_with_lines(cpath)
    except ValueError as e:
        report.err(package_id, 'clusters.jsonl', None, str(e))
        return {}

    clusters = {}
    for line_no, c in items:
        for field in CLUSTER_REQUIRED:
            if field not in c:
                report.err(package_id, 'clusters.jsonl', line_no,
                           f"cluster missing required field '{field}'")
        cid = c.get('id', '')
        err = validate_id_namespace(cid, package_id, 'k_')
        if err:
            report.err(package_id, 'clusters.jsonl', line_no, err)
        if cid in clusters:
            report.err(package_id, 'clusters.jsonl', line_no,
                       f"duplicate cluster id '{cid}'")
            continue

        # Members must reference real units
        for m in c.get('members', []):
            if m not in unit_ids:
                report.err(package_id, 'clusters.jsonl', line_no,
                           f"member '{m}' is not a unit in this package")

        # Cues must be list of strings
        cues = c.get('cues', [])
        if not isinstance(cues, list):
            report.err(package_id, 'clusters.jsonl', line_no, "cues must be a list")
        else:
            if len(cues) < 3:
                report.warn(package_id, 'clusters.jsonl', line_no,
                            f"cluster has only {len(cues)} cues (recommend ≥6 for retrieval)")
            for j, cue in enumerate(cues):
                if not isinstance(cue, str):
                    report.err(package_id, 'clusters.jsonl', line_no,
                               f"cue {j} is not a string")

        clusters[cid] = c

    return clusters


def validate_constraints(pkg_dir: Path, package_id: str, cluster_ids: Set[str],
                          report: ValidationReport) -> Dict[str, Dict[str, Any]]:
    cpath = pkg_dir / 'constraints.jsonl'
    if not cpath.exists():
        report.err(package_id, 'constraints.jsonl', None, "file does not exist")
        return {}

    try:
        items = load_jsonl_with_lines(cpath)
    except ValueError as e:
        report.err(package_id, 'constraints.jsonl', None, str(e))
        return {}

    constraints = {}
    for line_no, c in items:
        for field in CONSTRAINT_REQUIRED:
            if field not in c:
                report.err(package_id, 'constraints.jsonl', line_no,
                           f"constraint missing required field '{field}'")
        cid = c.get('id', '')
        err = validate_id_namespace(cid, package_id, 'c_')
        if err:
            report.err(package_id, 'constraints.jsonl', line_no, err)
        if cid in constraints:
            report.err(package_id, 'constraints.jsonl', line_no,
                       f"duplicate constraint id '{cid}'")
            continue

        sev = c.get('severity', '')
        if sev not in VALID_SEVERITIES:
            report.err(package_id, 'constraints.jsonl', line_no,
                       f"unknown severity '{sev}', expected one of {sorted(VALID_SEVERITIES)}")

        if c.get('blocks_answer') is True and sev not in ('high', 'critical'):
            report.err(package_id, 'constraints.jsonl', line_no,
                       f"blocks_answer=true requires severity in (high, critical), got '{sev}'")

        # If blocks_answer is true, repair must exist (otherwise the user has no way forward)
        if c.get('blocks_answer') is True:
            if not c.get('repair'):
                report.err(package_id, 'constraints.jsonl', line_no,
                           "blocks_answer=true requires non-empty 'repair' field")

        # Trigger cues should exist for retrieval
        if not c.get('trigger_cues') and not c.get('applies_to'):
            report.warn(package_id, 'constraints.jsonl', line_no,
                        "constraint has neither trigger_cues nor applies_to; will never fire")

        # related_clusters must be valid
        for r in c.get('related_clusters', []):
            if r not in cluster_ids:
                report.err(package_id, 'constraints.jsonl', line_no,
                           f"related_cluster '{r}' is not a cluster in this package")

        constraints[cid] = c

    return constraints


def validate_trajectories(pkg_dir: Path, package_id: str, cluster_ids: Set[str],
                           constraint_ids: Set[str],
                           report: ValidationReport) -> Dict[str, Dict[str, Any]]:
    tpath = pkg_dir / 'trajectories.jsonl'
    if not tpath.exists():
        report.err(package_id, 'trajectories.jsonl', None, "file does not exist")
        return {}

    try:
        items = load_jsonl_with_lines(tpath)
    except ValueError as e:
        report.err(package_id, 'trajectories.jsonl', None, str(e))
        return {}

    trajectories = {}
    for line_no, t in items:
        # Accept either 'trigger' (focused convention) or 'triggers' (axiom-bank convention)
        local_required = TRAJECTORY_REQUIRED - {'trigger'}
        for field in local_required:
            if field not in t:
                report.err(package_id, 'trajectories.jsonl', line_no,
                           f"trajectory missing required field '{field}'")
        if 'trigger' not in t and 'triggers' not in t:
            report.err(package_id, 'trajectories.jsonl', line_no,
                       "trajectory missing both 'trigger' and 'triggers' (need one)")
        tid = t.get('id', '')
        err = validate_id_namespace(tid, package_id, 'tr_')
        if err:
            report.err(package_id, 'trajectories.jsonl', line_no, err)

        # Path must reference real clusters
        for ck in t.get('path', []):
            if ck not in cluster_ids:
                report.err(package_id, 'trajectories.jsonl', line_no,
                           f"path references cluster '{ck}' that is not in this package")

        # Trigger cues — accept either shape
        trig = t.get('trigger', t.get('triggers', {}))
        if not isinstance(trig, dict):
            report.err(package_id, 'trajectories.jsonl', line_no,
                       "trigger/triggers must be an object")
        else:
            has_any = (trig.get('cues') or trig.get('query_phrases') or
                       trig.get('query_patterns') or trig.get('input_types'))
            if not has_any:
                report.warn(package_id, 'trajectories.jsonl', line_no,
                            "trajectory has no trigger cues/phrases/patterns; will not match any query")

        # Constraints referenced must exist
        for cn in t.get('constraints', []):
            if cn not in constraint_ids:
                report.err(package_id, 'trajectories.jsonl', line_no,
                           f"constraint '{cn}' referenced but not defined in this package")

        # branch_of references must be valid
        bof = t.get('branch_of')
        if bof is not None:
            if not isinstance(bof, dict):
                report.err(package_id, 'trajectories.jsonl', line_no,
                           "branch_of must be null or an object")
            else:
                if 'parent' not in bof or 'junction_cluster' not in bof:
                    report.err(package_id, 'trajectories.jsonl', line_no,
                               "branch_of must contain parent and junction_cluster")
                jc = bof.get('junction_cluster', '')
                if jc and jc not in cluster_ids:
                    report.err(package_id, 'trajectories.jsonl', line_no,
                               f"branch_of.junction_cluster '{jc}' is not in this package")

        trajectories[tid] = t

    return trajectories


def validate_transitions(pkg_dir: Path, package_id: str, cluster_ids: Set[str],
                          report: ValidationReport) -> None:
    tpath = pkg_dir / 'transitions.jsonl'
    if not tpath.exists():
        return  # transitions are optional in some packages
    try:
        items = load_jsonl_with_lines(tpath)
    except ValueError as e:
        report.err(package_id, 'transitions.jsonl', None, str(e))
        return

    seen = set()
    for line_no, t in items:
        for field in TRANSITION_REQUIRED:
            if field not in t:
                report.err(package_id, 'transitions.jsonl', line_no,
                           f"transition missing required field '{field}'")
        tid = t.get('id', '')
        if tid in seen:
            report.err(package_id, 'transitions.jsonl', line_no,
                       f"duplicate transition id '{tid}'")
        seen.add(tid)
        for end in ('from', 'to'):
            v = t.get(end, '')
            if v and v not in cluster_ids:
                report.err(package_id, 'transitions.jsonl', line_no,
                           f"transition {end}='{v}' is not a cluster in this package")


def validate_relations(pkg_dir: Path, package_id: str, all_package_ids: Set[str],
                        cluster_ids: Set[str], report: ValidationReport) -> None:
    rpath = pkg_dir / 'relations.jsonl'
    if not rpath.exists():
        return
    try:
        items = load_jsonl_with_lines(rpath)
    except ValueError as e:
        report.err(package_id, 'relations.jsonl', None, str(e))
        return

    for line_no, r in items:
        for field in RELATION_REQUIRED:
            if field not in r:
                report.err(package_id, 'relations.jsonl', line_no,
                           f"relation missing required field '{field}'")
        rt = r.get('type', '')
        if rt and rt not in VALID_RELATION_TYPES:
            report.warn(package_id, 'relations.jsonl', line_no,
                        f"unknown relation type '{rt}'")

        # Source must be in this package or be the package itself
        src = r.get('source', '')
        if src and src != package_id and ':' in src:
            src_pkg = src.split(':')[0]
            if src_pkg != package_id:
                report.err(package_id, 'relations.jsonl', line_no,
                           f"relation source '{src}' is not in this package")

        # Target may be another package, "user", "all_packages", or "all_empirical_packages"
        tgt = r.get('target', '')
        special_targets = {'user', 'all_packages', 'all_empirical_packages'}
        if tgt and tgt not in special_targets and tgt not in all_package_ids:
            if ':' in tgt:
                tgt_pkg = tgt.split(':')[0]
                if tgt_pkg not in all_package_ids:
                    report.err(package_id, 'relations.jsonl', line_no,
                               f"relation target '{tgt}' references unknown package '{tgt_pkg}'")
            else:
                report.warn(package_id, 'relations.jsonl', line_no,
                            f"relation target '{tgt}' is not a known package id")


def validate_tests(pkg_dir: Path, package_id: str, cluster_ids: Set[str],
                    constraint_ids: Set[str], trajectory_ids: Set[str],
                    report: ValidationReport) -> None:
    tpath = pkg_dir / 'tests.jsonl'
    if not tpath.exists():
        return
    try:
        items = load_jsonl_with_lines(tpath)
    except ValueError as e:
        report.err(package_id, 'tests.jsonl', None, str(e))
        return

    for line_no, t in items:
        for field in TEST_REQUIRED:
            if field not in t:
                report.err(package_id, 'tests.jsonl', line_no,
                           f"test missing required field '{field}'")

        for ck in t.get('expected_activated_clusters', []):
            if ck not in cluster_ids:
                report.err(package_id, 'tests.jsonl', line_no,
                           f"expected_activated_clusters references unknown cluster '{ck}'")
        for cn in t.get('expected_constraints_triggered', []):
            if cn not in constraint_ids:
                report.err(package_id, 'tests.jsonl', line_no,
                           f"expected_constraints_triggered references unknown constraint '{cn}'")
        et = t.get('expected_trajectory')
        if et and et not in trajectory_ids:
            report.err(package_id, 'tests.jsonl', line_no,
                       f"expected_trajectory '{et}' is not a trajectory in this package")


def validate_combined(pkg_dir: Path, package_id: str, expected_counts: Dict[str, int],
                       report: ValidationReport) -> None:
    """Verify package.combined.json is consistent with the JSONL files."""
    cpath = pkg_dir / 'package.combined.json'
    if not cpath.exists():
        report.err(package_id, 'package.combined.json', None, "file does not exist")
        return
    try:
        c = json.loads(cpath.read_text())
    except json.JSONDecodeError as e:
        report.err(package_id, 'package.combined.json', f'line {e.lineno}',
                   f"JSON parse error: {e.msg}")
        return

    for kind, count in expected_counts.items():
        actual = len(c.get(kind, []))
        if actual != count:
            report.err(package_id, 'package.combined.json', kind,
                       f"combined has {actual} {kind} but JSONL has {count}")


def validate_index(pkg_dir: Path, package_id: str, report: ValidationReport) -> None:
    """Verify index.json has the expected shape."""
    ipath = pkg_dir / 'index.json'
    if not ipath.exists():
        report.err(package_id, 'index.json', None, "file does not exist")
        return
    try:
        idx = json.loads(ipath.read_text())
    except json.JSONDecodeError as e:
        report.err(package_id, 'index.json', f'line {e.lineno}',
                   f"JSON parse error: {e.msg}")
        return
    for required in ('cue_index', 'cluster_summary'):
        if required not in idx:
            report.err(package_id, 'index.json', required, "field missing")


def validate_validation_report(pkg_dir: Path, package_id: str,
                                actual_counts: Dict[str, int],
                                report: ValidationReport) -> None:
    """Verify validation_report.json claimed counts match actual JSONL line counts.

    The report file is informational and is regenerated by package builds, but if
    its claimed counts diverge from what's actually in the JSONL files, the
    package's manifest is lying about its own contents. Catch that drift here.
    """
    vpath = pkg_dir / 'validation_report.json'
    if not vpath.exists():
        # Not all packages ship a validation_report.json; absence is not an error.
        return
    try:
        vr = json.loads(vpath.read_text())
    except json.JSONDecodeError as e:
        report.err(package_id, 'validation_report.json', f'line {e.lineno}',
                   f"JSON parse error: {e.msg}")
        return

    claimed = vr.get('counts', {})
    if not isinstance(claimed, dict):
        # Some validation_reports might not have a counts block. That's fine; nothing to check.
        return

    # Map of report-key → actual-count-key. Only check keys the report mentions.
    KEY_MAP = {
        'units': 'units',
        'clusters': 'clusters',
        'constraints': 'constraints',
        'trajectories': 'trajectories',
        'transitions': 'transitions',
        'relations': 'relations',
        'tests': 'tests',
    }
    for report_key, actual_key in KEY_MAP.items():
        if report_key not in claimed:
            continue
        claim = claimed[report_key]
        actual = actual_counts.get(actual_key, 0)
        if claim != actual:
            report.err(
                package_id, 'validation_report.json', report_key,
                f"validation_report.json claims {report_key}={claim} but "
                f"{actual_key}.jsonl has {actual} lines (count drift)"
            )


def validate_package(bundle_root: Path, package_id: str, all_package_ids: Set[str],
                      report: ValidationReport) -> None:
    pkg_dir = bundle_root / package_id
    if not pkg_dir.is_dir():
        report.err(package_id, '/', None, f"directory does not exist")
        return

    manifest = validate_manifest(pkg_dir, package_id, report)
    if not manifest:
        return  # bail; no manifest, nothing to cross-check

    units = validate_units(pkg_dir, package_id, report)
    clusters = validate_clusters(pkg_dir, package_id, set(units.keys()), report)
    constraints = validate_constraints(pkg_dir, package_id, set(clusters.keys()), report)
    trajectories = validate_trajectories(pkg_dir, package_id, set(clusters.keys()),
                                          set(constraints.keys()), report)
    validate_transitions(pkg_dir, package_id, set(clusters.keys()), report)
    validate_relations(pkg_dir, package_id, all_package_ids, set(clusters.keys()), report)
    validate_tests(pkg_dir, package_id, set(clusters.keys()), set(constraints.keys()),
                   set(trajectories.keys()), report)

    # Count actual JSONL lines for files not loaded above (transitions, relations, tests)
    def jsonl_lines(name: str) -> int:
        p = pkg_dir / name
        if not p.exists():
            return 0
        return sum(1 for ln in p.read_text().splitlines() if ln.strip())

    expected_counts = {
        'units': len(units),
        'clusters': len(clusters),
        'constraints': len(constraints),
        'trajectories': len(trajectories),
    }
    actual_counts_for_report = dict(expected_counts)
    actual_counts_for_report['transitions'] = jsonl_lines('transitions.jsonl')
    actual_counts_for_report['relations'] = jsonl_lines('relations.jsonl')
    actual_counts_for_report['tests'] = jsonl_lines('tests.jsonl')

    validate_combined(pkg_dir, package_id, expected_counts, report)
    validate_index(pkg_dir, package_id, report)
    validate_validation_report(pkg_dir, package_id, actual_counts_for_report, report)



def validate_bundle_manifest(bundle_root: Path, report: ValidationReport) -> List[str]:
    """Validate bundle_manifest.json. Returns list of package_ids in declaration order."""
    bmpath = bundle_root / 'bundle_manifest.json'
    if not bmpath.exists():
        report.bundle_err("bundle_manifest.json does not exist")
        return []
    try:
        bm = json.loads(bmpath.read_text())
    except json.JSONDecodeError as e:
        report.bundle_err(f"bundle_manifest.json JSON parse error at line {e.lineno}: {e.msg}")
        return []

    pkg_count = bm.get('package_count')
    pkgs = bm.get('packages', [])
    if pkg_count != len(pkgs):
        report.bundle_err(
            f"package_count is {pkg_count} but packages list has {len(pkgs)} entries")

    package_ids = []
    for i, p in enumerate(pkgs):
        if 'package_id' not in p:
            report.bundle_err(f"bundle_manifest.json packages[{i}] missing package_id")
            continue
        if 'path' not in p:
            report.bundle_err(f"bundle_manifest.json packages[{i}] ({p['package_id']}) missing 'path' field")
            continue
        pkg_dir = bundle_root / p['path']
        if not pkg_dir.is_dir():
            report.bundle_err(
                f"bundle_manifest.json packages[{i}] ({p['package_id']}) "
                f"references path '{p['path']}' that does not exist")
            continue
        package_ids.append(p['package_id'])

    # Check that every directory is in the manifest
    actual_dirs = {p.name for p in bundle_root.iterdir()
                   if p.is_dir() and (p / 'manifest.json').exists()}
    declared = set(package_ids)
    missing_in_manifest = actual_dirs - declared
    for pid in sorted(missing_in_manifest):
        report.bundle_err(f"package directory '{pid}' exists but is not in bundle_manifest.json")

    return package_ids


def main():
    parser = argparse.ArgumentParser(description="Validate TCog v0.3 bundle.")
    parser.add_argument('--strict', action='store_true',
                         help="treat warnings as errors")
    parser.add_argument('--package', default=None,
                         help="validate only this package (and bundle manifest)")
    parser.add_argument('--quiet', action='store_true',
                         help="suppress warnings in output")
    parser.add_argument('--root', default='.',
                         help="bundle root directory (default: current directory)")
    parser.add_argument('--json', action='store_true',
                         help="emit JSON report instead of text")
    args = parser.parse_args()

    bundle_root = Path(args.root).resolve()
    if not (bundle_root / 'bundle_manifest.json').exists():
        print(f"ERROR: {bundle_root}/bundle_manifest.json not found", file=sys.stderr)
        print("Run from the bundle root directory or pass --root.", file=sys.stderr)
        sys.exit(2)

    report = ValidationReport()
    package_ids = validate_bundle_manifest(bundle_root, report)

    if args.package:
        if args.package not in package_ids:
            print(f"ERROR: package '{args.package}' not in bundle", file=sys.stderr)
            sys.exit(2)
        targets = [args.package]
    else:
        targets = package_ids

    all_pids = set(package_ids)
    for pid in targets:
        validate_package(bundle_root, pid, all_pids, report)

    if args.json:
        out = {
            'bundle_errors': report.bundle_errors,
            'bundle_warnings': report.bundle_warnings,
            'errors': {pkg: {f: [{'where': w, 'message': m} for w, m in errs]
                              for f, errs in files.items()}
                        for pkg, files in report.errors.items()},
            'warnings': {pkg: {f: [{'where': w, 'message': m} for w, m in warns]
                                for f, warns in files.items()}
                          for pkg, files in report.warnings.items()},
            'total_errors': report.total_errors(),
            'total_warnings': report.total_warnings(),
            'pass': report.total_errors() == 0,
        }
        print(json.dumps(out, indent=2))
    else:
        text = report.render(quiet=args.quiet)
        if text:
            print(text)
        n_pkgs = len(targets)
        n_passed = sum(1 for p in targets if report.package_passed(p)) if not report.bundle_errors else 0
        print(f"=== SUMMARY ===")
        print(f"  Packages validated: {n_pkgs}")
        print(f"  Passed: {n_passed}")
        print(f"  Failed: {n_pkgs - n_passed}")
        print(f"  Bundle errors: {len(report.bundle_errors)}")
        print(f"  Total errors: {report.total_errors()}")
        print(f"  Total warnings: {report.total_warnings()}")

    if report.total_errors() > 0:
        sys.exit(1)
    if args.strict and report.total_warnings() > 0:
        sys.exit(1)
    sys.exit(0)


if __name__ == '__main__':
    main()
