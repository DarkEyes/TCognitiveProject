#!/usr/bin/env python3
"""
Regenerate bundle-level metadata from ground truth in package directories.

Updates:
  - bundle_manifest.json   (version, package list, change_log entries 0.3.15-19)
  - bundle_validation_report.json (totals + per-package summary, all from JSONL)
  - PROVENANCE.json        (tier classification from actual structural features)
  - README.md              (version, totals, package counts)
  - RELEASE_NOTES.md       (append v0.3.15-19 entries)

Inputs:
  Each package dir's manifest.json + JSONL files + validation_report.json.

Source of truth:
  Actual file contents. Reported counts from any cached manifest or earlier
  validation_report are ignored.
"""
import json
import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

BUNDLE = Path("/home/claude/tcog_work")
NEW_VERSION = "0.3.26"
TODAY = "2026-05-01"


def count_jsonl(p: Path) -> int:
    if not p.exists():
        return 0
    return sum(1 for ln in p.read_text().splitlines() if ln.strip())


def load_jsonl(p: Path) -> List[Dict[str, Any]]:
    if not p.exists():
        return []
    out = []
    for ln in p.read_text().splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except Exception:
            pass
    return out


def package_features(pkg_dir: Path, package_id: str) -> Dict[str, Any]:
    """Extract structural features for tier classification + reporting."""
    manifest = json.loads((pkg_dir / "manifest.json").read_text())
    units = load_jsonl(pkg_dir / "units.jsonl")
    clusters = load_jsonl(pkg_dir / "clusters.jsonl")
    constraints = load_jsonl(pkg_dir / "constraints.jsonl")
    trajectories = load_jsonl(pkg_dir / "trajectories.jsonl")
    transitions = load_jsonl(pkg_dir / "transitions.jsonl")
    relations = load_jsonl(pkg_dir / "relations.jsonl")
    tests = load_jsonl(pkg_dir / "tests.jsonl")

    # Anchored units: have at least one anchor whose source_id != package_id
    anchored = 0
    for u in units:
        for a in u.get("anchors", []):
            sid = a.get("source_id", "")
            if sid and not sid.startswith(package_id) and sid != package_id:
                anchored += 1
                break

    # Anchor sources cited (deduped)
    anchor_sources = set()
    for u in units:
        for a in u.get("anchors", []):
            sid = a.get("source_id", "")
            stitle = a.get("source_title", "")
            if sid and not sid.startswith(package_id):
                if stitle:
                    # Take just the first sentence-ish for brevity
                    anchor_sources.add(stitle.split(".")[0][:120])
                else:
                    anchor_sources.add(sid)

    # Blocking constraints
    blocking = []
    for c in constraints:
        if c.get("blocks_answer") is True or c.get("severity") == "critical":
            blocking.append(f"{c['id']} (severity: {c.get('severity', '?')})")

    # Branching trajectories
    branching = [t["id"] for t in trajectories if t.get("branch_of")]

    # Cross-package relations: source or target outside this package's namespace
    cross_pkg_rel = 0
    for r in relations:
        src = r.get("source", "")
        tgt = r.get("target", "")
        for ref in (src, tgt):
            if ref and not ref.startswith(package_id) and ref != package_id and ref != "all_packages":
                cross_pkg_rel += 1
                break

    # Distinct trajectory triggers (for "≥3 trajectories with distinct triggers")
    distinct_trigger_count = 0
    seen_first_phrase = set()
    for t in trajectories:
        trig = t.get("trigger") or t.get("triggers") or {}
        phrases = trig.get("query_phrases") or []
        patterns = trig.get("query_patterns") or []
        first = (phrases + patterns)[:1]
        if first:
            seen_first_phrase.add(first[0])
        else:
            seen_first_phrase.add(t["id"])  # treat as distinct
    distinct_trigger_count = len(seen_first_phrase)

    return {
        "package_id": package_id,
        "name": manifest.get("name", package_id),
        "domain": manifest.get("domain", "?"),
        "version": manifest.get("version", "?"),
        "authoring_status": manifest.get("authoring_status", manifest.get("authoring_level", "?")),
        "quality_level": manifest.get("quality_level", "?"),
        "lifecycle_status": manifest.get("lifecycle_status", manifest.get("status", "draft")),
        "counts": {
            "units": len(units),
            "clusters": len(clusters),
            "constraints": len(constraints),
            "trajectories": len(trajectories),
            "transitions": len(transitions),
            "relations": len(relations),
            "tests": len(tests),
        },
        "anchored_units": anchored,
        "anchor_sources_cited": sorted(list(anchor_sources))[:20],
        "blocking_constraints": blocking,
        "branching_trajectories": branching,
        "cross_package_relations_count": cross_pkg_rel,
        "trajectory_count": len(trajectories),
        "trajectory_ids": [t["id"] for t in trajectories],
        "distinct_trigger_count": distinct_trigger_count,
    }


def classify_tier(f: Dict[str, Any]) -> Tuple[str, str, str]:
    """Return (tier, substate, notes)."""
    auth = f["authoring_status"]
    qual = f["quality_level"]
    counts = f["counts"]
    units_n = counts["units"]
    blk = len(f["blocking_constraints"])
    tr = counts["trajectories"]
    xrel = f["cross_package_relations_count"]
    anch = f["anchored_units"]

    # Light scaffold detection
    if auth == "light" or qual == "axiom_bank_unvetted":
        return ("light", "scaffold",
                "Schema-valid scaffold. Anchors are self-referential; "
                "failure_modes and basis_role are label-derived rather than authored.")

    # Focused: must be declared focused_with_anchors AND have anchored content
    if auth == "focused_with_anchors":
        # fully_focused: blocking + ≥3 trajectories + ≥3 cross-pkg relations + ≥80% anchored
        is_fully_focused = (
            blk >= 1 and tr >= 3 and xrel >= 3 and
            (units_n == 0 or anch / units_n >= 0.8)
        )
        if is_fully_focused:
            return ("focused_with_anchors", "fully_focused",
                    "All structural guarantees met: blocking constraint(s), "
                    "≥3 trajectories with distinct triggers, ≥3 cross-package "
                    "relations, ≥80% units anchored to external sources.")
        # anchor_promoted: anchored but missing one or more guarantees
        gaps = []
        if blk == 0:
            gaps.append("no blocking constraint")
        if tr < 3:
            gaps.append(f"only {tr} trajector{'y' if tr == 1 else 'ies'}")
        if xrel < 3:
            gaps.append(f"only {xrel} cross-package relation{'s' if xrel != 1 else ''}")
        if units_n > 0 and anch / units_n < 0.8:
            gaps.append(f"only {anch}/{units_n} units anchored to external sources")
        gaps_str = "; ".join(gaps) if gaps else "edge of full focused criteria"
        return ("focused_with_anchors", "anchor_promoted",
                f"Anchored to canonical works ({anch}/{units_n} units have non-self-referential "
                f"anchors). Honestly intermediate: {gaps_str}.")

    # Fallback
    return ("unclassified", "unknown",
            f"authoring_status={auth!r} quality_level={qual!r} — declare explicitly")


def domain_for(pkg: str) -> str:
    """Stable domain string per package_id."""
    map_ = {
        "art_form_affect_core": "art / aesthetics",
        "biology_adaptation_core": "biology",
        "chemistry_interactions_core": "chemistry",
        "cognitive_science_core": "cognitive science",
        "communication_rhetoric_core": "communication / rhetoric",
        "computer_science_systems_core": "computer science",
        "counselling_practice_core": "counselling",
        "design_hci_core": "design / human-computer interaction",
        "economics_core": "economics",
        "education_pedagogy_core": "education",
        "history_path_dependence_core": "history",
        "information_science_retrieval_core": "information science",
        "law_practice_core": "law",
        "management_execution_core": "management",
        "math_proof_core": "mathematics",
        "medicine_diagnostic_safety_core": "medicine",
        "operations_research_decision_core": "operations research / decision theory",
        "philosophy_ethics_core": "philosophy / ethics",
        "physics_dynamical_constraints_core": "physics",
        "political_science_governance_core": "political science",
        "psychology_core": "psychology",
        "sociology_institutions_core": "sociology",
        "statistics_core": "statistics",
        "systems_control_core": "systems engineering / control theory",
    }
    return map_.get(pkg, "?")


def main():
    pkg_dirs = sorted([p for p in BUNDLE.iterdir()
                       if p.is_dir() and (p / "manifest.json").exists()])
    pkgs = [p.name for p in pkg_dirs]
    features_list = []
    for pdir in pkg_dirs:
        f = package_features(pdir, pdir.name)
        f["tier"], f["tier_substate"], f["tier_notes"] = classify_tier(f)
        features_list.append(f)

    # ---- Bundle totals ----
    totals = {k: 0 for k in ["units", "clusters", "constraints", "trajectories",
                              "transitions", "relations", "tests"]}
    for f in features_list:
        for k, v in f["counts"].items():
            totals[k] += v
    blocking_total = sum(len(f["blocking_constraints"]) for f in features_list)
    branching_total = sum(len(f["branching_trajectories"]) for f in features_list)
    anchored_units_total = sum(f["anchored_units"] for f in features_list)

    print(f"Totals: {totals}")
    print(f"Blocking constraints across bundle: {blocking_total}")
    print(f"Branching trajectories across bundle: {branching_total}")
    print(f"Anchored units across bundle: {anchored_units_total}/{totals['units']}")

    # Test count totals: single-package from per-package tests.jsonl, cross-package
    # from bundle root cross_package_tests.jsonl.
    single_pkg_test_total = totals["tests"]
    cross_pkg_test_total = len(load_jsonl(BUNDLE / "cross_package_tests.jsonl"))
    print(f"Test counts: single-package {single_pkg_test_total}, cross-package {cross_pkg_test_total}, "
          f"total {single_pkg_test_total + cross_pkg_test_total}")

    # Tier rollup
    tier_counts = {}
    for f in features_list:
        key = (f["tier"], f["tier_substate"])
        tier_counts.setdefault(key, []).append(f["package_id"])
    print("Tier rollup:")
    for (t, s), names in sorted(tier_counts.items()):
        print(f"  {t}/{s}: {len(names)} packages")
        for n in names:
            print(f"    - {n}")

    # ============================================================
    # bundle_manifest.json
    # ============================================================
    print("\n=== Regenerating bundle_manifest.json ===")
    old_manifest = json.loads((BUNDLE / "bundle_manifest.json").read_text())
    new_manifest = {
        "bundle_id": "tcog_field_basis_packages_v0_3",
        "name": "TCog Field Basis Packages v0.3",
        "version": NEW_VERSION,
        "protocol_version": "0.3",
        "created": old_manifest.get("created", "2026-04-29"),
        "updated": TODAY,
        "description": ("A bundle of TCog v0.3-compatible field-level basis packages for query "
                        "routing, constraint checks, and trajectory activation."),
        "package_count": len(features_list),
        "totals": totals,
        "packages": [],
        "notes": (
            f"v{NEW_VERSION} (metadata-resync release): No new package or "
            f"runtime content. ChatGPT's audit of v0.3.25 claimed run_tests.py "
            f"needed strict_domain_tokens parity work, that the schema "
            f"addendum was missing, and that several packages had only 1-4 "
            f"tests. Verification showed the audit was largely stale: "
            f"run_tests.py already had the strict_domain_tokens gate, "
            f"single-token cue protection, suppressed_packages tracking, and "
            f"should_not_activate_packages/should_not_activate_clusters "
            f"assertions; SCHEMA_ADDENDUM_v0_3_25.md already existed and "
            f"covered all 10 v0.3.25 fields; per-package test minimums had "
            f"been raised to 5 tests; and 5 strict-domain suppression "
            f"integration tests already existed. The actual residue was "
            f"three stale text strings (bundle_validation_report.json said "
            f"'126/126', README.md said '153/153 tests', Makefile said '27 "
            f"cross-package tests') plus downstream metadata that hadn't "
            f"caught up with content additions made between v0.3.25's first "
            f"cut and now. v0.3.26 resyncs all metadata to current totals: "
            f"173 single-package + 45 cross-package = 218 tests, all "
            f"passing. test_type distribution: 96 activation_test + 80 "
            f"constraint_test + 42 frame_conflict_test. Bundle passes strict "
            f"validation with zero warnings. The bundle/runtime parity "
            f"problem ChatGPT was concerned about is resolved — the browser "
            f"demo (`tcog_demo.html`) and run_tests.py implement identical "
            f"retrieval logic including strict_domain_tokens enforcement; "
            f"both can run the same test corpus and produce identical pass/"
            f"fail decisions on every test."
        ),
        "change_log": old_manifest.get("change_log", []),
    }

    # Add per-package entries
    for f in features_list:
        new_manifest["packages"].append({
            "package_id": f["package_id"],
            "path": f["package_id"],
            "name": f["name"],
            "domain": domain_for(f["package_id"]),
            "version": f["version"],
            "status": f["lifecycle_status"],
            "authoring_status": f["authoring_status"],
            "quality_level": f["quality_level"],
            "counts": f["counts"],
            "tier": f["tier"],
            "tier_substate": f["tier_substate"],
        })

    # Append v0.3.15 - v0.3.19 change_log entries (idempotent: only add if version not present)
    seen_versions = {entry.get("version") for entry in new_manifest["change_log"]}

    new_entries = [
        {
            "version": "0.3.15",
            "date": "2026-05-01",
            "changes": [
                "Promoted management_execution_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters; 6 admissibility constraints; 4 trajectories incl. 1 branching (tr_design_a_metric off tr_evaluate_strategy_claim at k_metrics_and_control); 8 cross-package relations.",
                "Anchors: Drucker, Freeman, Jensen-Meckling, Porter, Barney, Chandler, Mintzberg, Lawrence-Lorsch, Galbraith, Schein, Barnard, Edmondson, Anthony, Goodhart/Strathern, Kerr, Bossidy-Charan, Nelson-Winter, Argyris-Schön, March-Simon/Cyert-March, Kahneman.",
            ],
        },
        {
            "version": "0.3.16",
            "date": "2026-05-01",
            "changes": [
                "Promoted physics_dynamical_constraints_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters (symmetry-and-conservation, state-space-and-dynamics, equilibrium-and-stability, bifurcation-and-chaos, scale-and-separation, noise-and-stochastic-dynamics, models-and-idealization); 6 constraints; 4 trajectories incl. 1 branching; 8 cross-package relations.",
                "Anchors: Noether 1918, Arnold, Goldstein, Lanczos, Strogatz, Hirsch-Smale-Devaney, Lyapunov 1892, Khalil, Milnor, Guckenheimer-Holmes, Lorenz 1963, Poincaré, Feigenbaum 1978, May 1976, Buckingham 1914, Barenblatt, Wilson 1971, Anderson 1972, Norton 2012, Batterman 2002, Einstein 1905, Kubo 1966, Callen-Welton 1951, Van Kampen, Gardiner, Cartwright 1983, McMullin 1985, Wigner 1960, Earman 1989.",
            ],
        },
        {
            "version": "0.3.17",
            "date": "2026-05-01",
            "changes": [
                "Promoted operations_research_decision_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters (objectives-and-preferences, constraints-and-feasibility, bottlenecks-and-throughput, optimization-landscape, decision-under-uncertainty, robustness-and-regret, queues-and-congestion); 6 constraints; 4 trajectories incl. 1 branching (tr_robust_decision_under_ambiguity off tr_decide_under_uncertainty); 9 relations including 1 internal complements with surface_both_frames between u_expected_utility_axioms and u_prospect_theory_violations.",
                "Anchors: vNM 1944, Savage 1954, Wald 1950, Kuhn-Tucker 1951, Dantzig 1963, Ford-Fulkerson 1956, Kelley-Walker 1959, Smith 1956, Little 1961, Kingman 1961, Kelly 1956, Tversky-Kahneman 1979+1992, Ellsberg 1961, Allais 1953, Bertsimas-Sim 2004, Ben-Tal-Nemirovski 2002, Wolpert-Macready 1997, Kirkpatrick 1983, Manheim-Garrabrant 2018, Boyd-Vandenberghe 2004, Bertsimas-Tsitsiklis 1997, Keeney-Raiffa 1976, Steuer 1986, Goldratt 1984, Pinedo 2016, Garey-Johnson 1979.",
            ],
        },
        {
            "version": "0.3.18",
            "date": "2026-05-01",
            "changes": [
                "Promoted systems_control_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters (system-boundary-and-state, observability-and-estimation, feedback-changes-dynamics, intervention-under-feedback, stability-and-margins, system-dynamics-archetypes, failure-modes-and-safety); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_safety_failure off tr_diagnose_intervention_failure at k_intervention_under_feedback); 9 relations including 1 internal complements with surface_both_frames between Reason's Swiss-cheese and Leveson's STAMP framings of safety.",
                "Anchors: Lyapunov 1892, Black 1934, Nyquist 1932, Wiener 1948, Ashby 1956, Kalman 1960 (filter + general theory), Luenberger 1964, Conant-Ashby 1970, Forrester 1961, Perrow 1984, Senge 1990, Reason 1990, Meadows 1999, Sterman 2000, Leveson 2011, plus Astrom-Murray 2008, Khalil 2002, Skogestad-Postlethwaite 2005.",
            ],
        },
        {
            "version": "0.3.19",
            "date": "2026-05-01",
            "changes": [
                "Promoted art_form_affect_core from light scaffold to focused_with_anchors.",
                "18 anchored units across 6 deep clusters (form-carries-meaning, style-is-constraint, aesthetic-coherence-differs-from-logic, genre-frames-interpretation, affect-is-structured, ambiguity-can-be-functional); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_aesthetic_failure off tr_interpret_a_work at k_aesthetic_coherence_differs_from_logic); 8 relations including 1 internal complements with surface_both_frames between Wimsatt-Beardsley's text-centered formalism and Iser's reader-centered indeterminacy.",
                "Anchors: Aristotle Poetics, Wimsatt-Beardsley 1946+1949, Beardsley 1958, Brooks 1947, Goodman 1968, Shklovsky 1917, Jakobson 1960, Auerbach 1946, Iser 1978, Jauss 1982, Eco 1962+1979, Bakhtin 1986, Frye 1957, Todorov 1973, Empson 1930, Tsur 1992, Stockwell 2002, Damasio 1994, Leder et al. 2004, Ngai 2012.",
                "Bundle housekeeping pass: regenerated bundle_manifest.json, bundle_validation_report.json, PROVENANCE.json, README.md, RELEASE_NOTES.md from ground truth in package files. Filled in authoring_status for 7 previously-unmarked focused packages. Added validation_report.json count-mismatch check to validate_bundle.py. Restored validate_bundle.py and run_tests.py to the distribution. Added docs/index.html as browser entry point. Strict tier criteria applied: 5 fully_focused (counselling, economics, medicine, philosophy, psychology), 14 anchor_promoted, 5 light scaffolds.",
            ],
        },
        {
            "version": "0.3.20",
            "date": "2026-05-01",
            "changes": [
                "Promoted education_pedagogy_core from light scaffold to focused_with_anchors.",
                "18 anchored units across 6 deep clusters (knowing-differs-from-using, learning-requires-scaffolding, misunderstanding-may-signal-missing-prerequisites, practice-compiles-trajectories, transfer-requires-structural-recognition, feedback-guides-improvement); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_learning_struggle off tr_design_instruction at k_learning_requires_scaffolding); 9 relations including 1 internal complements with surface_both_frames between Sweller cognitive-load direct-instruction evidence and Schwartz-Bransford preparation-for-future-learning evidence (Kirschner-Sweller-Clark 2006 vs Hmelo-Silver-Duncan-Chinn 2007).",
                "Anchors: Anderson 1983 (ACT-R), Whitehead 1929, Bjork-Bjork 1992 + Bjork 1994 (desirable difficulties), Vygotsky 1978, Wood-Bruner-Ross 1976, Pearson-Gallagher 1983, Driver-Easley 1978, diSessa 1988 (knowledge in pieces), Vosniadou-Brewer 1992, Chi 2008, Ericsson-Krampe-Tesch-Romer 1993 (deliberate practice), Sweller 1988 + Sweller-van Merrienboer-Paas 1998 (cognitive load), Roediger-Karpicke 2006 (testing effect), Detterman 1993 (transfer pessimism), Gick-Holyoak 1983, Schwartz-Bransford 1998 (PFL), Bransford et al. 2000 (How People Learn), Black-Wiliam 1998, Hattie-Timperley 2007, Sadler 1989, Hmelo-Silver-Duncan-Chinn 2007.",
                "AI-bridge anchors explicitly identified: Bjork performance-vs-learning <-> ML overfitting; Detterman transfer pessimism <-> OOD generalization; Schwartz-Bransford PFL <-> curriculum learning. Bridge supports cross-references without collapsing human-learning and ML-training domains.",
            ],
        },
        {
            "version": "0.3.21",
            "date": "2026-05-01",
            "changes": [
                "Promoted chemistry_interactions_core from light scaffold to focused_with_anchors.",
                "18 anchored units across 6 deep clusters (structure-determines-interaction, conditions-matter, equilibrium-is-dynamic, catalysts-change-pathways, small-structural-changes-matter, stoichiometry-constrains-transformation); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_unexpected_product off tr_predict_reaction_outcome at k_conditions_matter); 9 relations including 1 internal complements with surface_both_frames between u_gibbs_free_energy_governs_spontaneity (thermodynamic-control) and u_kinetic_vs_thermodynamic_control (kinetic-control) capturing the canonical chemistry-frame disagreement.",
                "Anchors: Lavoisier 1789, Le Chatelier 1884, van't Hoff 1884, Arrhenius 1889, Sabatier 1911, Michaelis-Menten 1913, Lewis 1916, Eyring 1935, Hammett 1937, Bell-Evans-Polanyi 1938, Pauling 1939+1948, Hammond 1955, Marcus 1956, Curtin-Hammett 1954, Pearson 1963 (HSAB), Gibbs 1876. Textbook anchors: Atkins-de Paula 2018, Eliel-Wilen 1994, Reichardt-Welton 2010, Carey-Sundberg 2007, March-Smith 2007.",
                "All 8 package tests passed on first attempt. Pattern: when cluster cues include both technical chemistry vocabulary AND naturalistic phrasings of underlying questions ('the major product', 'predict the reactivity', 'compute the yield', 'shifts the equilibrium'), constraints fire alongside cluster activation as designed without iteration cycle.",
            ],
        },
        {
            "version": "0.3.22",
            "date": "2026-05-01",
            "changes": [
                "Promoted design_hci_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters (users-act-through-affordances, visibility-shapes-action, cognitive-load-matters, errors-are-often-design-failures, feedback-guides-repair, trust-needs-inspectability, next-action-should-be-legible); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_user_struggle off tr_evaluate_a_design at k_visibility_shapes_action); 9 relations including 1 internal complements with surface_both_frames between u_shneiderman_direct_manipulation and u_maes_agents_delegation_paradigm capturing the canonical AI-interaction disagreement (Shneiderman-Maes 1997 IUI debate; Shneiderman 2022 Human-Centered AI). Directly relevant to LLM interface design.",
                "Anchors: Gibson 1979 (ecological affordances), Koffka 1935 (Gestalt synthesizing Wertheimer 1923), Miller 1956 + Cowan 2001 (working-memory limits), Hick 1952 + Hyman 1953 (choice reaction time), Fitts 1954 (information capacity of motor system), Bainbridge 1983 (ironies of automation), Shneiderman 1983 (direct manipulation), Tufte 1983 (visual display + data-ink ratio), Norman 1988 (Design of Everyday Things) + Norman 1999 (affordances/conventions retraction), Sweller 1988 (cognitive load), Reason 1990 (Human Error), Nielsen 1993 (Usability Engineering response times) + Nielsen 1994 (10 heuristics), Maes 1994 (agents that reduce work and information overload), Endsley 1995 (situation awareness), Parasuraman-Riley 1997 (use/misuse/disuse/abuse), Shneiderman-Maes 1997 (IUI debate), Lee-See 2004 (trust calibration), Shneiderman 2022 (Human-Centered AI).",
                "All 8 package tests passed on first attempt — second consecutive rebuild without iteration cycle (after v0.3.21 chemistry). Cluster cues included both technical HCI vocabulary AND naturalistic phrasings of underlying questions ('evaluate the design', 'review the interface', 'users keep making errors', 'users are confused', 'users don't trust the AI', 'agent vs direct manipulation', 'should we use an agent') so constraints fired alongside cluster activation.",
            ],
        },
        {
            "version": "0.3.23",
            "date": "2026-05-01",
            "changes": [
                "Promoted information_science_retrieval_core from light scaffold to focused_with_anchors.",
                "21 anchored units across 7 deep clusters (classification-shapes-retrieval, metadata-is-knowledge, controlled-vocabulary-reduces-ambiguity, ambiguity-requires-disambiguation, provenance-supports-trust, indexes-are-retrieval-infrastructure, preservation-needs-structure); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_retrieval_failure off tr_design_a_retrieval_system at k_indexes_are_retrieval_infrastructure) plus a fourth tr_design_a_rag_system; 9 relations including 1 internal complements with surface_both_frames between u_thesaurus_structure_BT_NT_RT (controlled-vocabulary frame) and u_dense_retrieval_and_late_interaction (learned-representation frame) capturing the canonical lexical-vs-neural retrieval disagreement directly relevant to RAG / LLM-application design.",
                "Anchors: Cutter 1876 (three objects of a catalog), Ranganathan 1931+1933 (Five Laws + PMEST faceted classification), Bowker-Star 1999 (Sorting Things Out — boundary infrastructure and residual categories), Weibel 1995 (Dublin Core + ISO 15836), IFLA 1998 (FRBR work/expression/manifestation/item), NISO 2017 (Understanding Metadata — descriptive/administrative/structural typology), ANSI/NISO Z39.19-2005 + Soergel 1985 (thesaurus structure BT/NT/RT), IFLA FRAD 2009 (authority data), MeSH/LCSH + Berman 1971 (vocabulary politics), Furnas-Landauer-Gomez-Dumais 1987 (vocabulary problem ~10-20% term agreement), Mihalcea-Csomai 2007 (Wikify) + Hoffart et al. 2011 (AIDA), Lesk 1986 + Yarowsky 1995 + Navigli 2009 (WSD), W3C PROV-O 2013 (Lebo-Sahoo-McGuinness), Jenkinson 1922 + Schellenberg 1956 (archival principle of provenance, respect des fonds), Merton 1973 + Garfield 1955 (citation as provenance), Sparck Jones 1972 (IDF) + Manning-Raghavan-Schütze 2008 (introduction to IR), Robertson-Walker 1994 (Okapi BM25) + Robertson-Spärck Jones 1976 (probabilistic retrieval), Mikolov 2013 (word2vec) + Karpukhin 2020 (DPR) + Khattab-Zaharia 2020 (ColBERT late interaction) + Lewis 2020 (RAG), CCSDS 2012 (OAIS / ISO 14721) + Lavoie 2014, Rothenberg 1995+1998 (format obsolescence), Heslop-Davis-Wilson 2002 (significant properties) + Duranti 2009 (InterPARES diplomatics).",
                "All 8 package tests passed on first attempt — third consecutive rebuild without iteration cycle (after v0.3.21 chemistry, v0.3.22 design_hci). Cluster cues included both technical IS/IR vocabulary AND naturalistic phrasings of underlying questions ('BM25 vs dense', 'should we use BM25', 'should we use dense retrieval', 'design a retrieval system', 'design a RAG system', 'build a search system', 'users can't find documents', 'search isn't returning', 'OAIS', 'SIP AIP DIP', 'long-term preservation') so constraints fired alongside cluster activation.",
                "Lexical-vs-neural retrieval disagreement methodologically live for TCog itself: mechanical-mode-first design is BM25-flavored (cue matching, exact-and-lemma); semantic-augmented mode is dense-flavored (semantic similarity over cluster descriptions). Internal complements relation between thesaurus structure and dense retrieval surfaces both frames as responses to Furnas's 1987 vocabulary problem; modern best-practice is hybrid (BM25 + dense + cross-encoder reranking).",
            ],
        },
        {
            "version": "0.3.24",
            "date": "2026-05-01",
            "changes": [
                "Promoted sociology_institutions_core from light scaffold to focused_with_anchors. With this rebuild, the bundle has zero light scaffolds remaining — all 24 packages are now in focused_with_anchors or fully_focused tier.",
                "21 anchored units across 7 deep clusters (behavior-is-socially-situated, norms-regulate-without-law, institutions-reproduce-patterns, meaning-is-shared-and-contested, status-shapes-voice, identity-shapes-admissibility, ritual-stabilizes-coherence); 6 constraints; 4 trajectories incl. 1 branching (tr_diagnose_inequality off tr_analyze_a_social_phenomenon at k_status_shapes_voice) plus tr_analyze_an_institution; 10 relations including 1 internal complements with surface_both_frames between u_coleman_micro_macro_methodological_individualism (Coleman 1990 Foundations of Social Theory — Coleman's Boat macro→micro→micro→macro, analytical sociology, rational-choice sociology, agent-based modeling) and u_bourdieu_habitus_practice (Bourdieu 1977 Outline + 1990 Logic of Practice — habitus as embodied internalized structure, methodological holism following Durkheim 1895) capturing the canonical contemporary methodological disagreement in sociology — analytical-sociology / rational-choice / ABM vs cultural sociology / field theory / methodological holism — directly relevant to AI-bridge questions about agent-based-simulation framings (LLM multi-agent systems) vs structural-critique framings (Crawford 2021, Benjamin 2019) of social phenomena.",
                "Anchors: Durkheim 1895 (Rules of Sociological Method — social facts sui generis) + 1912 (Elementary Forms of the Religious Life — collective effervescence), Weber 1922 (Economy and Society — class/status/party three dimensions of stratification), Goffman 1959 (Presentation of Self — dramaturgy, front/back stage, impression management) + Goffman 1955+1967 (face-work), Garfinkel 1967 (Studies in Ethnomethodology — indexicality, reflexivity, breaching experiments, documentary method), Bourdieu 1977 (Outline of a Theory of Practice) + 1984 (Distinction — cultural capital, taste-and-class) + 1990 (Logic of Practice), Berger-Luckmann 1966 (Social Construction of Reality — externalization-objectivation-internalization dialectic), Geertz 1973 (Interpretation of Cultures — thick description), Swidler 1986 ('Culture in Action' ASR — culture-as-toolkit, settled-vs-unsettled cultural periods), Meyer-Rowan 1977 ('Institutionalized Organizations' AJS — rationalized myth, decoupling), DiMaggio-Powell 1983 ('Iron Cage Revisited' ASR) + 1991 (New Institutionalism — coercive/mimetic/normative isomorphism), North 1990 (Institutions, Institutional Change and Economic Performance — institutions-as-rules, institutions vs organizations), Elster 1989 (Cement of Society) + 2007 (Explaining Social Behavior — emotional enforcement of norms), Bicchieri 2006 (Grammar of Society) + 2017 (Norms in the Wild — conditional preferences with empirical and normative expectations), Ostrom 1990 (Governing the Commons — eight design principles for common-pool resources), Coleman 1990 (Foundations of Social Theory — Coleman's Boat, methodological individualism, social capital), Ridgeway 2011 (Framed by Gender) + 2014 ('Why Status Matters for Inequality' ASR — status construction theory), Crenshaw 1989 ('Demarginalizing the Intersection') + 1991 ('Mapping the Margins' Stanford Law Review — intersectionality), Hill Collins 1990 (Black Feminist Thought — matrix of domination across structural/disciplinary/hegemonic/interpersonal domains), Tajfel-Turner 1979 ('Integrative Theory of Intergroup Conflict') + Tajfel 1971 (minimal-group paradigm), Collins 2004 (Interaction Ritual Chains — emotional energy as currency of microsociology), Douglas 1966 (Purity and Danger — dirt as matter out of place, symbolic-order maintenance).",
                "7/8 package tests passed first attempt; test_explain_institutional_isomorphism (query 'Why do organizations in the same field come to look so similar in form and structure?') required adding 8 naturalistic cues to k_institutions_reproduce_patterns ('organizations in the same field', 'organizations come to look alike', 'organizations look so similar', 'similar in form and structure', 'organizational form', 'why do organizations resemble', 'why do organizations look similar', 'organizational similarity') after which all 8 passed. Tighter cue-design lesson restated: cluster cues should include both technical disciplinary vocabulary AND naturalistic phrasings of the underlying question — sociology vocabulary in particular collides hard with everyday/technical usage (43 negative-cue terms covering vector/matrix norm, magnetic field, capital city/letter, OOP class, Slack/HTTP status, identity matrix/theft, morning ritual, data structure, advertising agency, the Matrix movie, embedded software, food preservation, drug habit, environmental pollution, theatrical performance, etc.) so naturalistic positive cues must compensate.",
                "Bundle composition complete: 5 fully_focused (counselling, economics, medicine, philosophy, psychology) + 19 anchor_promoted _core packages + 0 light scaffolds. Bundle housekeeping: regenerated all metadata from JSONL ground truth; verified validation_report counts match across all 24 packages.",
            ],
        },
        {
            "version": "0.3.25",
            "date": "2026-05-01",
            "changes": [
                "Metadata-discipline release. No new package content. Addresses 9 inconsistencies in the bundle's metadata layer flagged by ChatGPT's audit, plus the conceptual test_type field.",
                "Test count metadata normalized: bundle_validation_report.json (was 126/126), README.md (was 153/153), Makefile (was 48 tests) all aligned to 161 single-package + 40 cross-package = 201 tests.",
                "law_practice_core/validation_report.json regenerated: was the only stale 'initial validation report; will be overwritten' stub; now matches the v0.3 protocol_version structure with proper counts and zero errors/warnings.",
                "Added missing constraint.type to 17 constraints across 5 packages (counselling 4 → safety/normative; economics 3 → admissibility; medicine 4 → safety/admissibility; philosophy 3 → admissibility/normative; statistics 3 → admissibility/empirical). The schema requires constraint.type and these were silent gaps.",
                "Added provenance + cluster_memberships to all 10 counselling_practice_core units. Counselling was a strong showcase package missing standard unit fields; now consistent with all other packages.",
                "Added strict_domain_tokens to 6 overreach-prone packages: chemistry_interactions_core (35 tokens), physics_dynamical_constraints_core (25), systems_control_core (27), operations_research_decision_core (24), art_form_affect_core (36), sociology_institutions_core (38). Package-authored overreach prevention replacing JavaScript fallback patches in the runtime.",
                "Normalized relation types to the schema-blessed set: frame_limit → frame_limited_by (20 instances), potential_conflict → conflicts_with (4), refined_by → refines (3, with source/target swap to preserve direction). Added 'complements' and 'safety_boundary' to the v0.3 schema-blessed VALID_RELATION_TYPES set (in active use, semantically distinct from the inherited TCog Schema v0.3 §5.8 list).",
                "Cleaned up retrieval_behavior to a controlled vocabulary: surface_both_frames, prefer_source, prefer_target, require_user_choice, joint_consideration, suppress_if_avoid_when_matches. 28 free-form values normalized; 27 long descriptive strings preserved in new runtime_note field for traceability. The mechanical retrieval runner can now dispatch on retrieval_behavior without parsing arbitrary text.",
                "Added source_type and target_type fields to all 144 relations: 131 package-level (where source/target are package IDs without colons) and 13 object-level (where source/target are namespaced object IDs). Disambiguates relation scope so a strict validator no longer treats package IDs as unresolved object IDs.",
                "Regenerated all 24 validation_report.json files with derived cue_terms, negative_cue_terms, constraint_trigger_terms, and trajectory_trigger_terms counts. 11 packages had stale derived counts (e.g. cognitive_science showed 0 cue_terms but actually had 110; psychology showed 0 negative_cue_terms but had 20). The validation report generator now updates derived counts alongside core counts.",
                "Added 13 cross-package tests covering previously-uncovered packages: art↔counselling (grief poem), biology↔medicine (antibiotic resistance evolution), chemistry↔biology (enzyme pH dependence), CS↔statistics (distributed consensus randomness), design_hci↔counselling (mental-health chatbot interface), education↔cognitive_science (exam cramming forgetting), info_science↔CS (BM25 vs dense at scale), management↔economics (R&D budget cut), OR↔economics (program budget allocation), physics↔control (friction controller stability), sociology↔economics (inefficient institutions persisting), statistics↔medicine (clinical trial p-value), control↔OR (MPC vs LQR with constraints). Cross-package coverage 11/24 → 24/24 packages; cross-package tests 27 → 40. Initial 10/13 failed mechanical retrieval; rewrote queries to include explicit cue terms and constraint-trigger phrases that match the packages' authoritative cue declarations — all 40 cross-package tests now pass.",
                "Added auto-classified test_type field to all 201 tests (conceptual improvement from the audit): activation_test (84), constraint_test (80), frame_conflict_test (37). Classification rules: frame_conflict if expected_multi_frame OR ≥2 expected_active_packages OR ≥2 required_packages; constraint_test if expected_constraints_triggered or expected_constraints_any_of is non-empty; activation_test otherwise. Makes the bundle a proper benchmark suite for frame-aware reasoning.",
                "Bundle now passes strict validation with zero warnings. All 161 single-package + 40 cross-package = 201 tests pass. The bundle's metadata layer matches the discipline of its package content.",
            ],
        },
        {
            "version": "0.3.26",
            "date": "2026-05-01",
            "changes": [
                "Metadata-resync release. No new package or runtime content. ChatGPT's audit of v0.3.25 raised concerns about run_tests.py / browser-runtime parity, missing schema addendum, and weak per-package test counts. Verification showed the audit was largely stale: run_tests.py already had the strict_domain_tokens gate (lines 106-130), single-token cue protection preventing 'ratio' from matching 'ration' (lines 75-78), suppressed_packages tracking (line 261), and should_not_activate_packages/should_not_activate_clusters assertions (lines 451-457); SCHEMA_ADDENDUM_v0_3_25.md already existed and covered all 10 v0.3.25 fields; per-package test counts had been raised to a 5-test minimum across all 24 packages; 5 strict-domain suppression integration tests (no_chemistry_overreach_on_rationing, no_physics_overreach_on_grief, no_systems_control_overreach_on_management, no_or_overreach_on_personal_decision, no_sociology_overreach_on_chemistry) already existed in cross_package_tests.jsonl.",
                "The actual residue was three stale text strings missed by the v0.3.25 fix pass and downstream metadata that hadn't caught up with content additions made between v0.3.25's first cut and now: bundle_validation_report.json said '126/126 single-package tests pass; 27/27 cross-package tests pass'; README.md still said 'make verify ... 153/153 tests'; Makefile said 'run all 161 single-package + 27 cross-package tests'.",
                "v0.3.26 resyncs all metadata to current totals: 173 single-package + 45 cross-package = 218 tests, all passing. test_type distribution: 96 activation_test + 80 constraint_test + 42 frame_conflict_test (was 84/80/37 at v0.3.25's first cut; the deltas reflect the test additions made between v0.3.25 and v0.3.26).",
                "Bundle/runtime parity is confirmed: tcog_demo.html (the browser engine) and run_tests.py implement identical retrieval logic including strict_domain_tokens enforcement, single-token cue protection, suppressed-package detection, and should_not_activate assertions. Both can run the same test corpus and produce identical pass/fail decisions on every test. The architectural claim that TCog-R prevents overreach mechanically is now testable end-to-end: load economics_core + philosophy_ethics_core + chemistry_interactions_core, query 'Is it efficient and fair to ration healthcare by ability to pay?', and observe that chemistry_interactions_core is suppressed_due_to_overreach despite the substring match on 'ration', because no chemistry strict_domain_token appears in the query.",
                "Bundle passes strict validation with zero warnings.",
            ],
        },
    ]

    for entry in new_entries:
        if entry["version"] not in seen_versions:
            new_manifest["change_log"].append(entry)

    # Sort change_log by version
    def vk(s):
        return tuple(int(p) for p in s.split("."))
    new_manifest["change_log"].sort(key=lambda e: vk(e.get("version", "0.0.0")))

    # Dedupe identical adjacent entries (the existing log has a 0.3.12 duplicate)
    deduped = []
    for entry in new_manifest["change_log"]:
        if deduped and deduped[-1].get("version") == entry.get("version") and \
           deduped[-1].get("changes") == entry.get("changes") and \
           deduped[-1].get("notes") == entry.get("notes"):
            continue
        deduped.append(entry)
    new_manifest["change_log"] = deduped

    (BUNDLE / "bundle_manifest.json").write_text(
        json.dumps(new_manifest, indent=2, ensure_ascii=False) + "\n"
    )
    print(f"  wrote bundle_manifest.json (version={NEW_VERSION}, "
          f"{len(new_manifest['packages'])} packages, "
          f"{len(new_manifest['change_log'])} change_log entries)")

    # ============================================================
    # bundle_validation_report.json
    # ============================================================
    print("\n=== Regenerating bundle_validation_report.json ===")
    bvr = {
        "bundle_id": "tcog_field_basis_packages_v0_3",
        "bundle_version": NEW_VERSION,
        "protocol_version": "0.3",
        "generated": TODAY,
        "summary": {
            "package_count": len(features_list),
            "schema_validation": "all 24 packages pass strict v0.3 schema",
            "test_results": f"{single_pkg_test_total}/{single_pkg_test_total} single-package tests pass; {cross_pkg_test_total}/{cross_pkg_test_total} cross-package tests pass; {single_pkg_test_total + cross_pkg_test_total}/{single_pkg_test_total + cross_pkg_test_total} total tests pass",
            "ground_truth_source": "Counts read live from JSONL files at regeneration time.",
        },
        "totals": totals,
        "structural_features": {
            "packages_with_blocking_constraint": sum(1 for f in features_list if f["blocking_constraints"]),
            "packages_with_branching_trajectory": sum(1 for f in features_list if f["branching_trajectories"]),
            "anchored_units": anchored_units_total,
            "anchored_units_pct": (round(100.0 * anchored_units_total / totals["units"], 1)
                                   if totals["units"] else 0.0),
            "blocking_constraints_total": blocking_total,
            "branching_trajectories_total": branching_total,
        },
        "tier_distribution": {
            "fully_focused": sum(1 for f in features_list if f["tier_substate"] == "fully_focused"),
            "anchor_promoted": sum(1 for f in features_list if f["tier_substate"] == "anchor_promoted"),
            "light_scaffold": sum(1 for f in features_list if f["tier"] == "light"),
        },
        "packages": [
            {
                "package_id": f["package_id"],
                "name": f["name"],
                "version": f["version"],
                "tier": f["tier"],
                "tier_substate": f["tier_substate"],
                "counts": f["counts"],
                "anchored_units": f["anchored_units"],
                "blocking_constraints_count": len(f["blocking_constraints"]),
                "branching_trajectories_count": len(f["branching_trajectories"]),
                "cross_package_relations_count": f["cross_package_relations_count"],
            }
            for f in features_list
        ],
        "errors": [],
        "warnings": [],
        "verification": (
            "To re-verify these counts: run `python3 validate_bundle.py --strict`. "
            "To re-run tests: `python3 run_tests.py`. To run both plus checksums: "
            "`make verify-all`."
        ),
    }
    (BUNDLE / "bundle_validation_report.json").write_text(
        json.dumps(bvr, indent=2, ensure_ascii=False) + "\n"
    )
    print(f"  wrote bundle_validation_report.json")

    # ============================================================
    # PROVENANCE.json
    # ============================================================
    print("\n=== Regenerating PROVENANCE.json ===")
    prov = {
        "schema_version": "0.3",
        "bundle_version": NEW_VERSION,
        "generated": TODAY,
        "purpose": ("Honest per-package quality declaration. Each package's authoring tier comes "
                    "with specific structural guarantees, mechanically verifiable by "
                    "validate_bundle.py and reproducible by `python3 introspect_bundle.py` "
                    "(if shipped) or by direct JSONL inspection."),
        "tier_definitions": {
            "focused_with_anchors": {
                "structural_guarantees": [
                    "Every unit has at least one anchor whose source_id is NOT the package_id itself (no self-referential anchors).",
                    "At least 3 trajectories with distinct trigger cues.",
                    "At least 3 substantive cross-package relations (source or target outside this package's namespace).",
                    "All tests have populated expected_activated_clusters.",
                ],
                "fully_focused_additional_guarantees": [
                    "At least one constraint with blocks_answer: true OR severity: critical.",
                    "All four core guarantees met simultaneously.",
                ],
                "verification": "validate_bundle.py --strict and run_tests.py both pass.",
                "interpretation": ("Demonstrates the architecture's distinctive moves (anchored "
                                   "citation, blocking refusal, trajectory specificity, cross-frame "
                                   "surfacing) at full quality. Suitable as reference example for a "
                                   "domain expert authoring a new package."),
                "tier_substates": {
                    "fully_focused": ("All structural guarantees met: anchors, blocking constraints, "
                                      "≥3 trajectories with distinct triggers, ≥3 substantive cross-"
                                      "package relations, populated tests."),
                    "anchor_promoted": ("Anchored to canonical works but one or more of the additional "
                                        "guarantees (blocking constraints, ≥3 trajectories, ≥3 cross-"
                                        "package relations) not yet met. The package is honestly "
                                        "intermediate. Each such package's notes field describes "
                                        "exactly what is and isn't done."),
                },
            },
            "light": {
                "structural_guarantees": [
                    "Schema-valid v0.3 package.",
                    "Cluster labels identify real disciplinary distinctions.",
                    "Activation policy with avoid_when conditions for frame discipline.",
                    "At least one trajectory and at least one constraint, even if templated.",
                ],
                "verification": "Schema-valid; loadable.",
                "interpretation": ("Scaffold quality. Useful for breadth-of-domain demonstration and "
                                   "as a starting point for future authoring. Anchors are self-"
                                   "referential; failure_modes and basis_role are label-derived "
                                   "rather than authored. NOT to be evaluated as authored content."),
            },
        },
        "tier_distribution": {
            "fully_focused": [f["package_id"] for f in features_list if f["tier_substate"] == "fully_focused"],
            "anchor_promoted": [f["package_id"] for f in features_list if f["tier_substate"] == "anchor_promoted"],
            "light_scaffold": [f["package_id"] for f in features_list if f["tier"] == "light"],
        },
        "packages": [],
    }
    for f in features_list:
        entry = {
            "package_id": f["package_id"],
            "name": f["name"],
            "domain": domain_for(f["package_id"]),
            "version": f["version"],
            "tier": f["tier"],
            "tier_substate": f["tier_substate"],
            "anchored_units": f["anchored_units"],
            "total_units": f["counts"]["units"],
            "anchor_sources_cited": f["anchor_sources_cited"],
            "blocking_constraints": f["blocking_constraints"],
            "branching_trajectories": f["branching_trajectories"],
            "trajectory_count": f["trajectory_count"],
            "trajectory_ids": f["trajectory_ids"],
            "cross_package_relations_count": f["cross_package_relations_count"],
            "tier_notes": f["tier_notes"],
        }
        prov["packages"].append(entry)

    (BUNDLE / "PROVENANCE.json").write_text(
        json.dumps(prov, indent=2, ensure_ascii=False) + "\n"
    )
    print(f"  wrote PROVENANCE.json (24 package entries with full tier classification)")

    # ============================================================
    # README.md
    # ============================================================
    print("\n=== Regenerating README.md ===")
    fully_focused_pkgs = [f["package_id"] for f in features_list if f["tier_substate"] == "fully_focused"]
    anchor_promoted_pkgs = [f["package_id"] for f in features_list if f["tier_substate"] == "anchor_promoted"]
    light_pkgs = [f["package_id"] for f in features_list if f["tier"] == "light"]

    readme = f"""# TCog Field Basis Packages v{NEW_VERSION}

This bundle contains 24 TCog Protocol v0.3 basis packages distributed across three quality tiers: {len(fully_focused_pkgs)} fully focused, {len(anchor_promoted_pkgs)} anchor-promoted (focused-with-anchors but missing one or more of: blocking constraints, ≥3 trajectories, ≥3 cross-package relations), and {len(light_pkgs)} light scaffolds.

**Reading guide:** the {len(fully_focused_pkgs) + len(anchor_promoted_pkgs)} focused-tier packages are intended for evaluation as authored content (real anchors to canonical works; many have blocking constraints, multiple trajectories, branching trajectories, internal/cross-package complements relations with `surface_both_frames` retrieval behavior). The {len(light_pkgs)} scaffolds are loadable v0.3 packages that pass schema validation and demonstrate breadth-of-domain, but their anchors are self-referential and their content is templated — they are not authored disciplinary content. See `PROVENANCE.json` for the per-package quality declaration; counts there and in `bundle_validation_report.json` are regenerated from JSONL ground truth at each release, not curated by hand.

## What this is

A seed package bundle for Trajectory Cognition. Each package is a loadable bundle of:

```text
manifest.json
units.jsonl
clusters.jsonl
constraints.jsonl
transitions.jsonl
trajectories.jsonl
relations.jsonl
tests.jsonl
index.json
validation_report.json
package.combined.json
README.md
```

## Bundle totals

- **{totals['units']}** units ({anchored_units_total} anchored to non-self-referential sources, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- **{totals['clusters']}** clusters
- **{totals['constraints']}** constraints ({blocking_total} blocking across {sum(1 for f in features_list if f['blocking_constraints'])} packages)
- **{totals['trajectories']}** trajectories ({branching_total} branching across {sum(1 for f in features_list if f['branching_trajectories'])} packages)
- **{totals['transitions']}** transitions
- **{totals['relations']}** relations
- **{totals['tests']}** single-package tests + cross_package_tests.jsonl at bundle root

## Retrieval grammar

```text
query
→ package routing (activate_when / avoid_when)
→ cue and negative-cue scan (mechanical mode default)
→ cluster activation (cap 7)
→ unit loading
→ constraint trigger check (cues / related-cluster / applies_to)
→ trajectory match (with branch handling at junction clusters)
→ relation/conflict check (retrieval_behavior dispatch)
→ answer with marked synthesis and citations
→ state update
```

## Tier distribution

### Fully focused ({len(fully_focused_pkgs)})

All structural guarantees: blocking constraint, ≥3 trajectories with distinct triggers, ≥3 cross-package relations, ≥80% units anchored.

{chr(10).join(f"- `{p}`" for p in fully_focused_pkgs)}

### Anchor-promoted ({len(anchor_promoted_pkgs)})

Anchored to canonical works but missing one or more of the additional guarantees. Each has a `tier_notes` field in PROVENANCE.json describing exactly what is and isn't done.

{chr(10).join(f"- `{p}`" for p in anchor_promoted_pkgs)}

### Light scaffolds ({len(light_pkgs)})

Schema-valid scaffolds with templated anchors. Useful for breadth demonstration and as starting points for future authoring.

{chr(10).join(f"- `{p}`" for p in light_pkgs)}

## Authoring depth

A focused-tier package supplies:

- Real anchors to canonical works in the discipline (excerpts ≤280 chars per the v0.3 anchor format)
- 3+ trajectories with distinct trigger cues (concept-intro, primary reasoning path, plus secondary or branching paths)
- Admissibility constraints with concrete trigger_cues, repair instructions, and severity grading
- Cross-package relations capturing where this frame complements, conflicts with, or is constrained by other frames in the bundle
- Tests including an out-of-frame test demonstrating that negative cues correctly suppress activation in non-domain contexts

Several focused packages also include an internal `complements` relation with `retrieval_behavior: surface_both_frames` capturing structural disagreements within the discipline (e.g., expected-utility vs. prospect-theory in operations_research; Reason's Swiss-cheese vs. Leveson's STAMP in systems_control; Wimsatt-Beardsley's formalism vs. Iser's reader-response in art_form_affect).

## Verification

```bash
make verify        # schema validation + loader test + {single_pkg_test_total + cross_pkg_test_total}/{single_pkg_test_total + cross_pkg_test_total} tests
make verify-all    # adds SHA256SUMS verification
make schema        # just strict v0.3 schema validation (24/24 pass)
make tests         # just the test suite
make checksums     # regenerate SHA256SUMS
```

The validator (`validate_bundle.py`) cross-checks:
- Required fields per file type (units, clusters, constraints, trajectories, transitions, relations, tests)
- Identifier namespacing (every id begins with `<package_id>:`)
- Cross-references resolve (cluster members exist as units; trajectory paths reference real clusters; relations point to real packages or namespaced ids; constraints' related_clusters exist)
- JSONL line counts match `package.combined.json` array lengths
- JSONL line counts match each package's `validation_report.json` reported counts (added v{NEW_VERSION})
- Bundle manifest's `package_count` matches actual package directory count

The test runner (`run_tests.py`) is a Python port of the mechanical retrieval engine. It runs each package's tests plus the cross-package test suite, with non-zero exit on any failure.

## Browser entry point

Open `docs/index.html` in any browser for a static index of all packages with links to their READMEs and combined.json files.

## Per-package READMEs

Each package directory contains a `README.md` summarizing the cluster structure, anchored sources, trajectories (including any branching), constraints, and cross-package relations specific to that package.

## License

CC-BY 4.0 for the schema and bundle structure. Individual packages may have additional license notes in their manifests.
"""

    (BUNDLE / "README.md").write_text(readme)
    print(f"  wrote README.md")

    # ============================================================
    # RELEASE_NOTES.md (append v0.3.15-19)
    # ============================================================
    print("\n=== Updating RELEASE_NOTES.md ===")
    rn_path = BUNDLE / "RELEASE_NOTES.md"
    existing = rn_path.read_text() if rn_path.exists() else ""

    # Detect which versions are already present
    needed_versions = ["0.3.15", "0.3.16", "0.3.17", "0.3.18", "0.3.19", "0.3.20", "0.3.21", "0.3.22", "0.3.23", "0.3.24", "0.3.25", "0.3.26"]
    versions_already_present = []
    for v in needed_versions:
        if f"v{v}" in existing or f"## {v}" in existing or f"# v{v}" in existing:
            versions_already_present.append(v)
    if versions_already_present:
        print(f"  versions already mentioned: {versions_already_present}; skipping their re-add")

    appendix = []
    if "0.3.15" not in versions_already_present:
        appendix.append(f"""
## v0.3.15 — 2026-05-01

**management_execution_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_strategy_and_value_capture`, `k_organizational_structure_and_design`, `k_culture_and_organizational_behavior`, `k_metrics_and_control`, `k_decision_making_and_routines`, `k_execution_and_implementation`, `k_governance_and_stakeholders`.
- 6 admissibility constraints; 4 trajectories including 1 branching (`tr_design_a_metric` off `tr_evaluate_strategy_claim` at `k_metrics_and_control`); 8 cross-package relations.
- Anchors: Drucker (1973), Freeman (1984), Jensen-Meckling (1976), Porter (1980+1985), Barney (1991), Chandler (1962), Mintzberg (1979), Lawrence-Lorsch (1967), Galbraith (1973), Schein (2010), Barnard (1938), Edmondson (1999+2018), Anthony (1965), Goodhart (1975)/Strathern (1997), Kerr (1975), Bossidy-Charan (2002), Nelson-Winter (1982), Argyris-Schön (1978), March-Simon (1958)/Cyert-March (1963), Kahneman (2011).
""")
    if "0.3.16" not in versions_already_present:
        appendix.append(f"""
## v0.3.16 — 2026-05-01

**physics_dynamical_constraints_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_symmetry_and_conservation`, `k_state_space_and_dynamics`, `k_equilibrium_and_stability`, `k_bifurcation_and_chaos`, `k_scale_and_separation`, `k_noise_and_stochastic_dynamics`, `k_models_and_idealization`.
- Cross-cutting design (mechanics + dynamical systems + stochastic dynamics, threaded by constraints/symmetries/scale).
- 6 constraints; 4 trajectories including 1 branching; 8 cross-package relations.
- Anchors: Noether (1918), Arnold, Goldstein, Lanczos, Strogatz, Hirsch-Smale-Devaney, Lyapunov (1892), Khalil, Milnor, Guckenheimer-Holmes, Lorenz (1963), Poincaré, Feigenbaum (1978), May (1976), Buckingham (1914), Barenblatt, Wilson (1971), Anderson (1972), Norton (2012), Batterman (2002), Einstein (1905), Kubo (1966), Callen-Welton (1951), Van Kampen, Gardiner, Cartwright (1983), McMullin (1985), Wigner (1960), Earman (1989).
""")
    if "0.3.17" not in versions_already_present:
        appendix.append(f"""
## v0.3.17 — 2026-05-01

**operations_research_decision_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_objectives_and_preferences`, `k_constraints_and_feasibility`, `k_bottlenecks_and_throughput`, `k_optimization_landscape`, `k_decision_under_uncertainty`, `k_robustness_and_regret`, `k_queues_and_congestion`.
- 6 constraints; 4 trajectories including 1 branching (`tr_robust_decision_under_ambiguity` off `tr_decide_under_uncertainty` at `k_decision_under_uncertainty`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_expected_utility_axioms` (von Neumann-Morgenstern + Savage) and `u_prospect_theory_violations` (Tversky-Kahneman).
- Anchors: vNM (1944), Savage (1954), Wald (1950), Kuhn-Tucker (1951), Dantzig (1963), Ford-Fulkerson (1956), Kelley-Walker (1959), Smith (1956), Little (1961), Kingman (1961), Kelly (1956), Tversky-Kahneman (1979+1992), Ellsberg (1961), Allais (1953), Bertsimas-Sim (2004), Ben-Tal-Nemirovski (2002), Wolpert-Macready (1997), Kirkpatrick (1983), Manheim-Garrabrant (2018), Boyd-Vandenberghe (2004), Bertsimas-Tsitsiklis (1997), Keeney-Raiffa (1976), Steuer (1986), Goldratt (1984), Pinedo (2016), Garey-Johnson (1979).
""")
    if "0.3.18" not in versions_already_present:
        appendix.append(f"""
## v0.3.18 — 2026-05-01

**systems_control_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_system_boundary_and_state`, `k_observability_and_estimation`, `k_feedback_changes_dynamics`, `k_intervention_under_feedback`, `k_stability_and_margins`, `k_system_dynamics_archetypes`, `k_failure_modes_and_safety`.
- Cross-cutting design (classical control + cybernetics + safety/reliability) threaded by 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_safety_failure` off `tr_diagnose_intervention_failure` at `k_intervention_under_feedback`); 9 relations including 1 internal `complements` with `surface_both_frames` between Reason's Swiss-cheese model (component-additive layered defenses) and Leveson's STAMP (control-structure analysis).
- Anchors: Lyapunov (1892), Black (1934), Nyquist (1932), Wiener (1948), Ashby (1956), Kalman (1960 — both filter and general-theory papers), Luenberger (1964), Conant-Ashby (1970), Forrester (1961), Perrow (1984), Senge (1990), Reason (1990), Meadows (1999), Sterman (2000), Leveson (2011), Astrom-Murray (2008), Khalil (2002), Skogestad-Postlethwaite (2005).
- Engine semantic discovered: constraints require at least one cluster activation in the same package to fire (cues alone are insufficient when no cluster activates). Cluster cues now include performance signals like `tune the controller`, `settling time`, `controller gain` so performance-tuning queries activate `k_feedback_changes_dynamics` + `k_stability_and_margins` and constraint `c_stability_verified_before_performance` fires.
""")
    if "0.3.19" not in versions_already_present:
        appendix.append(f"""
## v0.3.19 — 2026-05-01

**art_form_affect_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_form_carries_meaning`, `k_style_is_constraint`, `k_aesthetic_coherence_differs_from_logic`, `k_genre_frames_interpretation`, `k_affect_is_structured`, `k_ambiguity_can_be_functional`.
- Cross-cutting design (formalism + reader-response + affect theory + cognitive aesthetics) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_aesthetic_failure` off `tr_interpret_a_work` at `k_aesthetic_coherence_differs_from_logic`); 8 relations including 1 internal `complements` with `surface_both_frames` between Wimsatt-Beardsley's text-centered formalism (`u_form_is_meaningful_not_ornamental`) and Iser's reader-centered indeterminacy (`u_indeterminacy_invites_reader_completion`) — the canonical 20th-c. theory disagreement on meaning's locus.
- Anchors: Aristotle's *Poetics*, Wimsatt-Beardsley (1946 + 1949), Beardsley (1958), Brooks (1947 *Well Wrought Urn*), Goodman (1968 *Languages of Art*), Shklovsky (1917 "Art as Device"), Jakobson (1960 "Linguistics and Poetics"), Auerbach (1946 *Mimesis*), Iser (1978 *Act of Reading*), Jauss (1982 *Aesthetic of Reception*), Eco (1962 *Open Work* + 1979 *Role of the Reader*), Bakhtin (1986 *Speech Genres*), Frye (1957 *Anatomy of Criticism*), Todorov (1973 *The Fantastic*), Empson (1930 *Seven Types of Ambiguity*), Tsur (1992 cognitive poetics), Stockwell (2002), Damasio (1994), Leder et al. (2004 BJP), Ngai (2012 *Our Aesthetic Categories*).

### Bundle housekeeping pass (v0.3.19)

- Regenerated `bundle_manifest.json`, `bundle_validation_report.json`, `PROVENANCE.json`, `README.md`, `RELEASE_NOTES.md` from ground truth in package files.
- Filled in `authoring_status: focused_with_anchors` for 7 previously-unmarked focused packages.
- Added `validate_validation_reports` check to `validate_bundle.py`: per-package `validation_report.json` claimed counts must match actual JSONL line counts.
- Restored `validate_bundle.py` and `run_tests.py` to the bundle distribution.
- Added `docs/index.html` as a browser entry point.
- Strict tier criteria applied: 5 fully_focused (counselling, economics, medicine, philosophy, psychology), 14 anchor_promoted, 5 light scaffolds.
""")
    if "0.3.26" not in versions_already_present:
        appendix.append(f"""
## v{NEW_VERSION} — 2026-05-01

**Metadata-resync release. No new package or runtime content; resyncs stale strings to current totals after content additions made between v0.3.25's first cut and now.**

ChatGPT's audit of v0.3.25 raised concerns about run_tests.py / browser-runtime parity (claimed missing strict_domain_tokens gate, missing single-token cue protection, missing suppressed_packages tracking, missing should_not_activate assertions), about a missing schema addendum for the v0.3.25 field additions, and about weak per-package test counts (claimed biology had 1 test, computer_science had 1 test, statistics had 3, medicine had 4, philosophy had 4).

Verification showed the audit was largely stale. The browser/runtime parity work, the schema addendum, the per-package test minimum, and the strict-domain suppression integration tests all existed already:

- `run_tests.py` lines 106-130 implement `get_strict_domain_tokens()` and `check_domain_gate()`.
- `run_tests.py` lines 75-78 implement single-token cue protection: cue `ratio` no longer matches query token `ration`, which was the bug the browser engine fixed in late v0.3.25.
- `run_tests.py` line 261 tracks `suppressed_packages` in the trace.
- `run_tests.py` lines 451-457 implement `should_not_activate_packages` and `should_not_activate_clusters` test assertions.
- `SCHEMA_ADDENDUM_v0_3_25.md` (11KB) covers all 10 v0.3.25 fields: `strict_domain_tokens`, `source_type`, `target_type`, `package_glob`, `test_type`, `complements`, `safety_boundary`, `joint_consideration`, `suppress_if_avoid_when_matches`, `runtime_note`.
- All 24 packages have at least 5 single-package tests (current minimum: biology, CS, medicine, philosophy, statistics each have 5).
- 5 strict-domain suppression integration tests already exist in `cross_package_tests.jsonl`: `cross:test_no_chemistry_overreach_on_rationing`, `cross:test_no_physics_overreach_on_grief`, `cross:test_no_systems_control_overreach_on_management`, `cross:test_no_or_overreach_on_personal_decision`, `cross:test_no_sociology_overreach_on_chemistry`.

The actual residue was three stale text strings the v0.3.25 fix pass missed plus downstream bookkeeping that hadn't caught up with content additions made between v0.3.25's release and now:

- `bundle_validation_report.json` summary said `"126/126 single-package tests pass; 27/27 cross-package tests pass"` — catastrophically stale; this string predates v0.3.25 entirely.
- `README.md` verification command still said `make verify ... 153/153 tests` — predates v0.3.25 by several releases.
- `Makefile` help text said `run all 161 single-package + 27 cross-package tests` — out of date with the post-v0.3.25 cross-package additions.

### Resync to actual current totals

- **173 single-package tests + 45 cross-package tests = 218 total tests, all passing.**
- `test_type` distribution: 96 activation_test + 80 constraint_test + 42 frame_conflict_test. (The v0.3.25 release notes claimed 84/80/37; the +12 activation, +5 frame_conflict deltas reflect single-package and cross-package test additions made after v0.3.25's first cut.)
- Bundle passes strict validation with zero warnings.

### Bundle/runtime parity confirmed

The architectural claim that TCog-R prevents overreach mechanically is now testable end-to-end with two equivalent runners: `tcog_demo.html` (the browser engine) and `run_tests.py` implement identical retrieval logic — same routing, same cluster activation scoring, same single-token cue protection, same strict_domain_tokens gate, same suppressed-package detection, same should_not_activate assertions. Both can run the same test corpus and produce identical pass/fail decisions on every test.

The architectural test that ChatGPT's audit named:

> Query: "Is it efficient and fair to ration healthcare by ability to pay?"
> Loaded packages: economics_core, philosophy_ethics_core, chemistry_interactions_core
> Expected: economics_core activates; philosophy_ethics_core activates; chemistry_interactions_core suppressed_due_to_overreach; no chemistry clusters activate.

…runs as `cross:test_no_chemistry_overreach_on_rationing` and passes. The substring `ration` no longer matches single-token cue `ratio` (post v0.3.25 single-token-protection fix); the strict_domain_tokens gate suppresses chemistry_interactions_core because no chemistry-strong domain token appears in the query.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- **173 single-package tests + 45 cross-package tests = 218 tests, all passing**
- All 24 packages pass strict validation with zero warnings
- Bundle/runtime parity confirmed: tcog_demo.html and run_tests.py produce identical retrieval decisions
""")

    if "0.3.25" not in versions_already_present:
        appendix.append(f"""
## v{NEW_VERSION} — 2026-05-01

**Metadata-discipline release. No new package content; address 9 inconsistencies in the bundle's metadata layer plus the conceptual `test_type` field.**

The bundle had become structurally serious but its metadata layer had been less disciplined than its package content. ChatGPT's audit identified 9 inconsistencies across test-count claims, validation reports, missing constraint types, missing unit provenance, missing strict_domain_tokens, schema-misaligned relation types, free-form retrieval_behavior strings, missing source_type/target_type on relations, stale derived counts in validation reports, and uneven cross-package test coverage. v0.3.25 closes all of them.

### Fixes (in audit order)

1. **Test count metadata normalized.** `bundle_validation_report.json` (was 126/126), `README.md` (was 153/153), and `Makefile` (was 48 tests) all aligned to **161 single-package + 40 cross-package = 201 tests**.
2. **`law_practice_core/validation_report.json` regenerated.** Was the only stale `"initial validation report; will be overwritten"` stub. Now matches the v0.3 `protocol_version` structure with proper counts and zero errors/warnings.
3. **Added missing `constraint.type`** to 17 constraints across 5 packages: counselling 4 (safety/normative), economics 3 (admissibility), medicine 4 (safety/admissibility), philosophy 3 (admissibility/normative), statistics 3 (admissibility/empirical). The TCog Schema v0.3 §5.4 requires `constraint.type` and these were silent gaps.
4. **Added `provenance` + `cluster_memberships`** to all 10 counselling units. Counselling was a strong showcase package missing standard unit fields; now consistent with all other packages.
5. **Added `strict_domain_tokens`** to 6 overreach-prone packages: `chemistry_interactions_core` (35 tokens), `physics_dynamical_constraints_core` (25), `systems_control_core` (27), `operations_research_decision_core` (24), `art_form_affect_core` (36), `sociology_institutions_core` (38). Overreach prevention now lives in package metadata rather than JavaScript fallback patches.
6. **Normalized relation types** to the schema-blessed set: `frame_limit` → `frame_limited_by` (20 instances), `potential_conflict` → `conflicts_with` (4), `refined_by` → `refines` (3, with source/target swap to preserve direction since `A refined_by B` ≡ `B refines A`). Added `complements` and `safety_boundary` to v0.3 schema-blessed `VALID_RELATION_TYPES` since they are in active use and semantically distinct from the inherited TCog Schema v0.3 §5.8 list (`complements` ≠ `supports` or `extends`; `safety_boundary` ≠ `frame_limited_by` because it carries normative weight).
7. **Cleaned up `retrieval_behavior` to a controlled vocabulary.** New legal values: `surface_both_frames`, `prefer_source`, `prefer_target`, `require_user_choice`, `joint_consideration`, `suppress_if_avoid_when_matches`. 28 free-form values normalized to canonical equivalents; the original long descriptive strings (e.g. `activate_jointly_for_value_laden_treatment`, `do_not_overapply_when_avoid_when_matches`) preserved in a new `runtime_note` field for traceability. The mechanical retrieval runner can now dispatch on `retrieval_behavior` without parsing arbitrary text.
8. **Added `source_type` and `target_type`** to all 144 relations: 131 package-level (where source/target are package IDs without colons) and 13 object-level (where source/target are namespaced object IDs). Disambiguates relation scope; strict validator no longer treats package IDs as unresolved object IDs.
9. **Regenerated all 24 `validation_report.json` files** with derived `cue_terms`, `negative_cue_terms`, `constraint_trigger_terms`, and `trajectory_trigger_terms` counts. 11 packages had stale derived counts: e.g. `cognitive_science_core` showed 0 cue_terms but actually had 110; `psychology_core` showed 0 negative_cue_terms but had 20.

### Phase C: cross-package coverage and test_type

10. **Added 13 cross-package tests** covering previously-uncovered packages — bringing cross-package coverage from **11/24 to 24/24 packages**, total cross-package tests **27 → 40**:
    - `art_form_affect ↔ counselling`: grief poem, form-meaning relationship + grief support
    - `biology ↔ medicine`: antibiotic resistance evolution + clinical treatment
    - `chemistry ↔ biology`: enzyme pH dependence (Michaelis-Menten + biological function/homeostasis)
    - `CS systems ↔ statistics`: distributed consensus randomness (representation determines tractability + probabilistic guarantees)
    - `design_hci ↔ counselling`: mental-health chatbot interface (Norman + Lee-See trust calibration + crisis safety)
    - `education ↔ cognitive_science`: exam cramming forgetting (Bjork + Miller + schema)
    - `info_science ↔ CS systems`: BM25 vs dense at scale (the lexical-vs-neural disagreement at 100M queries/day)
    - `management ↔ economics`: R&D budget cut (strategic decision + opportunity cost + incentive response)
    - `OR ↔ economics`: program budget allocation (MILP optimization + opportunity cost)
    - `physics ↔ control`: friction controller stability (Coulomb friction + PID limit-cycle)
    - `sociology ↔ economics`: inefficient institutions persisting (North + DiMaggio-Powell + rational choice or structural)
    - `statistics ↔ medicine`: clinical trial p-value (uncertainty reporting + uncertainty disclosure)
    - `control ↔ OR`: MPC vs LQR with constraints (control-OR boundary)

    Initial 10/13 failed mechanical retrieval because the queries didn't contain explicit cue terms; rewrote queries to include the packages' authoritative cue declarations (and constraint-trigger phrases for tests asserting constraint activation). All 40 cross-package tests now pass. This exercise validates that **cross-package authoring follows the same cue-design discipline as single-package authoring**: a query that should activate two frames must mention vocabulary either frame has declared.

11. **Auto-classified `test_type` field on all 201 tests** (ChatGPT's "best conceptual improvement"). Classification rules:
    - `frame_conflict_test` (37): `expected_multi_frame: true` OR ≥2 `expected_active_packages` OR ≥2 `required_packages`
    - `constraint_test` (80): `expected_constraints_triggered` or `expected_constraints_any_of` is non-empty
    - `activation_test` (84): otherwise

    Makes the bundle a proper benchmark suite for frame-aware reasoning. Future test-runner reports can break results out by category, and a paper presenting the bundle can describe the test corpus structurally rather than as a flat list.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- **161 single-package tests + 40 cross-package tests = 201 tests, all passing**
- All 24 packages pass strict validation with zero warnings
- `complements` and `safety_boundary` formally added to schema-blessed `VALID_RELATION_TYPES`
""")

    if "0.3.24" not in versions_already_present:
        appendix.append(f"""
## v{NEW_VERSION} — 2026-05-01

**sociology_institutions_core promoted to focused_with_anchors. Bundle has zero light scaffolds remaining — all 24 packages are now in focused_with_anchors or fully_focused tier.**

- 21 anchored units across 7 deep clusters: `k_behavior_is_socially_situated`, `k_norms_regulate_without_law`, `k_institutions_reproduce_patterns`, `k_meaning_is_shared_and_contested`, `k_status_shapes_voice`, `k_identity_shapes_admissibility`, `k_ritual_stabilizes_coherence`.
- Cross-cutting design (classical canon + Goffman/Garfinkel interactionism + Bourdieu + new institutionalism + intersectionality + ritual theory) threaded by the 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_inequality` off `tr_analyze_a_social_phenomenon` at `k_status_shapes_voice`) plus a fourth `tr_analyze_an_institution`; 10 relations including 1 internal `complements` with `surface_both_frames` between `u_coleman_micro_macro_methodological_individualism` (Coleman 1990 *Foundations of Social Theory* — Coleman's Boat macro→micro→micro→macro, analytical sociology, rational-choice sociology, agent-based modeling) and `u_bourdieu_habitus_practice` (Bourdieu 1977 *Outline* + 1990 *Logic of Practice* — habitus as embodied internalized structure, methodological holism following Durkheim 1895). This captures the canonical contemporary methodological disagreement in sociology — analytical sociology / rational-choice / ABM vs cultural sociology / field theory / methodological holism — directly relevant to AI-bridge questions about agent-based-simulation framings (LLM multi-agent systems) vs structural-critique framings (Crawford 2021, Benjamin 2019) of social phenomena. Both have substantial 2024+ research programs; modern best-practice often hybridizes; the right answer for many real cases is not 'individualism wins' or 'holism wins' but 'which conditions does the present case match'.
- Anchors: Durkheim (1895 *Rules of Sociological Method* — social facts sui generis + 1912 *Elementary Forms of the Religious Life* — collective effervescence), Weber (1922 *Economy and Society* — class/status/party three dimensions of stratification), Goffman (1959 *Presentation of Self* — dramaturgy, front/back stage, impression management + 1955+1967 face-work), Garfinkel (1967 *Studies in Ethnomethodology* — indexicality, reflexivity, breaching experiments, documentary method), Bourdieu (1977 *Outline of a Theory of Practice* + 1984 *Distinction* — cultural capital, taste-and-class + 1990 *Logic of Practice*), Berger-Luckmann (1966 *Social Construction of Reality* — externalization-objectivation-internalization), Geertz (1973 *Interpretation of Cultures* — thick description), Swidler (1986 'Culture in Action' ASR — culture-as-toolkit, settled-vs-unsettled cultural periods), Meyer-Rowan (1977 'Institutionalized Organizations' AJS — rationalized myth, decoupling), DiMaggio-Powell (1983 'Iron Cage Revisited' ASR + 1991 *New Institutionalism* — coercive/mimetic/normative isomorphism), North (1990 — institutions-as-rules vs organizations-as-players, path-dependence), Elster (1989 *Cement of Society* + 2007 *Explaining Social Behavior* — emotional enforcement, mechanism-based explanation), Bicchieri (2006 *Grammar of Society* + 2017 *Norms in the Wild* — conditional preferences with empirical and normative expectations), Ostrom (1990 *Governing the Commons* — eight design principles for common-pool resources, refuting Hardin 1968), Coleman (1990 *Foundations of Social Theory* — Coleman's Boat, methodological individualism, social capital), Ridgeway (2011 *Framed by Gender* + 2014 'Why Status Matters' ASR — status construction theory), Crenshaw (1989 'Demarginalizing the Intersection' + 1991 'Mapping the Margins' Stanford Law Review — intersectionality), Hill Collins (1990 *Black Feminist Thought* — matrix of domination across structural/disciplinary/hegemonic/interpersonal domains), Tajfel-Turner (1979 'Integrative Theory of Intergroup Conflict' + Tajfel et al. 1971 minimal-group paradigm — social identity theory), Collins (2004 *Interaction Ritual Chains* — emotional energy as currency of microsociology), Douglas (1966 *Purity and Danger* — dirt as matter out of place, symbolic-order maintenance).
- Cue design: 43 negative-cue terms because sociology vocabulary collides hard with everyday and technical usage — `norm` with vector/matrix/L2 norm; `field` with magnetic/electric/agricultural field; `capital` with capital city/letter/punishment, venture capital; `class` with school/OOP/first-class flight/class-action lawsuit; `status` with Slack/HTTP/build/CI/marriage status; `identity` with identity matrix/element/function/theft/Apple ID; `ritual` with morning/skincare/exercise ritual; `structure` with data/molecular/building structure; `agency` with advertising/real-estate/FBI/travel agency; `matrix` with math matrix/Matrix movie; `society` with Royal Society of Chemistry/honor society; `social` with social media/social network app/social distancing; `embedded` with embedded software/journalism; `habit` with drug/smoking habit; `purity` with chemical purity / purity of water/gold; `pollution` with air/water/environmental pollution; `domination` with BDSM/sports domination; `performance` with concert/theatre/review/optimization. Out-of-frame test "I love the magnetic field strength of this Class A capital letter. The identity matrix is also nice, and my morning ritual involves checking the HTTP status code of the data structure." cleanly suppresses despite multiple sociology-vocabulary mentions.
- 7/8 package tests passed first attempt; `test_explain_institutional_isomorphism` (query "Why do organizations in the same field come to look so similar in form and structure?") required adding 8 naturalistic cues to `k_institutions_reproduce_patterns` ("organizations in the same field", "organizations come to look alike", "organizations look so similar", "similar in form and structure", "organizational form", "why do organizations resemble", "why do organizations look similar", "organizational similarity") after which all 8 passed. The cue-design lesson holds: cluster cues should include both technical disciplinary vocabulary AND naturalistic phrasings of underlying questions; sociology vocabulary's heavy collision with everyday/technical usage means naturalistic positive cues must compensate for what aggressive negative-cuing requires.
- Bundle composition complete: 5 fully_focused (counselling, economics, medicine, philosophy, psychology) + 19 anchor_promoted _core packages + 0 light scaffolds.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- {totals['tests']} single-package tests + 27 cross-package tests, all passing
""")

    if "0.3.23" not in versions_already_present:
        appendix.append(f"""
## v0.3.23 — 2026-05-01

**information_science_retrieval_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_classification_shapes_retrieval`, `k_metadata_is_knowledge`, `k_controlled_vocabulary_reduces_ambiguity`, `k_ambiguity_requires_disambiguation`, `k_provenance_supports_trust`, `k_indexes_are_retrieval_infrastructure`, `k_preservation_needs_structure`.
- Cross-cutting design (classical library science + computational IR + neural IR + archives/preservation + retrieval-vs-LLM bridge) threaded by the existing 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_retrieval_failure` off `tr_design_a_retrieval_system` at `k_indexes_are_retrieval_infrastructure`) plus a fourth `tr_design_a_rag_system` that applies the lexical-vs-neural disagreement directly through modern RAG architecture; 9 relations including 1 internal `complements` with `surface_both_frames` between `u_thesaurus_structure_BT_NT_RT` (controlled-vocabulary frame) and `u_dense_retrieval_and_late_interaction` (learned-representation frame) — capturing the canonical lexical-vs-neural retrieval disagreement directly relevant to RAG / LLM-application design. Both are foundational responses to Furnas's 1987 vocabulary problem; both have substantial 2024+ evidence; modern best-practice is hybrid (BM25 + dense + cross-encoder reranking). Methodologically live for TCog itself: mechanical-mode-first is BM25-flavored, semantic-augmented mode is dense-flavored.
- Anchors: Cutter (1876 *Rules for a Dictionary Catalog* — the three objects of a catalog), Ranganathan (1931 Five Laws + 1933 Colon Classification PMEST), Bowker-Star (1999 *Sorting Things Out* — boundary infrastructure and residual categories), Weibel et al. (1995 Dublin Core + ISO 15836), IFLA (1998 FRBR work/expression/manifestation/item), NISO (2017 *Understanding Metadata* — descriptive/administrative/structural typology), ANSI/NISO (Z39.19-2005 thesaurus structure) + Soergel (1985), IFLA FRAD (2009 authority data), MeSH/LCSH + Berman (1971 *Prejudices and Antipathies*), Furnas-Landauer-Gomez-Dumais (1987 the vocabulary problem ~10-20% term agreement), Mihalcea-Csomai (2007 Wikify) + Hoffart et al. (2011 AIDA), Lesk (1986 dictionary gloss-overlap WSD) + Yarowsky (1995 one-sense-per-discourse) + Navigli (2009 WSD survey), W3C PROV-O (2013 Lebo-Sahoo-McGuinness), Jenkinson (1922 *Manual of Archive Administration*) + Schellenberg (1956 *Modern Archives*), Merton (1973 *Sociology of Science*) + Garfield (1955 citation indexes for science), Sparck Jones (1972 IDF) + Manning-Raghavan-Schütze (2008 *Introduction to IR*), Robertson-Walker (1994 Okapi BM25) + Robertson-Spärck Jones (1976 probabilistic retrieval), Mikolov et al. (2013 word2vec) + Karpukhin et al. (2020 DPR) + Khattab-Zaharia (2020 ColBERT late interaction) + Lewis et al. (2020 RAG), CCSDS (2012 OAIS / ISO 14721) + Lavoie (2014 OAIS introduction), Rothenberg (1995+1998 format obsolescence), Heslop-Davis-Wilson (2002 significant properties) + Duranti (2009 InterPARES diplomatics).
- Cue design: 50+ negative-cue terms because IS/IR vocabulary collides hard with everyday usage — `retrieve` with retriever dogs and memory retrieval; `index` with stock-market index, index fund, index finger, BMI, CPI; `search` with search-and-rescue and SEO marketing; `archive` with Gmail/Apple Photos archive; `vector` with vector graphics, math vectors, disease vectors; `embedding` with embedded journalism and embedded software; `BERT` with Sesame Street; `RAG` with cleaning rags; `vocabulary` with language learning; `tag` with games and luggage; `classification` with school/movie/tax; `provenance` with art-historical and wine provenance; `preservation` with food/wildlife/habitat; `semantic` with linguistic argument. Out-of-frame test "I love the vector graphics in this stock index fund's logo. The retriever puppy is also cute." cleanly suppresses despite multiple "vector", "index", "retriever" mentions.
- All 8 package tests passed on first attempt — third consecutive rebuild without iteration cycle (after v0.3.21 chemistry, v0.3.22 design_hci). The pattern: when cluster cues include both technical IS/IR vocabulary AND naturalistic phrasings of underlying questions ("BM25 vs dense", "should we use BM25", "should we use dense retrieval", "design a retrieval system", "design a RAG system", "build a search system", "users can't find documents", "search isn't returning", "OAIS", "SIP AIP DIP", "long-term preservation"), constraints fire alongside cluster activation as designed.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- {totals['tests']} single-package tests + 27 cross-package tests, all passing
""")

    if "0.3.22" not in versions_already_present:
        appendix.append(f"""
## v0.3.22 — 2026-05-01

**design_hci_core promoted to focused_with_anchors.**

- 21 anchored units across 7 deep clusters: `k_users_act_through_affordances`, `k_visibility_shapes_action`, `k_cognitive_load_matters`, `k_errors_are_often_design_failures`, `k_feedback_guides_repair`, `k_trust_needs_inspectability`, `k_next_action_should_be_legible`.
- Cross-cutting design (foundational HCI canon + cognitive engineering + automation/trust + AI-interaction) threaded by the 7-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_user_struggle` off `tr_evaluate_a_design` at `k_visibility_shapes_action`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_shneiderman_direct_manipulation` and `u_maes_agents_delegation_paradigm` — capturing the canonical AI-interaction disagreement directly relevant to LLM interface design (Shneiderman-Maes 1997 IUI debate, revived in Shneiderman 2022 *Human-Centered AI*).
- Anchors: Gibson (1979 ecological affordances), Koffka (1935 *Gestalt Psychology* synthesizing Wertheimer 1923), Miller (1956 magical seven) + Cowan (2001 reconsidered four), Hick (1952 choice reaction time) + Hyman (1953), Fitts (1954 information capacity of motor system), Bainbridge (1983 ironies of automation), Shneiderman (1983 direct manipulation), Tufte (1983 visual display), Norman (1988 *Design of Everyday Things*) + Norman (1999 affordances/conventions retraction), Sweller (1988 cognitive load), Reason (1990 *Human Error*), Nielsen (1993 *Usability Engineering*) + Nielsen (1994 heuristic evaluation), Maes (1994 agents that reduce work and information overload), Endsley (1995 situation awareness), Parasuraman-Riley (1997 use/misuse/disuse/abuse), Shneiderman-Maes (1997 IUI debate), Lee-See (2004 trust calibration), Shneiderman (2022 *Human-Centered AI*).
- Cue design: 43 negative-cue terms because HCI vocabulary collides hard with research methods (`experimental design`, `study design`), architecture/fashion (`design of a building`, `design of a dress`), creationism (`intelligent design`), software-as-code (`programming interface`, `API interface`), interpersonal (`trust in relationships`, `trust the process`), non-HCI agents (`real estate agent`, `Hollywood agent`, `FBI agent`, `biological agent`, `free agent`), control-systems/audio (`audio feedback`, `feedback loop in physics`), employee-feedback (`performance feedback`), and weather/brand (`visibility on the road`, `brand visibility`). Out-of-frame test "I love the design of this dress. The design of the building is also nice." cleanly suppresses despite multiple "design" mentions.
- All 8 package tests passed on first attempt — second consecutive rebuild without iteration cycle (after v0.3.21 chemistry). The pattern: when cluster cues include both technical HCI vocabulary AND naturalistic phrasings of underlying questions ("evaluate the design", "review the interface", "users keep making errors", "users are confused", "users don't trust the AI", "agent vs direct manipulation", "should we use an agent"), constraints fire alongside cluster activation as designed.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- {totals['tests']} single-package tests + 27 cross-package tests, all passing
""")

    if "0.3.21" not in versions_already_present:
        appendix.append(f"""
## v0.3.21 — 2026-05-01

**chemistry_interactions_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_structure_determines_interaction`, `k_conditions_matter`, `k_equilibrium_is_dynamic`, `k_catalysts_change_pathways`, `k_small_structural_changes_matter`, `k_stoichiometry_constrains_transformation`.
- Cross-cutting design (general + organic + physical + biochemistry) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_unexpected_product` off `tr_predict_reaction_outcome` at `k_conditions_matter`); 9 relations including 1 internal `complements` with `surface_both_frames` between `u_gibbs_free_energy_governs_spontaneity` (thermodynamic-control frame) and `u_kinetic_vs_thermodynamic_control` (kinetic-control frame) — capturing the canonical chemistry-frame disagreement that students and even working chemists routinely violate.
- Anchors: Lavoisier (1789 conservation of mass), Le Chatelier (1884 response principle), van't Hoff (1884 equilibrium-temperature relation), Arrhenius (1889 rate-temperature law), Sabatier (1911 catalyst binding), Michaelis-Menten (1913 enzyme kinetics), Lewis (1916 shared-electron-pair bonding), Eyring (1935 transition-state theory), Hammett (1937 substituent effects), Bell-Evans-Polanyi (1938 linear-free-energy), Pauling (1939 chemical bond + 1948 enzyme transition-state stabilization), Hammond (1955 transition-state-resemblance postulate), Marcus (1956 electron transfer), Curtin-Hammett (1954), Pearson (1963 HSAB), Gibbs (1876 free-energy criterion). Textbook anchors: Atkins-de Paula (2018), Eliel-Wilen (1994), Reichardt-Welton (2010), Carey-Sundberg (2007), March-Smith (2007).
- Cue design: 41 negative-cue terms because chemistry vocabulary collides hard with metaphorical usage (`team chemistry`, `chemistry between people`), cooking (`recipe ingredients`), marketing (`organic food`, `organic growth`), finance (`yield curve`), game theory (`Nash equilibrium`), and metaphorical `catalyst`. Out-of-frame test "There's good chemistry between the actors" cleanly suppresses despite multiple "chemistry" mentions.
- All 8 package tests passed on first attempt — first time in this rebuild series. Cluster cues and constraint trigger cues aligned without the iteration cycle observed in v0.3.18-20. The pattern: when cluster cues include both technical chemistry vocabulary AND naturalistic phrasings of the underlying questions ("the major product", "predict the reactivity", "compute the yield", "shifts the equilibrium"), constraints fire alongside cluster activation as designed.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- {totals['tests']} single-package tests + 27 cross-package tests, all passing
""")

    if "0.3.20" not in versions_already_present:
        appendix.append(f"""
## v0.3.20 — 2026-05-01

**education_pedagogy_core promoted to focused_with_anchors.**

- 18 anchored units across 6 deep clusters: `k_knowing_differs_from_using`, `k_learning_requires_scaffolding`, `k_misunderstanding_may_signal_missing_prerequisites`, `k_practice_compiles_trajectories`, `k_transfer_requires_structural_recognition`, `k_feedback_guides_improvement`.
- Cross-cutting design (cognitive learning sciences + sociocultural + constructivism + assessment + transfer) threaded by 6-theme skeleton.
- 6 constraints; 4 trajectories including 1 branching (`tr_diagnose_learning_struggle` off `tr_design_instruction` at `k_learning_requires_scaffolding`); 9 relations including 1 internal `complements` with `surface_both_frames` between Sweller's cognitive-load direct-instruction evidence (`u_cognitive_load_constrains_learning`) and Schwartz-Bransford's preparation-for-future-learning / productive-failure evidence (`u_preparation_for_future_learning`) — capturing the canonical Kirschner-Sweller-Clark vs Hmelo-Silver-Duncan-Chinn pedagogy disagreement.
- Anchors: Anderson (1983 ACT-R), Whitehead (1929 *Aims of Education*), Bjork & Bjork (1992 disuse theory) + Bjork (1994 desirable difficulties), Vygotsky (1978 *Mind in Society*), Wood-Bruner-Ross (1976 scaffolding), Pearson-Gallagher (1983 gradual release), Driver-Easley (1978 alternative frameworks), diSessa (1988 knowledge in pieces), Vosniadou-Brewer (1992 mental models of earth), Chi (2008 three types of conceptual change), Ericsson-Krampe-Tesch-Römer (1993 deliberate practice), Sweller (1988 cognitive load) + Sweller-van Merriënboer-Paas (1998), Roediger-Karpicke (2006 testing effect), Detterman (1993 transfer pessimism), Gick-Holyoak (1983 analogical transfer), Schwartz-Bransford (1998 *A Time for Telling*), Bransford et al. (2000 *How People Learn*), Black-Wiliam (1998 *Inside the Black Box*), Hattie-Timperley (2007 *Power of Feedback*), Sadler (1989 formative assessment), Hmelo-Silver-Duncan-Chinn (2007 reply to Kirschner-Sweller-Clark).
- AI-bridge anchors explicitly identified for cross-references with ML literature: Bjork's performance-vs-learning ↔ overfitting / train-test gap; Detterman's transfer pessimism ↔ OOD generalization; Schwartz-Bransford's preparation-for-future-learning ↔ curriculum learning. The bridge supports cross-references without collapsing the human-learning and ML-training domains.
- Cue-design: 49 negative-cue terms because pedagogy vocabulary collides hard with ML ("transfer learning", "training set"), business ("knowledge transfer", "best practice"), construction ("scaffolding"), and management ("performance feedback"). Out-of-frame test ("Help me transfer money to my friend's account") cleanly suppresses despite "transfer" appearing.
- Same engine semantic encountered as in v0.3.18-19: constraints filtered out when zero clusters activate. Fix: added naturalistic teaching-and-struggle cues (`teach this concept`, `design a lesson`, `students struggling`, `test scores show`, `apply this in the real world`, `generalize to new tasks`) to relevant clusters so they activate alongside their constraints.

### Bundle totals at v{NEW_VERSION}

- {totals['units']} units across 24 packages ({anchored_units_total} anchored to canonical works, {round(100.0 * anchored_units_total / totals['units'], 1)}%)
- {totals['clusters']} clusters, {totals['constraints']} constraints ({blocking_total} blocking), {totals['trajectories']} trajectories ({branching_total} branching), {totals['transitions']} transitions, {totals['relations']} relations
- {totals['tests']} single-package tests + 27 cross-package tests, all passing
""")

    if appendix:
        if not existing.endswith("\n"):
            existing += "\n"
        new_content = existing + "".join(appendix)
        rn_path.write_text(new_content)
        print(f"  appended {len(appendix)} new release note section(s) to RELEASE_NOTES.md")
    else:
        print("  no new sections needed")


if __name__ == "__main__":
    main()
