#!/usr/bin/env python3
"""
TCog v0.3 test runner.

Runs all single-package tests and cross-package tests against a Python port
of the v0.3 mechanical retrieval engine. Ships with the bundle so anyone can
verify the test suite locally.

Usage:
  python3 run_tests.py                          # run everything
  python3 run_tests.py --package PKG            # one package only
  python3 run_tests.py --cross-only             # only cross-package tests
  python3 run_tests.py --json                   # machine-readable output

Exit codes:
  0 — all tests pass
  1 — one or more tests fail
"""
import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


# ============================================================================
# Retrieval engine — Python port of the JS engine in tcog_demo.html
# Behavior must match exactly. Any divergence is a bug.
# ============================================================================

SUFFIX_LEMMAS_TOK = {'s', 'es', 'ed', 'ing', 'er', 'ly', 'ation', 'tion'}
SUFFIX_LEMMAS_CUE = {'s', 'es', 'ed', 'ing', 'er', 'ly'}
STOP_WORDS = {'the', 'a', 'an', 'of', 'to', 'in', 'for', 'is', 'are', 'be', 'was', 'were'}


def normalize(text: str) -> str:
    text = text.lower()
    text = re.sub(r'[\u2018\u2019\u201C\u201D]', "'", text)
    text = re.sub(r"[\.\,\!\?\;\:\(\)\[\]\{\}'\"`]", ' ', text)
    text = re.sub(r'[\-_]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def tokenize(text: str) -> List[str]:
    return [t for t in normalize(text).split(' ') if t]


def lemma_match(token: str, cue: str) -> bool:
    t = token.lower()
    c = cue.lower()
    if t == c:
        return True
    if t.startswith(c) and len(t) > len(c):
        if t[len(c):] in SUFFIX_LEMMAS_TOK:
            return True
    if c.startswith(t) and len(c) > len(t):
        if c[len(t):] in SUFFIX_LEMMAS_CUE:
            return True
    return False


def phrase_match(cue: str, query_norm: str) -> bool:
    cue_norm = normalize(cue)
    if not cue_norm:
        return False
    cue_tokens = cue_norm.split(' ')
    query_tokens = tokenize(query_norm)
    # Substring containment is only safe for multi-word cues, where the spaces
    # act as word boundaries. For single-token cues, raw substring containment
    # produces false positives such as cue 'ratio' matching query token 'ration'
    # — which caused chemistry_interactions_core to over-activate on healthcare
    # rationing queries. Single-token cues must match a query token via lemma.
    if len(cue_tokens) > 1 and cue_norm in query_norm:
        return True
    if len(cue_tokens) == 1:
        return any(lemma_match(t, cue_norm) for t in query_tokens)

    # Sequential walk with stop-word elision
    n_query = len(query_tokens)
    n_cue = len(cue_tokens)
    for i in range(n_query - n_cue + 1):
        qi = i
        matched = True
        for ci in range(n_cue):
            while qi < n_query and query_tokens[qi] in STOP_WORDS and not lemma_match(query_tokens[qi], cue_tokens[ci]):
                qi += 1
            if qi >= n_query:
                matched = False
                break
            if not lemma_match(query_tokens[qi], cue_tokens[ci]):
                matched = False
                break
            qi += 1
        if matched:
            return True

    # 2-token bag fallback
    if len(cue_tokens) == 2:
        return all(any(lemma_match(qt, ct) for qt in query_tokens) for ct in cue_tokens)
    return False



def get_strict_domain_tokens(pkg: Dict[str, Any]) -> List[str]:
    """Mirror the browser getStrictDomainTokens(). Returns a possibly-empty list."""
    manifest = pkg.get('manifest', {})
    policy = manifest.get('activation_policy', {})
    if isinstance(policy, dict):
        ptokens = policy.get('strict_domain_tokens')
        if isinstance(ptokens, list) and ptokens:
            return ptokens
    mtokens = manifest.get('strict_domain_tokens')
    if isinstance(mtokens, list) and mtokens:
        return mtokens
    pkgtokens = pkg.get('strict_domain_tokens')
    if isinstance(pkgtokens, list) and pkgtokens:
        return pkgtokens
    fallback = pkg.get('_strict_domain_tokens')
    if isinstance(fallback, list) and fallback:
        return fallback
    return []


def check_domain_gate(query: str, pkg: Dict[str, Any]) -> Dict[str, Any]:
    """Mirror the browser checkDomainGate(). Returns {'passes', 'matched', 'tokens'}."""
    tokens = get_strict_domain_tokens(pkg)
    if not tokens:
        return {'passes': True, 'matched': [], 'tokens': []}
    qn = normalize(query)
    matched = [t for t in tokens if phrase_match(t, qn)]
    return {'passes': bool(matched), 'matched': matched, 'tokens': tokens}


def route_one_package(query: str, pkg: Dict[str, Any]) -> Dict[str, Any]:
    qn = normalize(query)
    policy = pkg['manifest'].get('activation_policy', {})
    activate = policy.get('activate_when', [])
    avoid = policy.get('avoid_when', [])
    activate_matches = [t for t in activate if phrase_match(t, qn)]
    avoid_matches = [t for t in avoid if phrase_match(t, qn)]
    if avoid_matches:
        cls = 'avoid'
    elif activate_matches:
        cls = 'activate'
    else:
        tags = pkg['manifest'].get('tags', [])
        domain = pkg['manifest'].get('domain', '')
        tag_match = any(normalize(t) in qn for t in tags)
        domain_match = bool(domain) and normalize(domain) in qn
        cls = 'candidate' if (tag_match or domain_match) else 'check_clusters'
    return {
        'package_id': pkg['manifest']['package_id'],
        'classification': cls,
        'activate_matches': activate_matches,
        'avoid_matches': avoid_matches,
    }


def score_cluster(cluster: Dict[str, Any], query: str) -> Dict[str, Any]:
    qn = normalize(query)
    pos = [c for c in cluster.get('cues', []) if phrase_match(c, qn)]
    neg = [c for c in cluster.get('negative_cues', []) if phrase_match(c, qn)]
    avoid = [t for t in cluster.get('activation_policy', {}).get('avoid_when', [])
             if phrase_match(t, qn)]
    penalty = 3 if avoid else 0
    score = len(pos) - 2 * len(neg) - penalty
    return {
        'cluster': cluster,
        'score': score,
        'positive_matches': pos,
        'negative_matches': neg,
        'policy_avoid': avoid,
    }


def activate_clusters_in_package(query: str, pkg: Dict[str, Any], routing: Dict[str, Any]) -> List[Dict[str, Any]]:
    if routing['classification'] == 'avoid':
        return []
    scored = [score_cluster(c, query) for c in pkg.get('clusters', [])]
    scored = [s for s in scored if s['score'] >= 1]
    scored.sort(key=lambda s: s['score'], reverse=True)
    return scored


def check_constraints(query: str, activated: List[Dict[str, Any]],
                       pkg: Dict[str, Any]) -> List[Dict[str, Any]]:
    qn = normalize(query)
    active_ids = {a['cluster']['id'] for a in activated}
    triggered = []
    for c in pkg.get('constraints', []):
        triggers = False
        reasons = []
        cue_matches = [t for t in c.get('trigger_cues', []) if phrase_match(t, qn)]
        if cue_matches:
            triggers = True
            reasons.append(f"cues: {', '.join(cue_matches)}")
        related_active = [r for r in c.get('related_clusters', []) if r in active_ids]
        if related_active:
            triggers = True
            reasons.append(f"active cluster: {related_active[0]}")
        applies_match = [a for a in c.get('applies_to', []) if phrase_match(a, qn)]
        if applies_match:
            triggers = True
            reasons.append(f"applies_to: {', '.join(applies_match)}")
        if triggers:
            triggered.append({'constraint': c, 'reasons': reasons,
                               'package_id': pkg['manifest']['package_id']})
    return triggered


def match_trajectories(query: str, activated: List[Dict[str, Any]],
                        pkg: Dict[str, Any]) -> List[Dict[str, Any]]:
    qn = normalize(query)
    active_ids = {a['cluster']['id'] for a in activated}
    out = []
    for tr in pkg.get('trajectories', []):
        triggers = tr.get('trigger', tr.get('triggers', {}))
        phrases = triggers.get('cues', []) + triggers.get('query_phrases', [])
        patterns = triggers.get('input_types', []) + triggers.get('query_patterns', [])
        phrase_matches = [p for p in phrases if phrase_match(p, qn)]
        pattern_matches = [p for p in patterns if phrase_match(p, qn)]
        path_active = sum(1 for c in tr.get('path', []) if c in active_ids)
        score = len(phrase_matches) * 2 + len(pattern_matches) * 2 + path_active
        if score >= 2:
            out.append({
                'trajectory': tr, 'score': score,
                'phrase_matches': phrase_matches,
                'pattern_matches': pattern_matches,
                'path_active': path_active,
                'package_id': pkg['manifest']['package_id'],
            })
    out.sort(key=lambda m: m['score'], reverse=True)
    return out


def retrieve(query: str, packages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Top-level multi-package retrieval. Mirrors the JS retrieve() in tcog_demo.html."""
    trace = {
        'routing_per_package': [],
        'activated_clusters': [],
        'units': [],
        'triggered_constraints': [],
        'matched_trajectories': [],
        'frame_issues': [],
        'active_packages': [],
        'suppressed_packages': [],
        'disposition': '',
    }

    if not packages:
        trace['disposition'] = 'no_packages_loaded'
        return trace

    all_activated = []
    for pkg in packages:
        routing = route_one_package(query, pkg)
        trace['routing_per_package'].append(routing)
        if routing['classification'] == 'avoid':
            trace['suppressed_packages'].append({
                'package_id': pkg['manifest']['package_id'],
                'domain': pkg['manifest'].get('domain', ''),
                'reason': 'avoid_when',
                'detail': f"avoid_when matched: {', '.join(routing['avoid_matches'])}",
            })
            continue
        # strict_domain_tokens gate: tentatively activate to expose what
        # generic cues *would* have hit, then drop if no domain token matches.
        gate = check_domain_gate(query, pkg)
        if not gate['passes']:
            tentative = activate_clusters_in_package(query, pkg, routing)
            cues_used = sorted({c for a in tentative for c in a['positive_matches']})
            if tentative:
                detail = (
                    f"Generic cues matched ({', '.join(cues_used)}) but no "
                    f"strong-domain token from this package appears in the query. "
                    f"Clusters dropped to prevent overreach."
                )
            else:
                detail = (
                    "No strong-domain token from this package appears in the query. "
                    "The package was considered and dropped — its frame does not apply here."
                )
            trace['suppressed_packages'].append({
                'package_id': pkg['manifest']['package_id'],
                'domain': pkg['manifest'].get('domain', ''),
                'reason': 'suppressed_due_to_overreach',
                'detail': detail,
                'would_have_activated': [
                    {'id': a['cluster']['id'], 'label': a['cluster'].get('label', ''),
                     'score': a['score'], 'cues': a['positive_matches']}
                    for a in tentative
                ],
            })
            continue
        for a in activate_clusters_in_package(query, pkg, routing):
            a['package_id'] = pkg['manifest']['package_id']
            a['package'] = pkg
            all_activated.append(a)

    all_activated.sort(key=lambda a: a['score'], reverse=True)
    trace['activated_clusters'] = all_activated[:7]

    active_pkg_ids = {a['package_id'] for a in trace['activated_clusters']}
    trace['active_packages'] = [p for p in packages
                                  if p['manifest']['package_id'] in active_pkg_ids]

    for pkg in trace['active_packages']:
        pkg_id = pkg['manifest']['package_id']
        pkg_clusters = [a for a in trace['activated_clusters'] if a['package_id'] == pkg_id]
        unit_ids = set()
        for a in pkg_clusters:
            for m in a['cluster'].get('members', []):
                unit_ids.add(m)
        for u in pkg.get('units', []):
            if u['id'] in unit_ids:
                trace['units'].append(u)

    for pkg in packages:
        pkg_id = pkg['manifest']['package_id']
        pkg_activated = [a for a in trace['activated_clusters'] if a['package_id'] == pkg_id]
        if not pkg_activated:
            continue
        for c in check_constraints(query, pkg_activated, pkg):
            trace['triggered_constraints'].append(c)
        for m in match_trajectories(query, pkg_activated, pkg):
            trace['matched_trajectories'].append(m)

    trace['matched_trajectories'].sort(key=lambda m: m['score'], reverse=True)
    trace['matched_trajectories'] = trace['matched_trajectories'][:2]

    if len(trace['active_packages']) >= 2:
        trace['frame_issues'].append({
            'kind': 'multi_package_active',
            'message': f"{len(trace['active_packages'])} packages activated",
            'packages': [p['manifest']['package_id'] for p in trace['active_packages']],
        })

    blocking = [t for t in trace['triggered_constraints']
                if t['constraint'].get('blocks_answer')]
    all_avoided = (trace['routing_per_package']
                    and all(r['classification'] == 'avoid'
                            for r in trace['routing_per_package']))
    no_clusters = len(trace['activated_clusters']) == 0

    if all_avoided:
        trace['disposition'] = 'refuse_out_of_frame'
    elif no_clusters:
        trace['disposition'] = 'no_match'
    elif blocking:
        trace['disposition'] = 'partial_with_blocking_constraints'
    else:
        trace['disposition'] = 'normal_answer'

    return trace


# ============================================================================
# Test runner
# ============================================================================

def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    out = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def load_package(bundle_root: Path, pkg_id: str) -> Dict[str, Any]:
    """Load a package via its package.combined.json."""
    cpath = bundle_root / pkg_id / 'package.combined.json'
    return json.loads(cpath.read_text())


def check_test(test: Dict[str, Any], trace: Dict[str, Any],
                target_pkg: Optional[str] = None) -> Tuple[bool, List[str]]:
    activated_ids = [a['cluster']['id'] for a in trace['activated_clusters']]
    constraint_ids = [c['constraint']['id'] for c in trace['triggered_constraints']]
    traj_ids = [m['trajectory']['id'] for m in trace['matched_trajectories']]
    active_pkg_ids = [p['manifest']['package_id'] for p in trace['active_packages']]
    multi_frame = any(i.get('kind') == 'multi_package_active'
                       for i in trace['frame_issues'])
    issues = []

    if 'expected_disposition' in test:
        if trace['disposition'] != test['expected_disposition']:
            issues.append(f"disposition: got {trace['disposition']}, expected {test['expected_disposition']}")

    if 'expected_disposition_any_of' in test:
        if trace['disposition'] not in test['expected_disposition_any_of']:
            issues.append(f"disposition: got {trace['disposition']}, expected one of {test['expected_disposition_any_of']}")

    if 'expected_activated_clusters' in test:
        expected = test['expected_activated_clusters']
        if expected:
            for cid in expected:
                if cid not in activated_ids:
                    issues.append(f"missing cluster {cid.split(':')[-1]}")
        else:
            # Empty list — no clusters from target package should activate
            if target_pkg:
                from_pkg = [a for a in trace['activated_clusters']
                             if a['package_id'] == target_pkg]
                if from_pkg:
                    issues.append(f"expected 0 from {target_pkg}, got {len(from_pkg)}")

    if 'expected_constraints_triggered' in test:
        for cid in test['expected_constraints_triggered']:
            if cid not in constraint_ids:
                issues.append(f"missing constraint {cid.split(':')[-1]}")

    if 'expected_constraints_any_of' in test:
        if not any(cid in constraint_ids for cid in test['expected_constraints_any_of']):
            short = [c.split(':')[-1] for c in test['expected_constraints_any_of']]
            issues.append(f"expected at least one of: {' or '.join(short)}")

    if 'expected_trajectory' in test and test['expected_trajectory']:
        if test['expected_trajectory'] not in traj_ids:
            short = test['expected_trajectory'].split(':')[-1]
            got = [t.split(':')[-1] for t in traj_ids]
            issues.append(f"missing trajectory {short} (got: {','.join(got) or 'none'})")

    if 'expected_active_packages' in test:
        for p in test['expected_active_packages']:
            if p not in active_pkg_ids:
                issues.append(f"missing active package {p}")

    if test.get('expected_multi_frame') and not multi_frame:
        issues.append("expected multi-frame but got single-frame")


    if 'expected_suppressed_packages' in test:
        suppressed_ids = {s['package_id'] for s in trace.get('suppressed_packages', [])}
        for pkg_id in test['expected_suppressed_packages']:
            if pkg_id not in suppressed_ids:
                issues.append(f"expected suppressed package {pkg_id} but it was not suppressed")

    if 'expected_suppressed_due_to_overreach' in test:
        overreach_ids = {s['package_id'] for s in trace.get('suppressed_packages', [])
                          if s.get('reason') == 'suppressed_due_to_overreach'}
        for pkg_id in test['expected_suppressed_due_to_overreach']:
            if pkg_id not in overreach_ids:
                issues.append(f"expected {pkg_id} to be suppressed_due_to_overreach but it was not")

    if 'should_not_activate_packages' in test:
        for pkg_id in test['should_not_activate_packages']:
            if pkg_id in active_pkg_ids:
                issues.append(f"package {pkg_id} should not have activated but it did")

    if 'should_not_activate_clusters' in test:
        for cid in test['should_not_activate_clusters']:
            if cid in activated_ids:
                issues.append(f"cluster {cid} should not have activated but it did")

    return len(issues) == 0, issues


def main():
    parser = argparse.ArgumentParser(description="Run TCog test suite.")
    parser.add_argument('--root', default='.', help="bundle root directory")
    parser.add_argument('--package', default=None,
                         help="run only this package's tests")
    parser.add_argument('--cross-only', action='store_true',
                         help="only cross-package tests")
    parser.add_argument('--single-only', action='store_true',
                         help="only single-package tests")
    parser.add_argument('--json', action='store_true', help="JSON output")
    parser.add_argument('--quiet', action='store_true', help="only print failures")
    args = parser.parse_args()

    bundle_root = Path(args.root).resolve()
    bm_path = bundle_root / 'bundle_manifest.json'
    if not bm_path.exists():
        print(f"ERROR: {bm_path} not found", file=sys.stderr)
        sys.exit(2)

    bm = json.loads(bm_path.read_text())
    pkg_ids = [p['package_id'] for p in bm['packages']]

    results = {'single': [], 'cross': []}

    # Single-package tests
    if not args.cross_only:
        targets = [args.package] if args.package else pkg_ids
        for pkg_id in targets:
            if pkg_id not in pkg_ids:
                print(f"ERROR: package {pkg_id} not in bundle", file=sys.stderr)
                sys.exit(2)
            pkg = load_package(bundle_root, pkg_id)
            for test in pkg.get('tests', []):
                trace = retrieve(test['input'], [pkg])
                ok, issues = check_test(test, trace, target_pkg=pkg_id)
                results['single'].append({
                    'pkg': pkg_id,
                    'test_id': test['id'],
                    'input': test['input'],
                    'ok': ok,
                    'issues': issues,
                    'disposition': trace['disposition'],
                })

    # Cross-package tests
    if not args.single_only and not args.package:
        cross_path = bundle_root / 'cross_package_tests.jsonl'
        cross = load_jsonl(cross_path)
        for test in cross:
            required = test.get('required_packages', [])
            packages = [load_package(bundle_root, p) for p in required if p in pkg_ids]
            trace = retrieve(test['input'], packages)
            ok, issues = check_test(test, trace)
            results['cross'].append({
                'test_id': test['id'],
                'input': test['input'],
                'required_packages': required,
                'ok': ok,
                'issues': issues,
                'disposition': trace['disposition'],
                'active_packages': [p['manifest']['package_id']
                                     for p in trace['active_packages']],
            })

    single_pass = sum(1 for r in results['single'] if r['ok'])
    single_fail = len(results['single']) - single_pass
    cross_pass = sum(1 for r in results['cross'] if r['ok'])
    cross_fail = len(results['cross']) - cross_pass

    if args.json:
        out = {
            'single_package': {
                'pass': single_pass,
                'fail': single_fail,
                'results': results['single'],
            },
            'cross_package': {
                'pass': cross_pass,
                'fail': cross_fail,
                'results': results['cross'],
            },
            'all_passed': single_fail == 0 and cross_fail == 0,
        }
        print(json.dumps(out, indent=2))
    else:
        if results['single']:
            print("===== SINGLE-PACKAGE TESTS =====\n")
            current_pkg = None
            for r in results['single']:
                if r['pkg'] != current_pkg:
                    if current_pkg is not None:
                        print()
                    print(f"--- {r['pkg']} ---")
                    current_pkg = r['pkg']
                if not r['ok']:
                    mark = '✗'
                    short = r['test_id'].split(':')[-1]
                    print(f"  {mark} {short}: {r['input'][:55]}")
                    print(f"     {'; '.join(r['issues'])}")
                elif not args.quiet:
                    short = r['test_id'].split(':')[-1]
                    print(f"  ✓ {short}: {r['input'][:55]}")
            print()

        if results['cross']:
            print("===== CROSS-PACKAGE TESTS =====\n")
            for r in results['cross']:
                mark = '✓' if r['ok'] else '✗'
                if r['ok'] and args.quiet:
                    continue
                print(f"{mark} {r['test_id']}: {r['input'][:55]}")
                print(f"  active: {', '.join(p.split('_')[0] for p in r['active_packages']) or 'none'}")
                if not r['ok']:
                    print(f"  ISSUES: {'; '.join(r['issues'])}")
                print()

        print("===== SUMMARY =====")
        print(f"Single-package: {single_pass}/{single_pass+single_fail} pass")
        print(f"Cross-package:  {cross_pass}/{cross_pass+cross_fail} pass")

    if single_fail == 0 and cross_fail == 0:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()
