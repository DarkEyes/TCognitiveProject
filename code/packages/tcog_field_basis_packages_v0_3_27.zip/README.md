# TCog Field Basis Packages v0.3.26

This bundle contains 24 TCog Protocol v0.3 basis packages distributed across three quality tiers: 5 fully focused, 19 anchor-promoted (focused-with-anchors but missing one or more of: blocking constraints, ≥3 trajectories, ≥3 cross-package relations), and 0 light scaffolds.

**Reading guide:** the 24 focused-tier packages are intended for evaluation as authored content (real anchors to canonical works; many have blocking constraints, multiple trajectories, branching trajectories, internal/cross-package complements relations with `surface_both_frames` retrieval behavior). The 0 scaffolds are loadable v0.3 packages that pass schema validation and demonstrate breadth-of-domain, but their anchors are self-referential and their content is templated — they are not authored disciplinary content. See `PROVENANCE.json` for the per-package quality declaration; counts there and in `bundle_validation_report.json` are regenerated from JSONL ground truth at each release, not curated by hand.

## What this is

A seed package bundle for Trajectory Cognition. Each package is a loadable bundle of:

```text
manifest.json
units.jsonl
clusters.jsonl
constraints.jsonl
transitions.jsonl
trajectories.jsonl
relations.jsonl
tests.jsonl
index.json
validation_report.json
package.combined.json
README.md
```

## Bundle totals

- **353** units (353 anchored to non-self-referential sources, 100.0%)
- **167** clusters
- **118** constraints (14 blocking across 7 packages)
- **79** trajectories (11 branching across 11 packages)
- **197** transitions
- **144** relations
- **173** single-package tests + cross_package_tests.jsonl at bundle root

## Retrieval grammar

```text
query
→ package routing (activate_when / avoid_when)
→ cue and negative-cue scan (mechanical mode default)
→ cluster activation (cap 7)
→ unit loading
→ constraint trigger check (cues / related-cluster / applies_to)
→ trajectory match (with branch handling at junction clusters)
→ relation/conflict check (retrieval_behavior dispatch)
→ answer with marked synthesis and citations
→ state update
```

## Tier distribution

### Fully focused (5)

All structural guarantees: blocking constraint, ≥3 trajectories with distinct triggers, ≥3 cross-package relations, ≥80% units anchored.

- `counselling_practice_core`
- `economics_core`
- `medicine_diagnostic_safety_core`
- `philosophy_ethics_core`
- `psychology_core`

### Anchor-promoted (19)

Anchored to canonical works but missing one or more of the additional guarantees. Each has a `tier_notes` field in PROVENANCE.json describing exactly what is and isn't done.

- `art_form_affect_core`
- `biology_adaptation_core`
- `chemistry_interactions_core`
- `cognitive_science_core`
- `communication_rhetoric_core`
- `computer_science_systems_core`
- `design_hci_core`
- `education_pedagogy_core`
- `history_path_dependence_core`
- `information_science_retrieval_core`
- `law_practice_core`
- `management_execution_core`
- `math_proof_core`
- `operations_research_decision_core`
- `physics_dynamical_constraints_core`
- `political_science_governance_core`
- `sociology_institutions_core`
- `statistics_core`
- `systems_control_core`

### Light scaffolds (0)

Schema-valid scaffolds with templated anchors. Useful for breadth demonstration and as starting points for future authoring.



## Authoring depth

A focused-tier package supplies:

- Real anchors to canonical works in the discipline (excerpts ≤280 chars per the v0.3 anchor format)
- 3+ trajectories with distinct trigger cues (concept-intro, primary reasoning path, plus secondary or branching paths)
- Admissibility constraints with concrete trigger_cues, repair instructions, and severity grading
- Cross-package relations capturing where this frame complements, conflicts with, or is constrained by other frames in the bundle
- Tests including an out-of-frame test demonstrating that negative cues correctly suppress activation in non-domain contexts

Several focused packages also include an internal `complements` relation with `retrieval_behavior: surface_both_frames` capturing structural disagreements within the discipline (e.g., expected-utility vs. prospect-theory in operations_research; Reason's Swiss-cheese vs. Leveson's STAMP in systems_control; Wimsatt-Beardsley's formalism vs. Iser's reader-response in art_form_affect).

## Verification

```bash
make verify        # schema validation + loader test + 218/218 tests
make verify-all    # adds SHA256SUMS verification
make schema        # just strict v0.3 schema validation (24/24 pass)
make tests         # just the test suite
make checksums     # regenerate SHA256SUMS
```

The validator (`validate_bundle.py`) cross-checks:
- Required fields per file type (units, clusters, constraints, trajectories, transitions, relations, tests)
- Identifier namespacing (every id begins with `<package_id>:`)
- Cross-references resolve (cluster members exist as units; trajectory paths reference real clusters; relations point to real packages or namespaced ids; constraints' related_clusters exist)
- JSONL line counts match `package.combined.json` array lengths
- JSONL line counts match each package's `validation_report.json` reported counts (added v0.3.26)
- Bundle manifest's `package_count` matches actual package directory count

The test runner (`run_tests.py`) is a Python port of the mechanical retrieval engine. It runs each package's tests plus the cross-package test suite, with non-zero exit on any failure.

## Browser entry point

Open `docs/index.html` in any browser for a static index of all packages with links to their READMEs and combined.json files.

## Per-package READMEs

Each package directory contains a `README.md` summarizing the cluster structure, anchored sources, trajectories (including any branching), constraints, and cross-package relations specific to that package.

## License

CC-BY 4.0 for the schema and bundle structure. Individual packages may have additional license notes in their manifests.
