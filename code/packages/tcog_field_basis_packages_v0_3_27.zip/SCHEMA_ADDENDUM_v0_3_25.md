# TCog Schema v0.3.25 Addendum

**Status:** Bundle-level addendum to TCog Schema v0.3.
**Applies to:** `tcog_field_basis_packages_v0_3_25.zip` and later.
**Audience:** Reviewers, package authors, runtime implementers.

---

## Purpose

The TCog Schema v0.3 specification (`tcog-schema.md`) defined the contract between package authors, ingestion systems, retrieval systems, and human reviewers. The bundle has since added several optional fields and controlled-vocabulary values that go beyond the published v0.3 schema. These additions are **strictly additive** — a package that uses none of them remains a valid v0.3 package, and a v0.3 package that uses none of these is treated identically by the v0.3.25 runtime.

This addendum documents the additions so reviewers do not see them as schema violations and so future implementers know what fields are part of the bundle's authoring contract.

---

## 1. New manifest field: `activation_policy.strict_domain_tokens`

**Type:** `array<string>`
**Default:** absent (no domain gate)
**Authoring scope:** package manifest

```json
{
  "manifest": {
    "activation_policy": {
      "activate_when": [...],
      "avoid_when": [...],
      "strict_domain_tokens": [
        "chemistry", "molecule", "reaction", "catalyst",
        "Hammett", "stoichiometry", ...
      ]
    }
  }
}
```

When present and non-empty, the runtime enforces a **strong-domain gate**: at least one strict-domain token must phrase-match the query before any cluster from this package is allowed to enter the activation pool. If the gate fails, the package is recorded in the trace as `suppressed_due_to_overreach`, with a `would_have_activated` field exposing the clusters that *would* have fired under a less strict regime.

**Purpose.** Generic vocabulary (e.g. cluster cue `structure`, `reaction`, `system`, `feedback`) can match queries far outside the package's intended domain. The strict-domain gate requires the query to contain genuinely domain-identifying vocabulary before the package contributes claims. This is package-authored overreach prevention, replacing earlier JavaScript fallback patches in the runtime.

**Authoring guidance.** Tokens should be vocabulary a domain expert would recognize as identifying their field. Multi-word tokens (e.g. `"reaction conditions"`, `"prose style"`) are matched by substring containment; single-word tokens (e.g. `"Hammett"`, `"habitus"`) are matched by lemma. Authors should expand the list when legitimate domain queries fail to pass the gate.

**Lookup priority** (mirrored in JS and Python runtimes):
1. `manifest.activation_policy.strict_domain_tokens`
2. `manifest.strict_domain_tokens`
3. `package.strict_domain_tokens` (top-level on the combined object)
4. Deprecated runtime fallback (`PACKAGE_PATCHES` in browser JS, `_strict_domain_tokens` in Python).

Bundle status: 6 packages currently author strict_domain_tokens (`chemistry_interactions_core`, `physics_dynamical_constraints_core`, `systems_control_core`, `operations_research_decision_core`, `art_form_affect_core`, `sociology_institutions_core`).

---

## 2. New trace field: `suppressed_packages`

**Type:** `array<object>`
**Authoring scope:** runtime trace (not in package files)
**Object form:**

```json
{
  "package_id": "chemistry_interactions_core",
  "domain": "chemistry",
  "reason": "suppressed_due_to_overreach",
  "detail": "Generic cues matched (structure, system) but no strong-domain token...",
  "would_have_activated": [
    {"id": "...:k_structure_determines_interaction", "label": "...", "score": 2,
     "cues": ["structure", "system"]}
  ]
}
```

**Reason values:**
- `"avoid_when"` — manifest `avoid_when` matched the query.
- `"suppressed_due_to_overreach"` — strict-domain gate failed.

The trace surfaces `would_have_activated` for `suppressed_due_to_overreach` so that audit tooling (browser demo, paper appendices) can show *what would have hit* under a looser regime — making the architectural prevention visible rather than silent.

---

## 3. New relation fields: `source_type` and `target_type`

**Type:** `string`
**Authoring scope:** every relation object in `relations.jsonl`
**Allowed values:** `"package"`, `"object"`, `"package_glob"`

```json
{
  "id": "...:rel_complements_economics_core",
  "type": "complements",
  "source_type": "package",
  "source": "sociology_institutions_core",
  "target_type": "package",
  "target": "economics_core",
  "retrieval_behavior": "joint_consideration"
}
```

```json
{
  "id": "...:rel_internal_methodological_individualism_vs_holism",
  "type": "complements",
  "source_type": "object",
  "source": "sociology_institutions_core:u_coleman_micro_macro_methodological_individualism",
  "target_type": "object",
  "target": "sociology_institutions_core:u_bourdieu_habitus_practice",
  "retrieval_behavior": "surface_both_frames"
}
```

Disambiguates package-level relations (where `source` / `target` are package IDs without a colon) from object-level relations (where they are namespaced object IDs). Without these fields, a strict validator would treat package IDs like `"economics_core"` as unresolved object references.

**`package_glob`** is reserved for future use, currently appearing on relations whose target is `"all_packages"`.

Bundle status at v0.3.25: 131 package-level relations + 13 object-level relations.

---

## 4. New relation types: `complements`, `safety_boundary`

**Schema-blessed addition** to the TCog Schema v0.3 §5.8 list (`supports`, `extends`, `refines`, `contrasts_with`, `conflicts_with`, `depends_on`, `supersedes`, `frame_limited_by`).

- **`complements`** — two packages (or two objects) approach the same problem from compatible but distinct frames. Default `retrieval_behavior`: `joint_consideration` for cross-package, `surface_both_frames` for canonical disagreements within a package. Bundle status: 109 instances.
- **`safety_boundary`** — a normatively-charged frame limit, distinct from the descriptive `frame_limited_by`. Used when crossing the boundary risks harm rather than mere category error (e.g. counselling's crisis_safety_override boundary on economics). Bundle status: 2 instances.

Legacy types still accepted (and present in some unmigrated bundles):
- `"frame_limit"` → normalize to `"frame_limited_by"`
- `"potential_conflict"` → normalize to `"conflicts_with"`
- `"refined_by"` → normalize to `"refines"` (with `source` and `target` swapped to preserve direction, since `A refined_by B` ≡ `B refines A`)

---

## 5. Controlled `retrieval_behavior` vocabulary

**Allowed values** (any other string is rejected by strict validation in v0.3.26+):

- `surface_both_frames`
- `prefer_source`
- `prefer_target`
- `require_user_choice`
- `joint_consideration`
- `suppress_if_avoid_when_matches`

Long descriptive strings that previously appeared in this field (e.g. `"activate_jointly_for_value_laden_treatment"`, `"do_not_overapply_when_avoid_when_matches"`) are stashed in a new `runtime_note` field for traceability:

```json
{
  "type": "complements",
  "retrieval_behavior": "joint_consideration",
  "runtime_note": "activate jointly for value-laden treatment decisions"
}
```

This makes the runtime mechanically dispatchable without parsing arbitrary strings, while preserving the original authoring intent.

---

## 6. New test field: `test_type`

**Type:** `string`
**Authoring scope:** every test object in `tests.jsonl` and `cross_package_tests.jsonl`
**Allowed values:**

- `"activation_test"` — verifies a package or cluster activates on the query
- `"constraint_test"` — verifies a constraint triggers
- `"frame_conflict_test"` — verifies cross-frame behavior, including overreach suppression and multi-frame surfacing

Auto-classification rule (used by the bundle's regenerator):
1. If `expected_multi_frame: true` OR ≥2 `expected_active_packages` OR ≥2 `required_packages` → `frame_conflict_test`.
2. Else if `expected_constraints_triggered` or `expected_constraints_any_of` is non-empty → `constraint_test`.
3. Else → `activation_test`.

Purpose: makes the bundle a benchmark suite for frame-aware reasoning rather than a flat list of activation cases. Future test runners may filter or report by `test_type`.

Bundle status at v0.3.26: 173 single-package tests + 45 cross-package tests = 218 tests, with `test_type` populated on every test.

---

## 7. New test assertion fields (v0.3.26)

The test schema accepts the following new optional assertion fields, processed by `run_tests.py`:

- **`expected_suppressed_packages`** — list of package IDs that must appear in `trace.suppressed_packages` (any reason).
- **`expected_suppressed_due_to_overreach`** — list of package IDs that must appear in `trace.suppressed_packages` with `reason == "suppressed_due_to_overreach"`. The strict assertion that the strict-domain-token gate did its job.
- **`should_not_activate_packages`** — list of package IDs that must NOT appear in `trace.active_packages`. Useful for negative tests where a package must remain dormant despite some keyword overlap.
- **`should_not_activate_clusters`** — list of cluster IDs that must NOT appear in `trace.activated_clusters`.

Example:

```json
{
  "id": "cross:test_no_chemistry_overreach_on_rationing",
  "test_type": "frame_conflict_test",
  "input": "Is it efficient and fair to ration healthcare by ability to pay?",
  "required_packages": ["economics_core", "philosophy_ethics_core",
                        "chemistry_interactions_core"],
  "expected_active_packages": ["economics_core", "philosophy_ethics_core"],
  "expected_suppressed_due_to_overreach": ["chemistry_interactions_core"],
  "should_not_activate_packages": ["chemistry_interactions_core"]
}
```

This test exercises the architectural claim — TCog-R prevents overreach mechanically — and makes it falsifiable.

---

## 8. Engine parity (v0.3.26)

The Python `run_tests.py` was previously a partial port of the JS retrieval engine. v0.3.26 brings them to parity:

- **`phrase_match` single-token guard.** Single-token cues now match query tokens via lemma only. Substring containment is reserved for multi-word cues, where the spaces act as word boundaries. Previously, single-token cue `ratio` could substring-match the query token `ration`, causing `chemistry_interactions_core` to over-activate on healthcare-rationing queries.
- **`get_strict_domain_tokens()` and `check_domain_gate()`** added with the same lookup priority as the browser engine.
- **`suppressed_packages`** added to the trace skeleton with `would_have_activated` detail.
- **Test runner extensions** for the new assertion fields above.

The browser engine and `run_tests.py` are now expected to agree on every test in the bundle. Divergence between them is a bug.

---

## 9. Forward compatibility

Future schema versions should either:
1. Promote these extensions into the next protocol version (e.g. `tcog-schema.md v0.4`), or
2. Keep them as bundle-level extensions and continue treating v0.3 as the published surface.

The bundle's `protocol_version` remains `"0.3"` — these are additive optional fields, not breaking changes. A package may use any subset of them or none at all and remain valid.

---

*Last updated: 2026-05-01 (v0.3.26 release)*
